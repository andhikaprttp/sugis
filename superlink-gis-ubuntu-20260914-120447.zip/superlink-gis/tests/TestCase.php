<?php

namespace Tests;

abstract class TestCase extends \Illuminate\Foundation\Testing\TestCase
{
    protected function serviceAreaId(): string
    {
        return \App\Models\ServiceArea::firstOrCreate(
            ['name' => 'Fixture area', 'village' => 'Fixture village', 'district' => 'Fixture district', 'city' => 'Fixture city'],
            ['created_by' => auth()->id()]
        )->id;
    }
    protected function setUp(): void
    {
        parent::setUp();
        if (! str_ends_with((string) config('database.connections.pgsql.database'), '_test')) {
            throw new \RuntimeException('Tests require a dedicated database ending in _test.');
        }
        $this->withoutVite();
    }
}
