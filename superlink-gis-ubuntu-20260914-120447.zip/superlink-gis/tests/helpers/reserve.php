<?php

use App\Models\OdpPort;
use App\Models\Survey;
use App\Services\Network\PortService;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Validation\ValidationException;

require dirname(__DIR__, 2).'/vendor/autoload.php';
$app = require dirname(__DIR__, 2).'/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();
try {
    auth()->loginUsingId((int) $argv[3]);
    app(PortService::class)->reserve(OdpPort::findOrFail($argv[1]), Survey::findOrFail($argv[2]));
    echo 'RESERVED';
    exit(0);
} catch (ValidationException $e) {
    echo 'CONFLICT';
    exit(2);
}
