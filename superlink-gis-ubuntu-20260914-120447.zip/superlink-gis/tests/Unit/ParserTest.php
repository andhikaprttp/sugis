<?php

namespace Tests\Unit;

use App\Services\Gis\KmlParserService;
use App\Services\Survey\SurveyService;
use PHPUnit\Framework\TestCase;

class ParserTest extends TestCase
{
    public function test_kml_point_line_polygon_folders_and_description(): void
    {
        $p = (new KmlParserService)->parse(file_get_contents(__DIR__.'/../../samples/network.kml'));
        $this->assertCount(3, $p['objects']);
        $this->assertSame(['Point' => 1, 'LineString' => 1, 'Polygon' => 1, 'Folders' => 1], $p['counts']);
        $this->assertSame('UNCLASSIFIED', $p['objects'][0]['object_type']);
        $this->assertStringNotContainsString('<script>', $p['objects'][0]['description']);
        $this->assertSame([106.76, -6.37], $p['objects'][0]['geometry']['coordinates']);
    }

    public function test_xml_entities_rejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        (new KmlParserService)->parse('<!DOCTYPE kml [<!ENTITY x SYSTEM "file:///etc/passwd">]><kml>&x;</kml>');
    }

    public function test_invalid_coordinate_rejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        (new KmlParserService)->parse('<kml><Placemark><Point><coordinates>190,-6</coordinates></Point></Placemark></kml>');
    }

    public function test_corrupt_xml_rejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        (new KmlParserService)->parse('<kml><broken>');
    }

    public function test_estimate_respects_allowance(): void
    {
        $this->assertSame(270.6, SurveyService::estimate(246, 10));
        $this->assertSame(307.5, SurveyService::estimate(246, 25));
    }
}
