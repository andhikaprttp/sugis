<?php

namespace Tests\Unit;

use App\Services\Customer\FlexibleSpreadsheet;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PHPUnit\Framework\TestCase;

class FlexibleSpreadsheetTest extends TestCase
{
    public function test_reordered_headers_and_leading_cover_sheet(): void
    {
        $book = new Spreadsheet;
        $sheet = $book->createSheet();
        $sheet->fromArray([' SN ', 'NAMA PELANGGAN', 'Username'], null, 'B7');
        [$found, $row, $map] = (new FlexibleSpreadsheet)->header($book);
        $this->assertSame($sheet, $found);
        $this->assertSame(7, $row);
        $this->assertSame([1 => 'ont_serial_number', 2 => 'name', 3 => 'pppoe_username'], $map);
    }

    public function test_duplicate_aliases_fail_instead_of_overwriting(): void
    {
        $book = new Spreadsheet;
        $book->getActiveSheet()->fromArray(['Client', 'Name', 'SN']);
        $this->expectException(\InvalidArgumentException::class);
        (new FlexibleSpreadsheet)->header($book);
    }

    public function test_serial_fallback_and_invalid_date_are_not_invented(): void
    {
        [$row] = (new FlexibleSpreadsheet)->row(['name' => 'Example', 'ont_serial_number' => ' abc 123 ', 'activation_date' => '31 Februari 2026']);
        $this->assertSame('ONT-ABC123', $row['customer_id']);
        $this->assertSame('31 Februari 2026', $row['activation_date']);
    }
}
