<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\Odp;
use App\Models\OdpPort;
use App\Models\Survey;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class ConcurrencyTest extends TestCase
{
    public function test_two_processes_cannot_reserve_same_port(): void
    {
        $u = User::create(['name' => 'Concurrency', 'email' => uniqid().'@test.invalid', 'password' => 'Concurrency-Test-123']);
        $g = GisObject::create(['name' => 'Concurrency ODP', 'object_type' => 'ODP']);
        $o = Odp::create(['id' => $g->id, 'capacity' => 1]);
        $p = OdpPort::create(['odp_id' => $o->id, 'port_number' => 1]);
        $cg = GisObject::create(['name' => 'Concurrency customer', 'object_type' => 'PROSPECT']);
        $c = Customer::create(['gis_object_id' => $cg->id, 'customer_id' => 'CONC-'.uniqid(), 'name' => 'Concurrent']);
        $s1 = Survey::create(['customer_id' => $c->id, 'odp_id' => $o->id, 'surveyor_id' => $u->id, 'status' => 'APPROVED']);
        $s2 = Survey::create(['customer_id' => $c->id, 'odp_id' => $o->id, 'surveyor_id' => $u->id, 'status' => 'APPROVED']);
        $env = array_merge(getenv(), ['DB_DATABASE' => config('database.connections.pgsql.database'), 'DB_HOST' => config('database.connections.pgsql.host'), 'DB_PORT' => (string) config('database.connections.pgsql.port'), 'DB_USERNAME' => config('database.connections.pgsql.username'), 'DB_PASSWORD' => (string) config('database.connections.pgsql.password'), 'CACHE_STORE' => 'array', 'SESSION_DRIVER' => 'array', 'APP_ENV' => 'testing', 'LOG_CHANNEL' => 'single']);
        try {
            $processes = [];
            $pipes = [];
            foreach ([$s1, $s2] as $i => $s) {
                $processes[$i] = proc_open([PHP_BINARY, base_path('tests/helpers/reserve.php'), $p->id, $s->id, (string) $u->id], [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes[$i], base_path(), $env);
                $this->assertIsResource($processes[$i]);
                fclose($pipes[$i][0]);
            }$out = [];
            foreach ($processes as $i => $process) {
                $out[] = stream_get_contents($pipes[$i][1]);
                $err = stream_get_contents($pipes[$i][2]);
                fclose($pipes[$i][1]);
                fclose($pipes[$i][2]);
                proc_close($process);
                $this->assertSame('', $err);
            }sort($out);
            $this->assertSame(['CONFLICT', 'RESERVED'], $out);
            $this->assertSame(1, OdpPort::where('odp_id', $o->id)->where('status', 'RESERVED')->count());
        } finally {
            DB::table('audit_logs')->where('model_id', $p->id)->delete();
            $p->update(['status' => 'AVAILABLE', 'reserved_for' => null]);
            $s1->delete();
            $s2->delete();
            $p->delete();
            DB::table('customers')->where('id', $c->id)->delete();
            DB::table('odps')->where('id', $o->id)->delete();
            $g->forceDelete();
            $cg->forceDelete();
            $u->delete();
        }
    }
}
