<?php

namespace Tests\Feature;

use App\Http\Resources\GisObjectResource;
use App\Models\GisObject;
use App\Models\ImportJob;
use App\Models\ServiceArea;
use App\Models\User;
use App\Services\Network\NetworkService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ServiceAreaTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Area tester', 'email' => uniqid().'@test.invalid', 'password' => 'Area-testing-password']);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
    }

    public function test_area_destination_is_required_and_region_creation_is_validated(): void
    {
        $file = UploadedFile::fake()->createWithContent('network.kml', file_get_contents(base_path('samples/network.kml')));
        $this->post('/gis/import', ['file' => $file])->assertSessionHasErrors('service_area_id');
        $this->post('/areas', ['name' => 'Coverage'])->assertSessionHasErrors(['village', 'district', 'city']);
        $this->postJson('/areas', ['name' => 'Coverage', 'village' => 'A', 'district' => 'B', 'city' => ['invalid']])->assertUnprocessable();
        $this->post('/areas', ['name' => 'Coverage', 'village' => 'Cinangka', 'district' => 'Sawangan', 'city' => 'Depok'])->assertSessionHasNoErrors()->assertRedirect();
        $area = ServiceArea::where('name', 'Coverage')->firstOrFail();
        $this->get('/areas/create?service_area_id='.$area->id)->assertInertia(fn ($p) => $p->component('Areas/Create')->where('selectedAreaId', $area->id));
        $this->get('/areas')->assertOk();
        auth()->user()->syncRoles('VIEWER');
        $this->post('/areas', [])->assertForbidden();
        $this->post('/gis/import', ['file' => $file, 'service_area_id' => $area->id])->assertForbidden();
    }

    public function test_repeated_import_appends_to_selected_area_and_cannot_override_destination(): void
    {
        $area = $this->serviceAreaId();
        $other = ServiceArea::create(['name' => 'Other', 'village' => 'Other', 'district' => 'Other', 'city' => 'Other', 'created_by' => auth()->id()]);
        $before = GisObject::count();
        foreach (range(1, 2) as $i) {
            $file = UploadedFile::fake()->createWithContent('network.kmz', file_get_contents(base_path('samples/network.kmz')));
            $this->post('/gis/import', ['file' => $file, 'service_area_id' => $area])->assertSessionHasNoErrors();
            $job = ImportJob::where('status', 'READY')->latest()->firstOrFail();
            $row = $job->rows()->where('validation', 'VALID')->firstOrFail();
            $this->post('/gis/import/'.$job->id.'/commit', ['ids' => [$row->id], 'changes' => [$row->id => ['service_area_id' => $other->id]]])->assertSessionHasNoErrors();
            $this->assertSame($i, GisObject::where('service_area_id', $area)->count());
            $this->assertSame($before + $i, GisObject::count());
            Storage::delete($job->path);
        }
        $this->getJson('/api/map/objects?service_area_id='.$area)->assertOk()->assertJsonCount(2, 'data');
        $this->getJson('/api/map/objects?service_area_id='.$other->id)->assertOk()->assertJsonCount(0, 'data');
    }

    public function test_map_network_serialization_uses_bounded_queries_and_correct_availability(): void
    {
        $ids = [];
        for ($i = 0; $i < 12; $i++) {
            $ids[] = app(NetworkService::class)->save(['name' => 'Query test '.$i, 'object_type' => 'ODP', 'capacity' => 8, 'geometry' => ['type' => 'Point', 'coordinates' => [106.76 + $i / 10000, -6.37]]])->id;
        }
        $objects = GisObject::withGeometry()->whereIn('id', $ids)->get();
        DB::enableQueryLog();
        DB::flushQueryLog();
        foreach ($objects as $object) {
            (new GisObjectResource($object))->resolve();
        }
        $individualQueries = count(DB::getQueryLog());
        DB::flushQueryLog();
        $data = GisObjectResource::collection($objects)->resolve();
        $queries = count(DB::getQueryLog());
        DB::disableQueryLog();
        $this->assertLessThan($individualQueries, $queries);
        fwrite(STDOUT, "\nMap query comparison (12 ODP): {$individualQueries} individual -> {$queries} batched\n");
        $this->assertLessThanOrEqual(6, $queries, 'Map serialization must not query once per ODP');
        $this->assertCount(12, $data);
        $this->assertSame(8, $data[0]['availability']['available']);
    }

    public function test_import_staging_crosses_batch_boundary_without_losing_rows(): void
    {
        $xml = '<kml><Document>'.str_repeat('<Placemark><name>Point</name><Point><coordinates>106.76,-6.37</coordinates></Point></Placemark>', 501).'</Document></kml>';
        $file = UploadedFile::fake()->createWithContent('batch.kml', $xml);
        $this->post('/gis/import', ['file' => $file, 'service_area_id' => $this->serviceAreaId()])->assertSessionHasNoErrors();
        $job = ImportJob::where('filename', 'batch.kml')->firstOrFail();
        $this->assertSame('READY', $job->status);
        $this->assertSame(501, $job->rows()->count());
        $this->assertSame(501, $job->rows()->max('row_number'));
        Storage::delete($job->path);
    }
}
