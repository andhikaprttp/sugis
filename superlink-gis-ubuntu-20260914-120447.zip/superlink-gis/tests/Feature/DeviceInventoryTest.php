<?php

namespace Tests\Feature;

use App\Http\Middleware\HandleInertiaRequests;
use App\Models\Customer;
use App\Models\Device;
use App\Models\User;
use App\Services\Customer\CustomerService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class DeviceInventoryTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Inventory tester', 'email' => uniqid().'@test.invalid', 'password' => 'Inventory-test-123']);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
    }

    private function customer(): Customer
    {
        return app(CustomerService::class)->save(['customer_id' => uniqid('INV-'), 'name' => 'Inventory Customer']);
    }

    private function device(string $type = 'ONT'): Device
    {
        $serial = strtoupper(uniqid('SN-'));
        $this->post('/devices', ['asset_tag' => $serial, 'serial_number' => $serial, 'type' => $type, 'vendor' => 'CDATA', 'model' => 'Test model', 'location' => 'Gudang'])->assertSessionHasNoErrors()->assertRedirect();

        return Device::where('serial_number', $serial)->firstOrFail();
    }

    private function assign(Device $device, Customer $customer)
    {
        return $this->post('/devices/'.$device->id.'/transition', ['action' => 'ASSIGN', 'customer_id' => $customer->id]);
    }

    public function test_assign_from_customer_shows_stock_with_destination_and_conflict_hints(): void
    {
        $device = $this->device();
        $customer = $this->customer();
        $this->get('/devices?type=ONT&status=IN_STOCK&assign_to='.$customer->id)
            ->assertInertia(fn ($p) => $p->where('selectedCustomer.id', $customer->id)->where('devices.data.0.id', $device->id));
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $other = $this->device();
        $this->getJson('/devices/customer-options?search='.$customer->customer_id.'&device_id='.$other->id)
            ->assertOk()->assertJsonFragment(['assignment_blocked' => 'Sudah memiliki ONT inventori']);
    }

    public function test_stock_filter_partial_reload_skips_history_and_chart_queries(): void
    {
        $this->device();
        DB::enableQueryLog();
        DB::flushQueryLog();
        $this->withHeaders(['X-Inertia' => 'true', 'X-Inertia-Version' => app(HandleInertiaRequests::class)->version(request()), 'X-Inertia-Partial-Component' => 'Devices/Index', 'X-Inertia-Partial-Data' => 'devices,filters,selectedCustomer'])
            ->get('/devices?type=ONT&status=IN_STOCK')->assertOk()->assertJsonMissingPath('props.history')->assertJsonMissingPath('props.summary');
        $queries = collect(DB::getQueryLog())->pluck('query')->implode(' ');
        DB::disableQueryLog();
        $this->assertStringNotContainsString('device_movements', $queries);
    }

    public function test_receive_assign_and_return_sync_customer_and_record_history(): void
    {
        $device = $this->device();
        $customer = $this->customer();
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $this->assertDatabaseHas('devices', ['id' => $device->id, 'status' => 'INSTALLED', 'customer_id' => $customer->id]);
        $this->assertDatabaseHas('customers', ['id' => $customer->id, 'ont_serial_number' => $device->serial_number, 'ont_model' => 'Test model']);
        $this->get('/customers/'.$customer->id)->assertInertia(fn ($p) => $p->component('Customers/Show')->has('customer.devices', 1));
        $this->post('/devices/'.$device->id.'/transition', ['action' => 'RETURN', 'status' => 'DAMAGED', 'location' => 'Meja servis', 'notes' => 'Adaptor rusak'])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('devices', ['id' => $device->id, 'status' => 'DAMAGED', 'customer_id' => null, 'location' => 'Meja servis']);
        $this->assertDatabaseHas('customers', ['id' => $customer->id, 'ont_serial_number' => null, 'ont_model' => null]);
        $this->assertSame(3, DB::table('device_movements')->where('device_id', $device->id)->count());
        $this->assertDatabaseHas('audit_logs', ['model' => 'Device', 'model_id' => $device->id, 'action' => 'RETURN']);
    }

    public function test_serials_are_normalized_unique_and_creation_cannot_assign(): void
    {
        $device = $this->device();
        $this->post('/devices', ['asset_tag' => uniqid(), 'serial_number' => strtolower($device->serial_number), 'type' => 'ONT', 'location' => 'Gudang'])->assertSessionHasErrors('serial_number');
        $this->post('/devices', ['asset_tag' => uniqid(), 'serial_number' => uniqid(), 'type' => 'INVALID', 'location' => 'Gudang'])->assertSessionHasErrors('type');
        $this->assertSame('IN_STOCK', $device->status);
    }

    public function test_device_cannot_be_double_assigned_and_customer_has_only_one_ont(): void
    {
        $device = $this->device();
        $other = $this->device();
        $customer = $this->customer();
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $this->assign($device, $this->customer())->assertSessionHasErrors('device');
        $this->assign($other, $customer)->assertSessionHasErrors('device');
        $this->assertSame('IN_STOCK', $other->fresh()->status);
        $this->assertSame(1, DB::table('device_movements')->where('device_id', $device->id)->where('action', 'ASSIGN')->count());
    }

    public function test_damaged_asset_must_return_to_stock_before_installation(): void
    {
        $device = $this->device();
        $this->post('/devices/'.$device->id.'/transition', ['action' => 'STATUS', 'status' => 'DAMAGED', 'location' => 'Servis'])->assertSessionHasNoErrors();
        $customer = $this->customer();
        $this->assign($device, $customer)->assertSessionHasErrors('device');
        $this->post('/devices/'.$device->id.'/transition', ['action' => 'STATUS', 'status' => 'IN_STOCK', 'location' => 'Gudang'])->assertSessionHasNoErrors();
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $this->post('/devices/'.$device->id.'/transition', ['action' => 'STATUS', 'status' => 'RETIRED', 'location' => 'Gudang'])->assertSessionHasErrors('device');
    }

    public function test_managed_ont_cannot_be_overwritten_or_customer_deleted(): void
    {
        $device = $this->device();
        $customer = $this->customer();
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $this->put('/customers/'.$customer->id, ['ont_serial_number' => 'DIFFERENT'])->assertSessionHasErrors('ont_serial_number');
        $this->delete('/customers/'.$customer->id)->assertSessionHasErrors('customer');
        $this->put('/devices/'.$device->id, ['model' => 'Changed'])->assertUnprocessable();
        $this->assertSame($device->serial_number, $customer->fresh()->ont_serial_number);
    }

    public function test_legacy_serial_conflicts_are_explicit_and_matching_serial_can_be_linked(): void
    {
        $customer = $this->customer();
        $customer->update(['ont_serial_number' => 'LEGACY-SERIAL']);
        $device = $this->device();
        $this->assign($device, $customer)->assertSessionHasErrors('device');
        $this->post('/devices', ['asset_tag' => uniqid(), 'serial_number' => 'LEGACY-SERIAL', 'type' => 'ONT', 'location' => 'Gudang'])->assertSessionHasNoErrors();
        $legacy = Device::where('serial_number', 'LEGACY-SERIAL')->firstOrFail();
        $this->assign($legacy, $customer)->assertSessionHasNoErrors();
    }

    public function test_statistics_filters_and_router_do_not_change_ont_fields(): void
    {
        $customer = $this->customer();
        $device = $this->device('ROUTER');
        $this->assign($device, $customer)->assertSessionHasNoErrors();
        $this->assertNull($customer->fresh()->ont_serial_number);
        $installed = Device::where('status', 'INSTALLED')->count();
        $this->get('/devices?search='.$device->serial_number)->assertInertia(fn ($p) => $p->component('Devices/Index')->where('devices.total', 1)->where('summary.INSTALLED', $installed)->has('trend', 6));
        $this->get('/devices?customer_id='.$customer->id)->assertInertia(fn ($p) => $p->where('devices.total', 1)->where('selectedCustomer.id', $customer->id));
        $this->get('/devices?status=IN_STOCK&search='.$device->serial_number)->assertInertia(fn ($p) => $p->where('devices.total', 0)->where('summary.INSTALLED', $installed));
        $this->getJson('/devices/customer-options?search='.$customer->customer_id)->assertOk()->assertJsonFragment(['id' => $customer->id]);
    }

    public function test_viewer_cannot_write_or_search_customer_assignment_options(): void
    {
        $device = $this->device();
        auth()->user()->syncRoles('VIEWER');
        $this->get('/devices')->assertOk();
        $this->post('/devices', [])->assertForbidden();
        $this->put('/devices/'.$device->id, [])->assertForbidden();
        $this->post('/devices/'.$device->id.'/transition', [])->assertForbidden();
        $this->getJson('/devices/customer-options?search=Inventory')->assertForbidden();
    }
}
