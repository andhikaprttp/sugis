<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class ElevationTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        Cache::flush();
        Http::preventStrayRequests();
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'Elevation', 'email' => uniqid().'@test.invalid', 'password' => 'Test-password-123']);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
    }

    public function test_null_elevation_is_preserved_and_result_cached(): void
    {
        Http::fake(['api.opentopodata.org/*' => Http::response(['status' => 'OK', 'results' => [['elevation' => 25], ['elevation' => null]]])]);
        $data = ['points' => [[-6.3, 106.7], [-6.31, 106.71]]];
        $this->postJson('/map/elevation', $data)->assertOk()->assertJsonPath('elevations.0', 25)->assertJsonPath('elevations.1', null);
        $this->postJson('/map/elevation', $data)->assertOk();
        Http::assertSentCount(1);
    }

    public function test_invalid_coordinates_and_cs_are_rejected(): void
    {
        $this->postJson('/map/elevation', ['points' => [[90, 0], [0, 0]]])->assertUnprocessable();
        auth()->user()->syncRoles(['CUSTOMER_SERVICE']);
        $this->postJson('/map/elevation', ['points' => [[0, 0], [1, 1]]])->assertForbidden();
        Http::assertNothingSent();
    }

    public function test_incomplete_provider_response_never_fabricates_heights(): void
    {
        Http::fake(['*' => Http::response(['status' => 'OK', 'results' => [['elevation' => 20]]])]);
        $this->postJson('/map/elevation', ['points' => [[0, 0], [1, 1]]])->assertStatus(503);
        $this->postJson('/map/elevation', ['points' => [[0, 0], [2, 2]]])->assertStatus(429);
        Http::assertSentCount(1);
    }
}
