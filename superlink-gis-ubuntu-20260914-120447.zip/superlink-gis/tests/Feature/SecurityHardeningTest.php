<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class SecurityHardeningTest extends TestCase
{
    use DatabaseTransactions;

    private function admin(): User
    {
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Security', 'email' => uniqid().'@test.invalid', 'password' => 'Security-Test-Password', 'active' => true]);
        $user->assignRole('ADMIN');
        $this->actingAs($user);

        return $user;
    }

    public function test_disabled_authenticated_user_loses_api_access(): void
    {
        $user = $this->admin();
        $user->update(['active' => false]);
        $this->getJson('/api/map/objects')->assertUnauthorized();
        $this->assertGuest();
    }

    public function test_login_has_security_headers_and_cannot_be_cached(): void
    {
        $this->get('/login')->assertOk()
            ->assertHeader('X-Content-Type-Options', 'nosniff')
            ->assertHeader('X-Frame-Options', 'SAMEORIGIN')
            ->assertHeader('Content-Security-Policy', "base-uri 'self'; object-src 'none'; frame-ancestors 'self'")
            ->assertHeader('Cache-Control', 'no-store, private');
    }

    public function test_map_rejects_malformed_filters_before_database_queries(): void
    {
        $this->admin();
        foreach (['area_id=not-a-uuid', 'search[]=value', 'bbox[]=1', 'bbox=0,0,181,90', 'bbox=0,0,1e309,90', 'bbox=0,10,1,0'] as $query) {
            $this->getJson('/api/map/objects?'.$query)->assertUnprocessable();
        }
        $this->getJson('/api/map/objects?search='.urlencode("' OR 1=1 --"))->assertOk()->assertJsonCount(0, 'data');
        $this->postJson('/api/gis-objects', ['object_type' => ['POP']])->assertUnprocessable();
        $this->postJson('/api/gis-objects', ['object_type' => 'POP', 'geometry' => 'invalid'])->assertUnprocessable();
    }

    public function test_login_ip_limit_survives_email_rotation(): void
    {
        for ($i = 0; $i < 30; $i++) {
            $this->postJson('/login', ['email' => "rotate-$i@test.invalid", 'password' => 'incorrect'])->assertUnprocessable();
        }
        $this->postJson('/login', ['email' => 'another@test.invalid', 'password' => 'incorrect'])->assertStatus(429);
    }

    public function test_api_requires_authentication_and_real_csrf_validation(): void
    {
        $this->getJson('/api/map/objects')->assertUnauthorized();
        $this->admin();
        // Laravel bypasses CSRF during tests; switch only the environment binding
        // after boot, keeping the test database and transactional connection.
        $this->app->instance('env', 'local');
        $this->postJson('/api/gis-objects', ['object_type' => 'POP', 'name' => 'CSRF probe'])->assertStatus(419);
    }
}
