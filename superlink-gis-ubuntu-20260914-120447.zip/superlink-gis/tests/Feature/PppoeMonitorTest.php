<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\Customer\CustomerService;
use App\Services\Monitoring\PppoeMonitor;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class PppoeMonitorTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        config(['monitoring.driver' => 'mikrotik', 'monitoring.url' => 'https://router.test', 'monitoring.username' => 'reader', 'monitoring.password' => 'private-password']);
        Http::preventStrayRequests();
    }

    private function customer(string $name)
    {
        return app(CustomerService::class)->save(['customer_id' => $name, 'name' => $name, 'status' => 'ACTIVE', 'pppoe_username' => $name]);
    }

    private function fake(): void
    {
        Http::fake(fn ($r) => Http::response(str_contains($r->url(), 'ppp/secret') ? [['name' => 'online', 'service' => 'pppoe'], ['name' => 'offline', 'service' => 'pppoe']] : [['name' => 'online', 'service' => 'pppoe', 'address' => '10.2.0.4', 'uptime' => '1h']], 200));
    }

    public function test_up_down_unknown_and_readonly_requests(): void
    {
        $this->customer('online');
        $this->customer('offline');
        $this->customer('radius-not-listed');
        $this->fake();
        $m = app(PppoeMonitor::class);
        $m->sync();
        $this->assertSame(['UP' => 1, 'DOWN' => 1, 'UNKNOWN' => 1], $m->summary()['counts']);
        Http::assertSentCount(2);
        Http::assertNotSent(fn ($r) => $r->method() !== 'GET');
        Http::assertSent(fn ($r) => str_contains($r->url(), 'ppp/secret') && $r['.proplist'] === 'name,service');
        $this->assertStringNotContainsString('private-password', json_encode($m->summary()));
        $this->assertDatabaseCount('pppoe_history', 1);
    }

    public function test_failed_poll_preserves_last_state_then_stales_to_unknown(): void
    {
        $this->customer('online');
        $fail = false;
        Http::fake(function ($r) use (&$fail) {
            return $fail ? Http::response('', 503) : Http::response([['name' => 'online', 'service' => 'pppoe']], 200);
        });
        $m = app(PppoeMonitor::class);
        $m->sync();
        $fail = true;
        try {
            $m->sync();
            $this->fail('must fail');
        } catch (\RuntimeException $e) {
        }
        $this->assertDatabaseHas('pppoe_snapshots', ['state' => 'UP']);
        $this->assertDatabaseCount('pppoe_history', 1);
        $this->travel(6)->minutes();
        $this->assertSame(1, $m->summary()['counts']['UNKNOWN']);
        $this->travelBack();
    }

    public function test_username_change_duplicate_and_disabled_connector_invalidate_status(): void
    {
        $c = $this->customer('online');
        $this->fake();
        $m = app(PppoeMonitor::class);
        $m->sync();
        $c->update(['pppoe_username' => 'changed']);
        $this->assertSame(1, $m->summary()['counts']['UNKNOWN']);
        $c->update(['pppoe_username' => 'online']);
        $d = $this->customer('second');
        $d->update(['pppoe_username' => 'online']);
        $this->assertSame(2, $m->summary()['counts']['UNKNOWN']);
        config(['monitoring.driver' => 'none']);
        $this->assertFalse($m->summary()['configured']);
        $this->assertSame(0, $m->summary()['counts']['DOWN']);
    }

    public function test_cs_can_read_dashboard_but_cannot_poll_or_see_router_credentials(): void
    {
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'CS', 'email' => uniqid().'@test.invalid', 'password' => 'Role-test-password']);
        $u->assignRole('CUSTOMER_SERVICE');
        $this->actingAs($u);
        $this->get('/dashboard')->assertOk()->assertDontSee('private-password')->assertDontSee('router.test');
        $this->post('/monitoring/pppoe/sync')->assertForbidden();
        Http::assertNothingSent();
    }
}
