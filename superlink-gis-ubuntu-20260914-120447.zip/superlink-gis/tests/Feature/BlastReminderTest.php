<?php

namespace Tests\Feature;

use App\Jobs\SendBlastDelivery;
use App\Models\BlastCampaign;
use App\Models\BlastDelivery;
use App\Models\User;
use App\Services\Blast\ReminderDispatcher;
use App\Services\Blast\ScheduleBuilder;
use App\Services\Blast\WhatsAppSender;
use Carbon\Carbon;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class BlastReminderTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Reminder tester', 'email' => uniqid().'@test.invalid', 'password' => 'Test-password', 'active' => true]);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
        $this->travelTo(Carbon::parse('2030-06-05T09:00:00+07:00'));
        config(['blast.driver' => 'fonnte', 'blast.token' => 'fake-secret', 'queue.default' => 'sync']);
        Http::preventStrayRequests();
        Http::fake(['api.fonnte.com/*' => Http::response(['status' => true, 'id' => ['fake-id']])]);
    }

    private function payload(): array
    {
        return ['name' => 'June invoice', 'template' => 'Halo {NAME}: {INVOICE} {AMOUNT} {LINK}', 'schedule' => ['month' => '2030-06', 'time' => '09:00', 'mode' => 'dates', 'count' => 2, 'days' => [15, 25]], 'recipients' => [['name' => 'Tester', 'phone' => '081234567890', 'invoice' => 'INV1', 'amount' => 'Rp150.000', 'selected' => true]]];
    }

    private function campaign(): BlastCampaign
    {
        $c = BlastCampaign::create(['name' => 'Due now', 'template' => 'Halo {NAME}', 'schedule' => $this->payload()['schedule'], 'occurrences' => [now()->toIso8601String()], 'enabled' => true, 'created_by' => auth()->id()]);
        $c->recipients()->create(['name' => 'Tester', 'phone' => '6281234567890', 'invoice' => 'INV1', 'selected' => true]);

        return $c;
    }

    public function test_draft_normalizes_phone_and_never_sends_or_exposes_token(): void
    {
        $this->post('/blast', $this->payload())->assertSessionHasNoErrors()->assertRedirect();
        $c = BlastCampaign::where('name', 'June invoice')->firstOrFail();
        $this->assertFalse($c->enabled);
        $this->assertSame('6281234567890', $c->recipients->first()->phone);
        $this->get('/blast')->assertOk()->assertDontSee('fake-secret');
        $this->get('/blast/'.$c->id)->assertOk()->assertDontSee('fake-secret');
        Http::assertNothingSent();
    }

    public function test_csv_import_and_bad_csv_validation(): void
    {
        $csv = "Customer Name,Customer Phone,Invoice Number,Total Amount,Expired Date,Payment Link\nTester,081234567890,INV1,150000,2030-06-10,https://example.com/pay\n";
        $this->postJson('/blast/csv', ['file' => UploadedFile::fake()->createWithContent('doku.csv', $csv)])->assertOk()->assertJsonPath('recipients.0.phone', '6281234567890')->assertJsonCount(1, 'recipients');
        $this->postJson('/blast/csv', ['file' => UploadedFile::fake()->createWithContent('bad.csv', 'wrong,headers')])->assertUnprocessable();
        Http::assertNothingSent();
    }

    public function test_invalid_dates_duplicates_and_unsafe_links_are_rejected(): void
    {
        $data = $this->payload();
        $data['recipients'][] = $data['recipients'][0];
        $this->postJson('/blast', $data)->assertUnprocessable();
        $data = $this->payload();
        $data['recipients'][0]['link'] = 'javascript:alert(1)';
        $this->postJson('/blast', $data)->assertUnprocessable();
        $data = $this->payload();
        $data['schedule']['days'] = [1, 25];
        $this->postJson('/blast', $data)->assertUnprocessable();
        Http::assertNothingSent();
    }

    public function test_intervals_stay_in_month_and_use_wib(): void
    {
        $builder = app(ScheduleBuilder::class);
        $data = ['month' => '2032-02', 'time' => '09:00', 'mode' => 'interval', 'count' => 3, 'start_day' => 15, 'interval_days' => 7];
        $this->assertSame(['2032-02-15T09:00:00+07:00', '2032-02-22T09:00:00+07:00', '2032-02-29T09:00:00+07:00'], $builder->build($data));
        $data['month'] = '2030-02';
        $this->expectException(ValidationException::class);
        $builder->build($data);
    }

    public function test_disabled_api_blocks_activation_and_manual_send(): void
    {
        $c = $this->campaign();
        config(['blast.driver' => 'disabled']);
        $this->postJson('/blast/'.$c->id.'/enabled', ['enabled' => true])->assertUnprocessable();
        $this->postJson('/blast/'.$c->id.'/recipients/'.$c->recipients->first()->id.'/send', ['request_id' => (string) Str::uuid()])->assertUnprocessable();
        Http::assertNothingSent();
    }

    public function test_repeated_scheduler_ticks_send_once_at_correct_instant(): void
    {
        $c = $this->campaign();
        app(ReminderDispatcher::class)->tick();
        app(ReminderDispatcher::class)->tick();
        $d = BlastDelivery::where('recipient_id', $c->recipients->first()->id)->sole();
        $this->assertSame('ACCEPTED', $d->status);
        $this->assertSame(now()->timestamp, $d->scheduled_at->timestamp);
        Http::assertSentCount(1);
        Http::assertSent(fn ($r) => $r->url() === 'https://api.fonnte.com/send' && $r['target'] === '6281234567890' && $r['message'] === 'Halo Tester' && $r->hasHeader('Authorization', 'fake-secret'));
    }

    public function test_paid_paused_removed_slot_and_revoked_sender_cancel_queued_jobs(): void
    {
        Queue::fake();
        foreach (['paid', 'paused', 'removed', 'revoked'] as $scenario) {
            $c = $this->campaign();
            app(ReminderDispatcher::class)->tick();
            $d = BlastDelivery::where('recipient_id', $c->recipients->first()->id)->sole();
            if ($scenario === 'paid') {
                $c->recipients->first()->update(['paid' => true]);
            }
            if ($scenario === 'paused') {
                $c->update(['enabled' => false]);
            }
            if ($scenario === 'removed') {
                $c->update(['occurrences' => [now()->addDay()->toIso8601String()]]);
            }
            if ($scenario === 'revoked') {
                auth()->user()->update(['active' => false]);
            }
            (new SendBlastDelivery($d->id))->handle(app(WhatsAppSender::class));
            $this->assertSame('CANCELLED', $d->fresh()->status, $scenario);
        }
        Http::assertNothingSent();
    }

    public function test_unknown_response_is_not_retried(): void
    {
        Http::swap(new Factory);
        Http::preventStrayRequests();
        Http::fake(['api.fonnte.com/*' => Http::response('gateway error', 502)]);
        $c = $this->campaign();
        app(ReminderDispatcher::class)->tick();
        app(ReminderDispatcher::class)->tick();
        $this->assertSame('UNKNOWN', BlastDelivery::where('recipient_id', $c->recipients->first()->id)->sole()->status);
        Http::assertSentCount(1);
    }

    public function test_expired_and_future_schedules_do_not_send(): void
    {
        $c = $this->campaign();
        $c->update(['occurrences' => [now()->subHours(2)->toIso8601String(), now()->addDay()->toIso8601String()]]);
        app(ReminderDispatcher::class)->tick();
        $this->assertSame('EXPIRED', BlastDelivery::where('recipient_id', $c->recipients->first()->id)->sole()->status);
        Http::assertNothingSent();
    }

    public function test_manual_request_is_idempotent_and_recipient_must_belong_to_campaign(): void
    {
        $c = $this->campaign();
        $c->update(['enabled' => false]);
        $r = $c->recipients->first();
        $id = (string) Str::uuid();
        foreach ([1, 2] as $n) {
            $this->post('/blast/'.$c->id.'/recipients/'.$r->id.'/send', ['request_id' => $id])->assertSessionHasNoErrors();
        }
        $this->assertSame(1, BlastDelivery::where('recipient_id', $r->id)->count());
        $other = $this->campaign();
        $this->putJson('/blast/'.$other->id.'/recipients/'.$r->id, ['paid' => true])->assertNotFound();
        app(ReminderDispatcher::class)->tick();
        $this->assertSame('ACCEPTED', BlastDelivery::where('recipient_id', $r->id)->sole()->status);
    }

    public function test_viewer_cannot_create_or_send(): void
    {
        $c = $this->campaign();
        auth()->user()->syncRoles(['VIEWER']);
        $this->get('/blast')->assertOk();
        $this->postJson('/blast', $this->payload())->assertForbidden();
        $this->postJson('/blast/'.$c->id.'/enabled', ['enabled' => true])->assertForbidden();
        Http::assertNothingSent();
    }

    public function test_network_failure_is_unknown_and_does_not_leak_secrets(): void
    {
        Http::swap(new Factory);
        Http::preventStrayRequests();
        Http::fake(fn () => throw new ConnectionException('fake-secret'));
        $result = app(WhatsAppSender::class)->send('6281234567890', 'Test');
        $this->assertSame('UNKNOWN', $result['status']);
        $this->assertStringNotContainsString('fake-secret', $result['error']);
    }

    public function test_schedule_requires_pause_and_cancels_removed_pending_slots(): void
    {
        Queue::fake();
        $c = $this->campaign();
        app(ReminderDispatcher::class)->tick();
        $data = ['schedule' => $this->payload()['schedule'], 'template' => 'Updated'];
        $this->putJson('/blast/'.$c->id.'/schedule', $data)->assertUnprocessable();
        $this->post('/blast/'.$c->id.'/enabled', ['enabled' => false])->assertSessionHasNoErrors();
        $this->put('/blast/'.$c->id.'/schedule', $data)->assertSessionHasNoErrors();
        $this->assertSame('CANCELLED', BlastDelivery::where('recipient_id', $c->recipients->first()->id)->sole()->status);
        Http::assertNothingSent();
    }
}
