<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class CustomerServiceRoleTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'CS', 'email' => uniqid().'@test.invalid', 'password' => 'Role-test-password']);
        $user->assignRole('CUSTOMER_SERVICE');
        $this->actingAs($user);
    }

    public function test_cs_gets_customer_dashboard_and_customer_pages_only(): void
    {
        $this->get('/dashboard')->assertInertia(fn ($p) => $p->component('Dashboard/CustomerService')->missing('objects')->missing('ports')->missing('surveys'));
        foreach (['/customers', '/customers/create', '/customers/import', '/customers/export'] as $path) {
            $this->get($path)->assertOk();
        }
        foreach (['/map', '/network/pops', '/network/odps', '/surveys', '/zones', '/operations/monitoring', '/operations/actions', '/operations/connection', '/reports', '/audit-logs', '/settings', '/gis/import', '/api/map/objects'] as $path) {
            $this->get($path)->assertForbidden();
        }
        $this->post('/cdata/sync')->assertForbidden();
        $this->post('/settings/users', [])->assertForbidden();
        $this->assertFalse(auth()->user()->can('customer.delete'));
    }

    public function test_admin_can_assign_existing_user_and_cs_cannot_escalate(): void
    {
        $cs = auth()->user();
        $this->put('/settings/users/'.$cs->id.'/role', ['role' => 'ADMIN'])->assertForbidden();
        $admin = User::create(['name' => 'Admin', 'email' => uniqid().'@test.invalid', 'password' => 'Admin-test-password']);
        $admin->assignRole('ADMIN');
        $this->actingAs($admin);
        $this->put('/settings/users/'.$cs->id.'/role', ['role' => 'CUSTOMER_SERVICE'])->assertSessionHasNoErrors();
        $this->assertTrue($cs->fresh()->hasRole('CUSTOMER_SERVICE'));
        $this->put('/settings/users/'.$admin->id.'/role', ['role' => 'CUSTOMER_SERVICE'])->assertUnprocessable();
        $this->post('/settings/users', ['name' => 'New CS', 'email' => 'new-cs@test.invalid', 'password' => 'Strong-test-password', 'role' => 'CUSTOMER_SERVICE'])->assertSessionHasNoErrors();
        $this->assertTrue(User::where('email', 'new-cs@test.invalid')->firstOrFail()->hasRole('CUSTOMER_SERVICE'));
    }
}
