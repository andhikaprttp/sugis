<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\Device;
use App\Models\ServicePackage;
use App\Models\User;
use App\Services\Customer\CustomerService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class OntImportAndPackagesTest extends TestCase
{
    use DatabaseTransactions;

    private const SERIALS = "YEKGCB923474\nYEKGCBF47032\nYEKGCBBE6D04\nYEKGCBC00662\nYEKGCBF80000\nYEKGCB3D5F23\nYEKGCB12CA80\nYEKGCBF06D30";

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Import tester', 'email' => uniqid().'@test.invalid', 'password' => 'Import-test-password']);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
    }

    private function customer(): Customer
    {
        return app(CustomerService::class)->save(['name' => 'Package customer', 'customer_id' => uniqid('PACKAGE-')]);
    }

    private function package(): ServicePackage
    {
        return ServicePackage::create(['name' => 'Internet '.uniqid(), 'speed_mbps' => 30, 'price' => '150000.00', 'active' => true]);
    }

    public function test_eight_plain_text_serials_are_counted_imported_and_assignable(): void
    {
        $this->postJson('/devices/import-serials/preview', ['serials' => self::SERIALS])->assertOk()->assertJsonPath('unique', 8)->assertJsonCount(8, 'ready');
        $before = Device::where('status', 'IN_STOCK')->count();
        $this->post('/devices/import-serials', ['serials' => self::SERIALS, 'location' => 'Gudang', 'vendor' => 'Test vendor'])->assertSessionHasNoErrors()->assertRedirect('/devices?type=ONT&status=IN_STOCK');
        $this->assertSame($before + 8, Device::where('status', 'IN_STOCK')->count());
        $device = Device::where('serial_number', 'YEKGCB923474')->firstOrFail();
        $customer = $this->customer();
        $this->post('/devices/'.$device->id.'/transition', ['action' => 'ASSIGN', 'customer_id' => $customer->id])->assertSessionHasNoErrors();
        $this->assertSame($device->serial_number, $customer->fresh()->ont_serial_number);
        $this->assertDatabaseHas('device_movements', ['device_id' => $device->id, 'action' => 'RECEIVE']);
        $this->assertDatabaseHas('device_movements', ['device_id' => $device->id, 'action' => 'ASSIGN']);
    }

    public function test_markdown_duplicates_and_repeated_import_do_not_inflate_stock(): void
    {
        $text = "| yekgcb923474 |\n| ------------ |\n| YEKGCB923474 |\n| YEKGCBF47032 |";
        $this->postJson('/devices/import-serials/preview', ['serials' => $text])->assertJsonPath('duplicates', 1)->assertJsonCount(2, 'ready');
        foreach (range(1, 2) as $i) {
            $this->post('/devices/import-serials', ['serials' => $text, 'location' => 'Gudang'])->assertSessionHasNoErrors();
        }
        $this->assertSame(2, Device::whereIn('serial_number', ['YEKGCB923474', 'YEKGCBF47032'])->count());
        $this->postJson('/devices/import-serials/preview', ['serials' => $text])->assertJsonCount(2, 'existing')->assertJsonCount(0, 'ready');
    }

    public function test_invalid_input_rejects_entire_import(): void
    {
        $before = Device::count();
        $this->post('/devices/import-serials', ['serials' => "VALID123\nbad!", 'location' => 'Gudang'])->assertSessionHasErrors('serials');
        $this->assertSame($before, Device::count());
        $this->postJson('/devices/import-serials/preview', ['serials' => ['bad']])->assertUnprocessable();
        $this->postJson('/devices/import-serials/preview', ['serials' => str_repeat("SN123\n", 1001)])->assertUnprocessable();
    }

    public function test_package_selection_copies_server_price_and_preserves_existing_subscription(): void
    {
        $package = $this->package();
        $customer = $this->customer();
        $this->put('/customers/'.$customer->id, ['package_id' => $package->id, 'package_price' => '1.00'])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('customers', ['id' => $customer->id, 'package_id' => $package->id, 'package_name' => $package->name, 'package_speed' => 30, 'package_price' => '150000.00']);
        $this->put('/packages/'.$package->id, ['name' => $package->name, 'speed_mbps' => 50, 'price' => 200000, 'active' => true])->assertSessionHasNoErrors();
        $this->assertEquals('150000.00', $customer->fresh()->package_price);
        $this->put('/customers/'.$customer->id, ['name' => 'Updated name'])->assertSessionHasNoErrors();
        $this->put('/customers/'.$customer->id, ['package_name' => 'Forged'])->assertSessionHasErrors('package_id');
        $this->put('/customers/'.$customer->id, ['package_id' => $package->id])->assertSessionHasNoErrors();
        $this->assertEquals('200000.00', $customer->fresh()->package_price);
        $this->get('/customers/'.$customer->id)->assertOk();
    }

    public function test_package_options_search_excludes_inactive_and_cannot_assign_inactive(): void
    {
        $package = $this->package();
        $this->getJson('/packages/options?search='.urlencode($package->name))->assertOk()->assertJsonCount(1)->assertJsonFragment(['id' => $package->id]);
        $package->update(['active' => false]);
        $this->getJson('/packages/options?search='.urlencode($package->name))->assertOk()->assertJsonCount(0);
        $this->put('/customers/'.$this->customer()->id, ['package_id' => $package->id])->assertSessionHasErrors('package_id');
    }

    public function test_catalog_permissions_and_price_validation(): void
    {
        $this->post('/packages', ['name' => 'Invalid', 'speed_mbps' => 30, 'price' => -1, 'active' => true])->assertSessionHasErrors('price');
        $this->post('/packages', ['name' => 'Starter', 'speed_mbps' => 20, 'price' => 125000, 'active' => true])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('service_packages', ['name' => 'Starter', 'price' => '125000.00']);
        $this->get('/packages')->assertOk();
        $this->get('/devices/import-serials')->assertOk();
        auth()->user()->syncRoles('CUSTOMER_SERVICE');
        $this->getJson('/packages/options')->assertOk();
        $this->post('/packages', [])->assertForbidden();
        $this->post('/devices/import-serials', ['serials' => self::SERIALS, 'location' => 'Gudang'])->assertForbidden();
        auth()->user()->syncRoles('VIEWER');
        $this->getJson('/packages/options')->assertForbidden();
    }
}
