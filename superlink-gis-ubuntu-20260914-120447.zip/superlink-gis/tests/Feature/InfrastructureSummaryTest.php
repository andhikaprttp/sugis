<?php

namespace Tests\Feature;

use App\Models\GisObject;
use App\Models\User;
use App\Services\Network\InfrastructureSummary;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Inertia\Testing\AssertableInertia as Assert;
use Tests\TestCase;

class InfrastructureSummaryTest extends TestCase
{
    use DatabaseTransactions;

    private function asset(string $type, ?string $point): GisObject
    {
        $object = GisObject::create(['name' => 'Pole count fixture', 'code' => (string) Str::uuid(), 'object_type' => $type, 'status' => 'ACTIVE']);
        if ($point !== null) {
            DB::update('UPDATE gis_objects SET geometry = ST_GeomFromText(?,4326) WHERE id = ?', [$point, $object->id]);
        }

        return $object;
    }

    public function test_exact_coordinates_count_once_and_deleted_objects_are_excluded(): void
    {
        $before = app(InfrastructureSummary::class)->poleCount();
        $pole = $this->asset('POLE', 'POINT(10.1234567 20.1234567)');
        $odp = $this->asset('ODP', 'POINT(10.1234567 20.1234567)');
        $this->asset('ODC', 'POINT(10.1234567 20.1234567)');
        $this->asset('ODP', 'POINT(10.1234568 20.1234567)');
        $this->asset('CLOSURE', 'POINT(11 21)');
        $this->asset('POLE', 'POINT(12 22)')->delete();
        $this->assertSame($before + 2, app(InfrastructureSummary::class)->poleCount());
        $pole->delete();
        $odp->delete();
        $this->assertSame($before + 2, app(InfrastructureSummary::class)->poleCount());
        $this->asset('ODP', null);
        $this->asset('ODC', null);
        $this->assertSame($before + 4, app(InfrastructureSummary::class)->poleCount());
    }

    public function test_dashboard_exposes_physical_total_without_changing_asset_counts(): void
    {
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Counter', 'email' => uniqid().'@test.invalid', 'password' => 'Test-password', 'active' => true]);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
        $this->asset('ODC', 'POINT(15.87654 25.87654)');
        $this->get('/dashboard')->assertOk()->assertInertia(fn (Assert $page) => $page
            ->component('Dashboard/Index')
            ->where('poleCount', app(InfrastructureSummary::class)->poleCount())
            ->where('objects.ODC', GisObject::where('object_type', 'ODC')->count()));
    }
}
