<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\Device;
use App\Models\GisObject;
use App\Models\User;
use App\Services\Customer\CustomerService;
use App\Services\Network\NetworkService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class GlobalSearchTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Search tester', 'email' => uniqid().'@test.invalid', 'password' => 'Search-test-password', 'active' => true]);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
        app(CustomerService::class)->save(['name' => 'SearchProbe customer', 'customer_id' => 'SEARCH-PROBE', 'address' => 'SearchProbe village']);
        foreach (['ODP', 'ODC'] as $type) {
            app(NetworkService::class)->save(['name' => 'SearchProbe '.$type, 'code' => 'SearchProbe-'.$type, 'object_type' => $type, 'capacity' => 8, 'geometry' => ['type' => 'Point', 'coordinates' => [106.76, -6.37]]]);
        }
        DB::table('provisioning_olts')->insert(['name' => 'SearchProbe OLT', 'external_id' => 'SearchProbe-OLT', 'host' => '10.200.1.1', 'created_at' => now(), 'updated_at' => now()]);
        Device::create(['asset_tag' => 'SearchProbe-asset', 'serial_number' => 'SearchProbe-SN', 'type' => 'ONT', 'status' => 'IN_STOCK', 'location' => 'Gudang']);
    }

    public function test_search_finds_all_categories_and_destination_links_resolve(): void
    {
        $response = $this->getJson('/api/search?q=searchprobe')->assertOk()->assertJsonCount(5, 'groups');
        foreach ($response->json('groups') as $group) {
            $this->assertCount(1, $group['items']);
            $this->assertFalse($group['has_more']);
            $this->get($group['items'][0]['url'])->assertOk();
        }
        $this->get('/dashboard')->assertOk();
    }

    public function test_customer_service_cannot_discover_infrastructure(): void
    {
        auth()->user()->syncRoles('CUSTOMER_SERVICE');
        $this->getJson('/api/search?q=SearchProbe')->assertOk()->assertJsonCount(1, 'groups')->assertJsonPath('groups.0.key', 'customers');
        auth()->user()->syncRoles([]);
        auth()->user()->givePermissionTo('dashboard.view');
        $this->getJson('/api/search?q=SearchProbe')->assertOk()->assertExactJson(['groups' => []]);
        auth()->logout();
        $this->getJson('/api/search?q=SearchProbe')->assertUnauthorized();
    }

    public function test_invalid_queries_and_wildcards_do_not_expand_results(): void
    {
        foreach (['q[]=x', 'q=a', 'q=%20%20', 'q='.str_repeat('x', 101)] as $query) {
            $this->getJson('/api/search?'.$query)->assertUnprocessable();
        }
        foreach (['%_', "' OR 1=1 --"] as $query) {
            $response = $this->getJson('/api/search?q='.urlencode($query))->assertOk();
            foreach ($response->json('groups') as $group) {
                $this->assertEmpty($group['items']);
            }
        }
    }

    public function test_deleted_objects_are_hidden_and_results_are_bounded(): void
    {
        Customer::where('customer_id', 'SEARCH-PROBE')->delete();
        GisObject::where('object_type', 'ODP')->where('name', 'like', 'SearchProbe%')->delete();
        foreach (range(1, 7) as $n) {
            Device::create(['asset_tag' => 'SearchProbe-'.$n, 'serial_number' => 'EXTRA-'.$n, 'type' => 'ONT', 'status' => 'IN_STOCK', 'location' => 'Gudang']);
        }
        $groups = collect($this->getJson('/api/search?q=SearchProbe')->assertOk()->json('groups'))->keyBy('key');
        $this->assertEmpty($groups['customers']['items']);
        $this->assertEmpty($groups['odp']['items']);
        $this->assertCount(5, $groups['devices']['items']);
        $this->assertTrue($groups['devices']['has_more']);
    }

    public function test_stock_zero_query_and_array_input_are_handled_correctly(): void
    {
        $device = Device::create(['asset_tag' => 'ZERO-0', 'serial_number' => 'SERIAL-WITHOUT-DIGITS', 'type' => 'ONT', 'status' => 'IN_STOCK', 'location' => 'Gudang']);
        $this->get('/devices?search=0')->assertInertia(fn ($p) => $p->where('devices.total', 1)->where('devices.data.0.id', $device->id));
        $this->postJson('/devices', ['asset_tag' => ['bad'], 'serial_number' => ['bad'], 'type' => 'ONT', 'location' => 'Gudang'])->assertUnprocessable();
    }

    public function test_olt_search_and_id_links_filter_the_actual_olt_list(): void
    {
        $id = DB::table('provisioning_olts')->where('external_id', 'SearchProbe-OLT')->value('id');
        DB::table('provisioning_olts')->insert(['name' => 'Different OLT', 'external_id' => 'OTHER-OLT', 'host' => '10.200.1.2', 'created_at' => now(), 'updated_at' => now()]);
        $this->get('/operations/olts?search=SearchProbe')->assertInertia(fn ($p) => $p->has('olts', 1)->where('olts.0.id', $id));
        $this->get('/operations/olts?olt_id='.$id)->assertInertia(fn ($p) => $p->has('olts', 1)->where('olts.0.id', $id));
    }
}
