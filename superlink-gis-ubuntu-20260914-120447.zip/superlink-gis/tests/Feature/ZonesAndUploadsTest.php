<?php

namespace Tests\Feature;

use App\Models\CustomerImportJob;
use App\Models\GisObject;
use App\Models\ImportJob;
use App\Models\User;
use App\Services\Customer\CustomerService;
use App\Services\Customer\SpreadsheetService;
use App\Services\Gis\ZoneService;
use App\Services\Network\NetworkService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ZonesAndUploadsTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'Zone test', 'email' => uniqid().'@test.invalid', 'password' => 'Example-Password-123']);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
    }

    private function polygon(): array
    {
        return ['type' => 'Polygon', 'coordinates' => [[[106.75, -6.38], [106.77, -6.38], [106.77, -6.36], [106.75, -6.36], [106.75, -6.38]]]];
    }

    public function test_upload_size_accepts_256_mb_and_rejects_larger_files(): void
    {
        Queue::fake();
        foreach (['/gis/import' => 'network.kmz', '/customers/import' => 'customers.xlsx'] as $url => $filename) {
            $this->post($url, ['service_area_id' => $this->serviceAreaId(), 'file' => UploadedFile::fake()->create($filename, 256 * 1024)])->assertRedirect()->assertSessionHasNoErrors();
            $this->post($url, ['service_area_id' => $this->serviceAreaId(), 'file' => UploadedFile::fake()->create($filename, 256 * 1024 + 1)])->assertSessionHasErrors('file');
        }
        foreach ([ImportJob::class, CustomerImportJob::class] as $class) {
            $job = $class::latest()->firstOrFail();
            $this->assertSame('UPLOADED', $job->status);
            Storage::delete($job->path);
        }
    }

    public function test_php_upload_errors_explain_failure_before_staging(): void
    {
        foreach ([UPLOAD_ERR_INI_SIZE => 'batas upload PHP', UPLOAD_ERR_PARTIAL => 'sebagian', UPLOAD_ERR_NO_TMP_DIR => 'Folder sementara', UPLOAD_ERR_CANT_WRITE => 'tidak dapat menulis'] as $code => $message) {
            $file = new UploadedFile('', 'network.kmz', 'application/vnd.google-earth.kmz', $code, true);
            $this->post('/gis/import', ['service_area_id' => $this->serviceAreaId(), 'file' => $file])->assertSessionHasErrors('file');
            $this->assertStringContainsString($message, session('errors')->first('file'));
        }
        $this->assertSame(0, ImportJob::count());
    }

    public function test_rt_zone_crud_and_map_metadata(): void
    {
        $data = ['name' => 'RT 01 RW 02', 'object_type' => 'AREA', 'geometry' => $this->polygon(), 'zone_level' => 'RT', 'rt' => '1', 'rw' => '2', 'village' => 'Contoh', 'color' => '#8b5cf6'];
        $response = $this->postJson('/api/gis-objects', $data)->assertOk()->assertJsonPath('data.network.rt', '001')->assertJsonPath('data.network.rw', '002');
        $id = $response->json('data.id');
        $this->getJson('/api/map/objects?type=AREA')->assertOk()->assertJsonFragment(['zone_level' => 'RT']);
        $this->putJson('/api/gis-objects/'.$id, ['name' => 'Zona diperbarui', 'color' => '#ff5f01'])->assertOk()->assertJsonPath('data.network.rt', '001');
        $this->postJson('/api/gis-objects', [...$data, 'rt' => null])->assertUnprocessable();
        $this->postJson('/api/gis-objects', [...$data, 'color' => 'url(evil)'])->assertUnprocessable();
        $this->deleteJson('/api/gis-objects/'.$id)->assertOk();
        $this->assertSoftDeleted('gis_objects', ['id' => $id]);
    }

    public function test_statistics_normalize_numbers_keep_villages_separate_and_include_missing_location(): void
    {
        $s = app(CustomerService::class);
        foreach ([['village' => 'A', 'rt' => '1', 'rw' => '2', 'status' => 'ACTIVE'], ['village' => 'A', 'rt' => '001', 'rw' => '002', 'status' => 'PROSPECT'], ['village' => 'B', 'rt' => '1', 'rw' => '2', 'status' => 'SUSPENDED']] as $i => $row) {
            $s->save(['customer_id' => 'ZONE-'.$i, 'name' => 'Sample '.$i, ...$row]);
        }
        $stats = app(ZoneService::class)->statistics(['level' => 'RT']);
        $this->assertCount(2, $stats['rows']);
        $a = $stats['rows']->firstWhere('village', 'A');
        $this->assertSame(2, (int) $a->total);
        $this->assertSame(2, (int) $a->missing_location);
        $this->assertSame(1, (int) $a->active);
        $this->assertCount(1, app(ZoneService::class)->statistics(['village' => 'A', 'rt' => '1', 'rw' => '02'])['rows']);
        $this->get('/zones')->assertOk();
    }

    public function test_spatial_counts_are_separate_and_deleted_customers_excluded(): void
    {
        $z = app(NetworkService::class)->save(['name' => 'RW boundary', 'object_type' => 'AREA', 'geometry' => $this->polygon(), 'zone_level' => 'RW', 'rw' => '2']);
        $s = app(CustomerService::class);
        $c = $s->save(['customer_id' => 'SPATIAL', 'name' => 'Inside', 'status' => 'PROSPECT', 'geometry' => ['type' => 'Point', 'coordinates' => [106.76, -6.37]]]);
        $this->assertSame(1, (int) app(ZoneService::class)->statistics([])['zones']->firstWhere('id', $z->id)->spatial_customers);
        $s->delete($c);
        $this->assertSame(0, (int) app(ZoneService::class)->statistics([])['zones']->firstWhere('id', $z->id)->spatial_customers);
    }

    public function test_xlsx_and_kmz_upload_reach_review_without_commit(): void
    {
        foreach ([['/customers/import', 'customers-demo.xlsx', CustomerImportJob::class], ['/gis/import', 'network.kmz', ImportJob::class]] as [$url,$name,$class]) {
            $before = GisObject::count();
            $this->post($url, ['service_area_id' => $this->serviceAreaId(), 'mode' => 'INSERT_ONLY', 'file' => UploadedFile::fake()->createWithContent($name, file_get_contents(base_path('samples/'.$name)))])->assertRedirect()->assertSessionHasNoErrors();
            $job = $class::latest()->firstOrFail();
            $this->assertSame('READY', $job->status);
            $this->assertGreaterThan(0, $job->total_rows);
            $this->assertSame($before, GisObject::count());
            Storage::delete($job->path);
        }
    }

    public function test_corrupted_import_redirects_to_failed_review_and_preserves_error(): void
    {
        $this->post('/gis/import', ['service_area_id' => $this->serviceAreaId(), 'file' => UploadedFile::fake()->createWithContent('broken.kmz', 'not a zip')])->assertRedirect();
        $j = ImportJob::latest()->firstOrFail();
        $this->assertSame('FAILED', $j->status);
        $this->assertStringContainsString('rusak', $j->error);
        $this->get('/gis/import/'.$j->id.'/review')->assertOk();
        Storage::delete($j->path);
        $this->post('/customers/import', ['file' => UploadedFile::fake()->createWithContent('network.kmz', 'wrong format')])->assertSessionHasErrors('file');
    }

    public function test_excel_numeric_rt_rw_and_invalid_port_are_reviewable(): void
    {
        $r = app(SpreadsheetService::class)->validateRow(['customer_id' => 'NUM-RT', 'name' => 'Numeric region', 'status' => 'PROSPECT', 'rt' => 1, 'rw' => 2, 'port_number' => 'abc']);
        $this->assertSame('1', $r['data']['rt']);
        $this->assertSame('2', $r['data']['rw']);
        $this->assertArrayNotHasKey('rt', $r['errors']);
        $this->assertArrayHasKey('port_number', $r['errors']);
    }

    public function test_invalid_imported_line_does_not_abort_other_rows(): void
    {
        $kml = '<kml><Document><Placemark><name>Invalid short line</name><LineString><coordinates>106,-6</coordinates></LineString></Placemark><Placemark><name>Valid point</name><Point><coordinates>106,-6</coordinates></Point></Placemark></Document></kml>';
        $this->post('/gis/import', ['service_area_id' => $this->serviceAreaId(), 'file' => UploadedFile::fake()->createWithContent('mixed.kml', $kml)])->assertRedirect();
        $j = ImportJob::latest()->firstOrFail();
        $this->assertSame('READY', $j->status);
        $this->assertSame(1, $j->rows()->where('validation', 'INVALID')->count());
        $this->assertSame(1, $j->rows()->where('validation', 'VALID')->count());
        Storage::delete($j->path);
    }
}
