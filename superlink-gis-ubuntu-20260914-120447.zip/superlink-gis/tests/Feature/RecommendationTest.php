<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\Network\NetworkService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class RecommendationTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        config(['routing.url' => '']);
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'Planner', 'email' => uniqid().'@test.invalid', 'password' => 'Test-password-123']);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
    }

    private function asset(string $type, float $lng, int $capacity = 2)
    {
        return app(NetworkService::class)->save(['name' => uniqid($type), 'object_type' => $type, 'capacity' => $capacity, 'geometry' => ['type' => 'Point', 'coordinates' => [$lng, 0]], 'status' => 'ACTIVE']);
    }

    private function url(string $type, bool $free = true): string
    {
        return '/api/map/recommendations?lat=0&lng=10&radius=3000&type='.$type.'&free='.($free ? '1' : '0');
    }

    public function test_full_nearest_is_skipped_before_limit_and_inactive_excluded(): void
    {
        for ($i = 1; $i <= 6; $i++) {
            $o = $this->asset('ODP', 10 + $i * .001);
            DB::table('odp_ports')->where('odp_id', $o->id)->update(['status' => 'DISABLED']);
        }
        $available = $this->asset('ODP', 10.009);
        $inactive = $this->asset('ODP', 10.008);
        $inactive->update(['status' => 'INACTIVE']);
        $this->getJson($this->url('ODP'))->assertOk()->assertJsonCount(1, 'data')->assertJsonPath('data.0.id', $available->id)->assertJsonPath('data.0.available', 2);
    }

    public function test_odc_observation_is_required_expires_and_checks_capacity(): void
    {
        $o = $this->asset('ODC', 10.001);
        $this->getJson($this->url('ODC'))->assertJsonCount(0, 'data');
        $this->getJson($this->url('ODC', false))->assertJsonPath('data.0.available', null);
        $this->putJson('/api/map/odcs/'.$o->id.'/port-observation', ['available' => 3])->assertUnprocessable();
        $this->putJson('/api/map/odcs/'.$o->id.'/port-observation', ['available' => 1])->assertOk();
        $this->getJson($this->url('ODC'))->assertJsonPath('data.0.available', 1);
        DB::table('odcs')->where('id', $o->id)->update(['capacity' => 4]);
        $this->getJson($this->url('ODC'))->assertJsonCount(0, 'data');
        DB::table('odcs')->where('id', $o->id)->update(['capacity' => 2]);
        $this->travel(25)->hours();
        $this->getJson($this->url('ODC'))->assertJsonCount(0, 'data');
        $this->travelBack();
    }

    public function test_cs_cannot_access_recommendations_or_record_ports(): void
    {
        $o = $this->asset('ODC', 10.001);
        auth()->user()->syncRoles(['CUSTOMER_SERVICE']);
        $this->getJson($this->url('ODP'))->assertForbidden();
        $this->putJson('/api/map/odcs/'.$o->id.'/port-observation', ['available' => 1])->assertForbidden();
    }
}
