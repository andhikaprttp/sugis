<?php

namespace Tests\Feature;

use App\Services\Gis\RoadRoutingService;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class RoadRoutingTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        config(['routing.url' => 'https://router.test', 'routing.profile' => 'driving']);
        Http::preventStrayRequests();
    }

    public function test_table_distances_keep_unroutable_destination_null(): void
    {
        Http::fake(['router.test/table/*' => Http::response(['code' => 'Ok', 'distances' => [[125.4, null]]])]);
        $result = app(RoadRoutingService::class)->distances([-6.3, 106.7], [[-6.31, 106.71], [-6.32, 106.72]]);
        $this->assertSame([125.4, null], $result);
        Http::assertSent(fn ($request) => $request->method() === 'GET' && $request['sources'] === '0' && $request['destinations'] === '1;2');
    }

    public function test_route_is_converted_to_lat_lng_and_bounded_for_editor(): void
    {
        $coordinates = collect(range(0, 199))->map(fn ($i) => [106.7 + $i / 10000, -6.3 + $i / 10000])->all();
        Http::fake(['router.test/route/*' => Http::response(['code' => 'Ok', 'routes' => [['distance' => 456.7, 'geometry' => ['coordinates' => $coordinates]]]])]);
        $result = app(RoadRoutingService::class)->route([-6.3, 106.7], [-6.28, 106.72]);
        $this->assertCount(50, $result['points']);
        $this->assertSame([-6.3, 106.7], $result['points'][0]);
        $this->assertEqualsWithDelta([-6.2801, 106.7199], $result['points'][49], 0.000001);
        $this->assertSame(456.7, $result['distance']);
    }

    public function test_redirect_and_malformed_geometry_are_rejected(): void
    {
        Http::fakeSequence()->push('', 302)->push(['code' => 'Ok', 'routes' => [['distance' => 10, 'geometry' => ['coordinates' => [[1]]]]]], 200);
        $this->expectException(\RuntimeException::class);
        app(RoadRoutingService::class)->route([0, 0], [1, 1]);
    }
}
