<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\ExportJob;
use App\Models\GisObject;
use App\Models\ImportJob;
use App\Models\Odp;
use App\Models\User;
use App\Services\Network\NetworkService;
use Database\Seeders\DemoCustomerSeeder;
use Database\Seeders\DemoNetworkSeeder;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Tests\TestCase;

class HttpWorkflowTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'HTTP Admin', 'email' => uniqid().'@example.test', 'password' => 'HTTP-Password-123']);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
        $this->seed([DemoNetworkSeeder::class, DemoCustomerSeeder::class]);
    }

    public function test_all_workspaces_render_through_inertia(): void
    {
        foreach (['/dashboard', '/map', '/customers', '/customers/create', '/customers/import', '/customers/export', '/gis/import', '/gis/export', '/network/pops', '/network/odcs', '/network/odps', '/network/poles', '/network/closures', '/network/fiber-routes', '/surveys', '/surveys/create', '/audit-logs', '/settings'] as $path) {
            $this->get($path)->assertOk();
        }$this->getJson('/api/map/objects')->assertOk()->assertJsonStructure(['data' => [['id', 'geometry', 'object_type']]]);
        $this->get('/customers/'.Customer::first()->id)->assertOk();
        $this->get('/network/odps/'.Odp::first()->id.'/ports')->assertOk();
    }

    public function test_kml_upload_requires_review_then_commits_selected_classification(): void
    {
        $before = GisObject::count();
        $file = UploadedFile::fake()->createWithContent('network.kml', file_get_contents(base_path('samples/network.kml')));
        $this->post('/gis/import', ['service_area_id' => $this->serviceAreaId(), 'file' => $file])->assertRedirect();
        $j = ImportJob::latest()->firstOrFail();
        $this->assertSame('READY', $j->status);
        $this->assertSame($before, GisObject::count());
        $row = $j->rows()->where('row_number', 1)->firstOrFail();
        $this->post('/gis/import/'.$j->id.'/commit', ['ids' => [$row->id], 'changes' => [$row->id => ['object_type' => 'ODP', 'code' => 'IMPORTED-ODP', 'capacity' => 8]]])->assertRedirect()->assertSessionHasNoErrors();
        $this->assertDatabaseHas('gis_objects', ['code' => 'IMPORTED-ODP', 'object_type' => 'ODP', 'source' => 'KMZ_IMPORT']);
        $this->assertSame('COMPLETED', $j->fresh()->status);
        $this->post('/gis/import/'.$j->id.'/commit', ['ids' => [$row->id]])->assertSessionHasErrors();
        Storage::delete($j->path);
    }

    public function test_template_export_and_error_report_are_xlsx(): void
    {
        $this->get('/customers/template')->assertOk()->assertHeader('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $this->post('/customers/export', ['status' => 'ACTIVE'])->assertRedirect();
        $job = ExportJob::latest()->firstOrFail();
        $this->assertSame('COMPLETED', $job->status);
        $this->get('/exports/'.$job->id.'/download')->assertOk();
        $book = IOFactory::load(Storage::path($job->path));
        $this->assertSame(['Customers', 'Summary', 'Metadata'], $book->getSheetNames());
        Storage::delete($job->path);
    }

    public function test_fiber_route_has_edges_and_moving_node_updates_distance(): void
    {
        $s = app(NetworkService::class);
        $line = $s->save(['name' => 'Topology test', 'object_type' => 'FIBER_ROUTE', 'geometry' => ['type' => 'LineString', 'coordinates' => [[106.76, -6.37], [106.761, -6.37]]]]);
        $segment = DB::table('fiber_segments')->where('route_id', $line->id)->first();
        $this->assertNotNull($segment);
        $node = GisObject::findOrFail($segment->end_node_id);
        $s->save(['geometry' => ['type' => 'Point', 'coordinates' => [106.762, -6.37]]], $node);
        $updated = DB::table('fiber_segments')->where('id', $segment->id)->first();
        $this->assertGreaterThan($segment->distance * 1.9, $updated->distance);
        $this->assertDatabaseHas('gis_objects', ['id' => $segment->start_node_id, 'object_type' => 'UNCLASSIFIED']);
    }
}
