<?php

namespace Tests\Feature;

use App\Services\Monitoring\IncidentMonitor;
use App\Services\Telegram\AlertSender;
use App\Services\Telegram\Authorization;
use App\Services\Telegram\CommandHandler;
use App\Services\Telegram\Formatter;
use App\Services\Telegram\Poller;
use App\Services\Telegram\Transport;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\Client\Factory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class TelegramTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        config(['telegram.enabled' => true, 'telegram.token' => 'test-secret', 'telegram.chat_id' => '-100', 'telegram.allowed_users' => ['123'], 'telegram.allowed_chats' => ['-100'], 'telegram.debounce' => 90]);
        Http::preventStrayRequests();
        Http::fake(['api.telegram.org/*' => Http::response(['ok' => true, 'result' => []])]);
    }

    private function snapshot(string $state): array
    {
        return ['sources' => ['CMS' => true, 'PPPoE' => null], 'rows' => ['olt:a' => ['key' => 'olt:a', 'type' => 'OLT', 'name' => 'OLT A', 'state' => $state]]];
    }

    public function test_access_requires_both_user_and_chat_and_blocks_callbacks(): void
    {
        $a = app(Authorization::class);
        $this->assertTrue($a->allowed('123', '-100'));
        $this->assertFalse($a->allowed('123', 'other'));
        $this->assertFalse($a->allowed('other', '-100'));
        app(CommandHandler::class)->handle(['callback_query' => ['id' => 'x', 'from' => ['id' => 999], 'message' => ['chat' => ['id' => -100]], 'data' => 'ack:1']]);
        Http::assertNothingSent();
    }

    public function test_debounce_deduplication_acknowledge_and_single_recovery(): void
    {
        $m = app(IncidentMonitor::class);
        $sender = app(AlertSender::class);
        $m->evaluate($this->snapshot('OFFLINE'));
        $sender->tick();
        Http::assertNothingSent();
        $this->travel(100)->seconds();
        $m->evaluate($this->snapshot('OFFLINE'));
        $sender->tick();
        $sender->tick();
        Http::assertSentCount(1);
        $i = DB::table('monitoring_incidents')->where('kind', 'OLT OFFLINE')->first();
        $update = ['callback_query' => ['id' => 'cb', 'from' => ['id' => 123], 'message' => ['chat' => ['id' => -100]], 'data' => 'ack:'.$i->id]];
        app(CommandHandler::class)->handle($update);
        app(CommandHandler::class)->handle($update);
        $this->assertDatabaseHas('monitoring_incidents', ['id' => $i->id, 'status' => 'ACKNOWLEDGED', 'acknowledged_by' => '123']);
        $this->assertDatabaseCount('monitoring_incidents', 1);
        $m->evaluate($this->snapshot('ONLINE'));
        $sender->tick();
        $sender->tick();
        Http::assertSentCount(6);
        $this->assertDatabaseHas('monitoring_incidents', ['id' => $i->id, 'status' => 'RESOLVED']);
    }

    public function test_unknown_never_resolves_an_outage_and_breaks_debounce(): void
    {
        $m = app(IncidentMonitor::class);
        $m->evaluate($this->snapshot('OFFLINE'));
        $this->travel(100)->seconds();
        $m->evaluate($this->snapshot('UNKNOWN'));
        $m->evaluate($this->snapshot('OFFLINE'));
        app(AlertSender::class)->tick();
        Http::assertNothingSent();
        $this->assertNull(DB::table('monitoring_incidents')->first()->resolved_at);
    }

    public function test_olt_outage_suppresses_child_and_source_failure_is_separate(): void
    {
        $s = $this->snapshot('OFFLINE');
        $s['rows']['onu:x'] = ['key' => 'onu:x', 'name' => 'Budi', 'type' => 'ONU', 'state' => 'OFFLINE', 'olt_id' => 'a', 'pon' => '0/1', 'rx' => -30];
        app(IncidentMonitor::class)->evaluate($s);
        $this->assertDatabaseCount('monitoring_incidents', 1);
        $s['sources']['CMS'] = false;
        $s['rows']['olt:a']['state'] = 'UNKNOWN';
        $s['rows']['onu:x']['state'] = 'UNKNOWN';
        app(IncidentMonitor::class)->evaluate($s);
        $this->assertDatabaseHas('monitoring_incidents', ['kind' => 'SOURCE UNAVAILABLE']);
        $this->assertDatabaseMissing('monitoring_incidents', ['kind' => 'ONU OFFLINE']);
    }

    public function test_formatter_escapes_html_and_uses_wib(): void
    {
        $f = app(Formatter::class);
        $this->assertStringContainsString('&lt;b&gt;', $f->fields('Pelanggan', ['Nama' => '<b>Budi</b>']));
        $this->assertSame('14 Sep 2026 18:00:00 WIB', $f->time('2026-09-14 11:00:00+00'));
    }

    public function test_transport_failure_does_not_expose_token(): void
    {
        Http::fake(fn () => throw new \RuntimeException('https://api.telegram.org/bottest-secret/getMe'));
        try {
            app(Transport::class)->call('getMe');
            $this->fail('Expected sanitized exception');
        } catch (\RuntimeException $e) {
            $this->assertStringNotContainsString('test-secret', (string) $e);
            $this->assertNull($e->getPrevious());
        }
    }

    public function test_help_uses_existing_snapshot_without_external_monitoring_requests(): void
    {
        app(CommandHandler::class)->handle(['message' => ['from' => ['id' => 123], 'chat' => ['id' => -100], 'text' => '/help']]);
        Http::assertSentCount(1);
        Http::assertSent(fn ($r) => str_contains($r['text'], '/customer') && str_contains($r->url(), 'api.telegram.org'));
    }

    public function test_command_search_buttons_detail_and_bot_startup(): void
    {
        DB::table('cms_olt_snapshots')->insert(['device_id' => 'a', 'name' => 'OLT A', 'state' => 'ONLINE', 'observed_at' => now()]);
        foreach (['ONE', 'TWO'] as $sn) {
            DB::table('ont_snapshots')->insert(['sn' => $sn, 'description' => 'Budi '.$sn, 'olt_device_id' => 'a', 'pon_id' => '0/1/2', 'ont_state' => 'ONLINE', 'rx_power' => '-28', 'observed_at' => now()]);
        }
        $handler = app(CommandHandler::class);
        $handler->handle(['message' => ['from' => ['id' => 123], 'chat' => ['id' => -100], 'text' => '/onu bUdI']]);
        Http::assertSent(fn ($r) => str_contains($r['text'], '2 hasil') && count($r['reply_markup']['inline_keyboard']) === 2);
        $handler->handle(['callback_query' => ['id' => 'detail', 'from' => ['id' => 123], 'message' => ['chat' => ['id' => -100]], 'data' => 'detail:'.substr(hash('sha256', 'onu:ONE'), 0, 40)]]);
        Http::assertSent(fn ($r) => str_contains($r['text'] ?? '', 'Budi ONE') && str_contains($r['text'] ?? '', 'UNKNOWN'));
        foreach (['/start', '/status', '/customer Budi', '/pppoe budi', '/olt OLT A', '/pon OLT A 0/1/2', '/offline', '/warning', '/alarm', '/incidents'] as $command) {
            $handler->handle(['message' => ['from' => ['id' => 123], 'chat' => ['id' => -100], 'text' => $command]]);
        }
        $this->artisan('telegram:check')->assertSuccessful();
        Http::assertSentCount(14);
    }

    public function test_poller_persists_offset_and_accepts_only_supported_updates(): void
    {
        Http::swap(new Factory);
        Http::preventStrayRequests();
        $update = ['update_id' => 40, 'message' => ['from' => ['id' => 123], 'chat' => ['id' => -100], 'text' => '/help']];
        Http::fake(['api.telegram.org/*' => fn ($r) => Http::response(['ok' => true, 'result' => str_contains($r->url(), 'getUpdates') ? [$update] : []])]);
        app(Poller::class)->tick();
        $this->assertDatabaseHas('telegram_state', ['id' => 1, 'update_offset' => 41]);
        Http::assertSent(fn ($r) => str_contains($r->url(), 'getUpdates') && $r['allowed_updates'] === ['message', 'callback_query']);
    }

    public function test_mass_pon_optical_and_short_flap(): void
    {
        $m = app(IncidentMonitor::class);
        $s = $this->snapshot('ONLINE');
        for ($i = 1; $i <= 5; $i++) {
            $s['rows']['onu:'.$i] = ['key' => 'onu:'.$i, 'name' => 'ONU '.$i, 'type' => 'ONU', 'state' => 'OFFLINE', 'olt_id' => 'a', 'pon' => '0/1', 'rx' => -30];
        }
        $m->evaluate($s);
        $this->assertDatabaseHas('monitoring_incidents', ['kind' => 'PON OUTAGE']);
        $this->assertDatabaseMissing('monitoring_incidents', ['kind' => 'ONU OFFLINE']);
        foreach ($s['rows'] as &$row) {
            $row['state'] = 'ONLINE';
        }
        unset($row);
        $m->evaluate($s);
        app(AlertSender::class)->tick();
        Http::assertNothingSent();
        $this->assertSame(5, DB::table('monitoring_incidents')->where('kind', 'OPTICAL WARNING')->count());
    }
}
