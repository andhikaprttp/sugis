<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class OperationsTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $user = User::create(['name' => 'Operations', 'email' => uniqid().'@test.invalid', 'password' => 'Operations-test-123']);
        $user->assignRole('ADMIN');
        $this->actingAs($user);
        Http::preventStrayRequests();
    }

    public function test_all_menus_render_and_do_not_call_devices(): void
    {
        foreach (['monitoring', 'olts', 'templates', 'activation', 'actions', 'alarms', 'history', 'connection'] as $section) {
            $this->get('/operations/'.$section)->assertOk();
        }
        $this->get('/operations/not-a-menu')->assertNotFound();
        $this->post('/operations/activation', [])->assertNotFound();
        Http::assertNothingSent();
    }

    public function test_description_search_across_olts_and_within_selected_olt(): void
    {
        foreach (['a', 'b'] as $olt) {
            DB::table('cms_olt_snapshots')->insert(['device_id' => $olt, 'name' => 'OLT '.$olt, 'state' => 'ONLINE', 'observed_at' => now()]);
            DB::table('ont_snapshots')->insert(['sn' => 'SERIAL-'.$olt, 'description' => 'Budi '.$olt, 'olt_device_id' => $olt, 'ont_state' => 'ONLINE', 'observed_at' => now()]);
        }
        $this->get('/operations/olts?search=bUdI')->assertInertia(fn ($page) => $page->where('cmsOnus.total', 2));
        $this->get('/operations/olts?search=budi&cms_olt=a')->assertInertia(fn ($page) => $page->where('cmsOnus.total', 1)->where('cmsOnus.data.0.description', 'Budi a'));
        Http::assertNothingSent();
    }

    public function test_olt_and_template_are_saved_validated_and_audited(): void
    {
        $this->post('/operations/olts', ['name' => 'OLT example', 'external_id' => 'example-olt', 'host' => '10.1.1.22'])->assertSessionHasNoErrors();
        $olt = DB::table('provisioning_olts')->where('external_id', 'example-olt')->first();
        $data = ['olt_id' => $olt->id, 'name' => 'Internet', 'vlan' => 100, 'line_profile' => 'line', 'service_profile' => 'service', 'wan_profile' => 'wan', 'tr069_profile' => 'tr069', 'binding' => 'LAN1'];
        $this->post('/operations/templates', $data)->assertSessionHasNoErrors();
        $this->assertDatabaseHas('provisioning_templates', ['olt_id' => $olt->id, 'vlan' => 100]);
        $this->assertDatabaseHas('audit_logs', ['model' => 'provisioning_templates', 'action' => 'Create']);
        $this->post('/operations/templates', [...$data, 'vlan' => 4095])->assertSessionHasErrors('vlan');
        $this->post('/operations/olts', ['name' => 'Duplicate', 'external_id' => 'example-olt'])->assertSessionHasErrors('external_id');
        $this->post('/operations/olts', ['id' => $olt->id, 'name' => 'Renamed', 'external_id' => 'example-olt'])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('provisioning_olts', ['id' => $olt->id, 'name' => 'Renamed']);
        Http::assertNothingSent();
    }

    public function test_readonly_user_cannot_change_setup_or_access_connection(): void
    {
        auth()->user()->syncRoles('VIEWER');
        $this->get('/operations/monitoring')->assertOk();
        $this->get('/operations/connection')->assertForbidden();
        $this->post('/operations/olts', ['name' => 'Forbidden'])->assertForbidden();
        $this->post('/operations/templates', [])->assertForbidden();
        $this->post('/operations/connection', [])->assertForbidden();
    }

    public function test_connection_is_local_setup_and_online_filter_does_not_infer_status(): void
    {
        $this->post('/operations/connection', ['cms_url' => 'https://10.1.1.21', 'pppoe_source' => 'RADIUS'])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('provisioning_connections', ['id' => 1, 'pppoe_source' => 'RADIUS']);
        $this->get('/operations/monitoring?state=ONLINE')->assertInertia(fn ($page) => $page->component('Operations/Index')->where('customers.total', 0));
        Http::assertNothingSent();
    }
}
