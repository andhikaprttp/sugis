<?php

return [
    'driver' => env('PPPOE_DRIVER', 'none'),
    'url' => env('MIKROTIK_URL', ''),
    'username' => env('MIKROTIK_USERNAME', ''),
    'password' => env('MIKROTIK_PASSWORD', ''),
    'allow_http' => filter_var(env('MIKROTIK_ALLOW_HTTP', false), FILTER_VALIDATE_BOOL),
    'maptiler_key' => env('MAPTILER_KEY', ''),
];
