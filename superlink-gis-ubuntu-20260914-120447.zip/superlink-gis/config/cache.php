<?php

return ['default' => env('CACHE_STORE', 'redis'), 'stores' => ['redis' => ['driver' => 'redis', 'connection' => 'cache'], 'array' => ['driver' => 'array', 'serialize' => false], 'file' => ['driver' => 'file', 'path' => storage_path('framework/cache/data')]], 'prefix' => 'superlink_cache'];
