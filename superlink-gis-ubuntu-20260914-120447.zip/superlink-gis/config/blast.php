<?php

return [
    'driver' => env('BLAST_DRIVER', 'disabled'),
    'token' => env('BLAST_FONNTE_TOKEN'),
    'batch_size' => 20,
    'late_minutes' => 60,
];
