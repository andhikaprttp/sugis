<?php

return ['admin_email' => env('ADMIN_EMAIL', 'admin@superlink.local'), 'admin_password' => env('ADMIN_PASSWORD'), 'demo_seed' => filter_var(env('DEMO_SEED', false), FILTER_VALIDATE_BOOL), 'upload_bytes' => 256 * 1024 * 1024, 'expanded_bytes' => 512 * 1024 * 1024, 'import_objects' => 20000];
