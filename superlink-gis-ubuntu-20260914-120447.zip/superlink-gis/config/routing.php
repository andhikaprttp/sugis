<?php

return [
    'url' => env('ROUTING_URL', 'https://router.project-osrm.org'),
    'profile' => env('ROUTING_PROFILE', 'driving'),
];
