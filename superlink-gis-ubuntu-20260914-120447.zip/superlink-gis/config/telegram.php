<?php

return [
    'enabled' => (bool) env('TELEGRAM_ENABLED', false),
    'token' => env('TELEGRAM_BOT_TOKEN', ''),
    'chat_id' => (string) env('TELEGRAM_CHAT_ID', ''),
    'allowed_users' => array_values(array_filter(array_map('trim', explode(',', env('TELEGRAM_ALLOWED_USER_IDS', ''))))),
    'allowed_chats' => array_values(array_filter(array_map('trim', explode(',', env('TELEGRAM_ALLOWED_CHAT_IDS', ''))))),
    'debounce' => max(0, (int) env('TELEGRAM_DEBOUNCE_SECONDS', 90)),
    'rx_warning' => (float) env('MONITORING_RX_WARNING_DBM', -27),
    'mass_threshold' => max(2, (int) env('MONITORING_MASS_THRESHOLD', 5)),
];
