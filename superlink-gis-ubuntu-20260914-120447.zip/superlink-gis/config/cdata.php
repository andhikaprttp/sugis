<?php

return ['allow_http' => env('CDATA_ALLOW_HTTP', false)];
