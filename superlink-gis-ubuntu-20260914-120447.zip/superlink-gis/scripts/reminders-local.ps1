$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$phpBinary = Join-Path (Split-Path $projectRoot -Parent) '.tools/php/php.exe'
$mutex = [Threading.Mutex]::new($false, 'Local\SuperlinkReminderScheduler')
if (-not $mutex.WaitOne(0)) { throw 'Scheduler reminder lokal sudah berjalan.' }
Push-Location $projectRoot
try {
    Write-Host 'Scheduler reminder aktif. Ctrl+C untuk berhenti. API mengikuti konfigurasi .env.'
    while ($true) {
        & $phpBinary artisan blast:run
        Start-Sleep -Seconds 60
    }
} finally {
    Pop-Location
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
