<?php

require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use Illuminate\Support\Facades\DB;

$role = DB::selectOne('SELECT current_user AS name, rolsuper, rolcreatedb, rolcreaterole, rolreplication, rolbypassrls FROM pg_roles WHERE rolname = current_user');
$report = [
    'database' => config('database.connections.pgsql.database'),
    'runtime_role' => $role,
    'schema_create' => DB::selectOne("SELECT has_schema_privilege(current_user, 'public', 'CREATE') AS allowed")->allowed,
    'listen_addresses' => DB::selectOne('SHOW listen_addresses')->listen_addresses,
    'cms' => DB::table('provisioning_connections')->select('enabled', 'allow_writes')->first(),
    'pppoe_driver' => config('monitoring.driver'),
    'debug' => config('app.debug'),
    'cms_http_allowed' => config('cdata.allow_http'),
];
echo json_encode($report, JSON_PRETTY_PRINT).PHP_EOL;
