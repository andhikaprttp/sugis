"""Create a source-only Docker deployment archive, excluding local data and secrets."""
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
output = root / 'output' / 'releases'
output.mkdir(parents=True, exist_ok=True)
archive = output / ('superlink-gis-ubuntu-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip')
folders = {'app', 'bootstrap', 'config', 'database', 'docker', 'docs', 'public', 'resources', 'routes', 'samples', 'scripts', 'tests'}
files = {'.dockerignore', '.env.example', '.env.server.example', '.gitignore', 'artisan', 'composer.json', 'composer.lock', 'docker-compose.yml', 'Dockerfile', 'package.json', 'package-lock.json', 'phpunit.xml', 'postcss.config.js', 'README.md', 'tailwind.config.js', 'tsconfig.json', 'vite.config.ts'}
selected = []
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    rel = path.relative_to(root)
    if len(rel.parts) == 1:
        include = rel.name in files
    else:
        include = rel.parts[0] in folders
    if not include or rel.as_posix().startswith(('bootstrap/cache/', 'public/build/')) or rel.as_posix() == 'public/hot':
        continue
    if rel.name == '.env' or '__pycache__' in rel.parts or rel.suffix in {'.pyc', '.log'}:
        continue
    selected.append((path, 'superlink-gis/' + rel.as_posix()))
with ZipFile(archive, 'x', ZIP_DEFLATED) as package:
    for path, name in selected:
        package.write(path, name)
with ZipFile(archive) as package:
    assert package.testzip() is None, 'Archive failed CRC verification'
    names = set(package.namelist())
    for required in ['Dockerfile', 'docker-compose.yml', 'composer.lock', 'package-lock.json', '.env.server.example', 'docs/PINDAH-KE-SERVER.md']:
        assert 'superlink-gis/' + required in names, required
    assert not any(n.endswith('/.env') or '/storage/' in n or '/vendor/' in n or '/node_modules/' in n for n in names)
digest = sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
print(f'{archive}\nFiles: {len(selected)}\nSize: {archive.stat().st_size / 1024 / 1024:.2f} MB\nSHA256: {digest}')
