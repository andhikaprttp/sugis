param([ValidateRange(1,65535)][int]$Port = 8080)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$phpBinary = Join-Path (Split-Path $projectRoot -Parent) '.tools/php/php.exe'
if (-not (Test-Path $phpBinary)) {
    $phpCommand = Get-Command php -ErrorAction SilentlyContinue
    if (-not $phpCommand) { throw 'PHP tidak ditemukan. Pasang PHP 8.3 atau runtime portable ../.tools/php.' }
    $phpBinary = $phpCommand.Source
}
if (-not (Test-Path (Join-Path $projectRoot '.env'))) { throw 'File .env belum tersedia. Salin .env.example dan atur koneksi database lokal.' }
if (-not (Test-Path (Join-Path $projectRoot 'public/build/manifest.json'))) { throw 'Asset belum dibuild. Jalankan npm ci dan npm run build terlebih dahulu.' }
$uploadTemp = Join-Path $projectRoot 'storage/app/upload-tmp'
New-Item -ItemType Directory -Force -Path $uploadTemp | Out-Null
Push-Location $projectRoot
$previousAppUrl = $env:APP_URL
try {
    $env:APP_URL = "http://localhost:$Port"
    Write-Host "Superlink: http://localhost:$Port (Ctrl+C untuk berhenti)"
    $router = Join-Path $projectRoot 'vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php'
    Set-Location (Join-Path $projectRoot 'public')
    & $phpBinary -d upload_max_filesize=256M -d post_max_size=260M -d "upload_tmp_dir=$uploadTemp" -S "127.0.0.1:$Port" $router
} finally {
    $env:APP_URL = $previousAppUrl
    Pop-Location
}
