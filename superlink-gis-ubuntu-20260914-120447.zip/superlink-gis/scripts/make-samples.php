<?php

use App\Services\Customer\SpreadsheetService;
use Illuminate\Contracts\Console\Kernel;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Regenerate exchange fixtures; all coordinates and identities are dummy data.
require dirname(__DIR__).'/vendor/autoload.php';
$app = require dirname(__DIR__).'/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();
$root = dirname(__DIR__).'/samples';
$zip = new ZipArchive;
$zip->open($root.'/network.kmz', ZipArchive::CREATE | ZipArchive::OVERWRITE);
$zip->addFile($root.'/network.kml', 'doc.kml');
$zip->close();
$service = app(SpreadsheetService::class);
$book = $service->template();
$book->getSheet(0)->setCellValueExplicit('A2', 'CUST-SAMPLE-001', 's');
$book->getSheet(0)->setCellValueExplicit('B2', 'Sample Customer [DEMO]', 's');
$book->getSheet(0)->setCellValueExplicit('C2', '+628120000001', 's');
$book->getSheet(0)->setCellValueExplicit('D2', 'Alamat dummy, bukan pelanggan nyata', 's');
$book->getSheet(0)->setCellValue('K2', -6.37);
$book->getSheet(0)->setCellValue('L2', 106.76);
$book->getSheet(0)->setCellValueExplicit('N2', 'PROSPECT', 's');
(new Xlsx($book))->save($root.'/customers-demo.xlsx');
echo "Generated sample KMZ and XLSX.\n";
