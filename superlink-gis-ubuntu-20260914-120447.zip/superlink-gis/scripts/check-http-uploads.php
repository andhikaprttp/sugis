<?php

use App\Models\CustomerImportJob;
use App\Models\ImportJob;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\Storage;

// Real multipart requests through the local PHP server, including files above PHP's old 2 MB limit.
// Creates isolated staging jobs only, then removes those jobs and files. No inventory is committed.
require dirname(__DIR__).'/vendor/autoload.php';
$app = require dirname(__DIR__).'/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();
if (! app()->environment('local')) {
    throw new RuntimeException('Local development only');
}
$base = $argv[1] ?? 'http://127.0.0.1:8080';
$paddingMb = (int) ($argv[2] ?? 3);
if ($paddingMb < 1 || $paddingMb > 255) {
    throw new InvalidArgumentException('Padding must be between 1 and 255 MB');
}
$curl = curl_init();
curl_setopt_array($curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEFILE => '', CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 120]);
$request = function (string $path, ?array $fields = null) use ($base, $curl) {
    $token = '';
    foreach (curl_getinfo($curl, CURLINFO_COOKIELIST) ?: [] as $line) {
        $parts = explode("\t", $line);
        if (($parts[5] ?? '') === 'XSRF-TOKEN') {
            $token = urldecode($parts[6]);
        }
    }
    curl_setopt_array($curl, [CURLOPT_URL => $base.$path, CURLOPT_POST => $fields !== null, CURLOPT_HTTPHEADER => ['Accept: application/json', 'X-Requested-With: XMLHttpRequest', 'X-XSRF-TOKEN: '.$token]]);
    if ($fields !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, $fields);
    }
    $body = curl_exec($curl);
    $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($body === false || $code >= 400) {
        throw new RuntimeException($path.' HTTP '.$code.' '.substr((string) $body, 0, 400));
    }

    return $code;
};
$request('/login');
$request('/login', ['email' => config('superlink.admin_email'), 'password' => config('superlink.admin_password')]);
$jobs = [];
$temp = [];
$prefix = 'http-check-'.bin2hex(random_bytes(4));
try {
    foreach (['kmz', 'xlsx'] as $extension) {
        $path = tempnam(sys_get_temp_dir(), 'sl-upload-');
        $temp[] = $path;
        copy(base_path($extension === 'kmz' ? 'samples/network.kmz' : 'samples/customers-demo.xlsx'), $path);
        $zip = new ZipArchive;
        $zip->open($path);
        $padding = tempnam(sys_get_temp_dir(), 'sl-padding-');
        $temp[] = $padding;
        $stream = fopen($padding, 'wb');
        for ($i = 0; $i < $paddingMb; $i++) {
            fwrite($stream, random_bytes(1024 * 1024));
        }
        fclose($stream);
        $zip->addFile($padding, 'test-padding.bin');
        $zip->setCompressionName('test-padding.bin', ZipArchive::CM_STORE);
        $zip->close();
        $name = $prefix.'.'.$extension;
        $class = $extension === 'kmz' ? ImportJob::class : CustomerImportJob::class;
        $jobs[] = [$class, $name];
        $code = $request($extension === 'kmz' ? '/gis/import' : '/customers/import', ['mode' => 'INSERT_ONLY', 'file' => new CURLFile($path, 'application/octet-stream', $name)]);
        $j = $class::where('filename', $name)->firstOrFail();
        if ($j->status !== 'READY') {
            throw new RuntimeException($name.' status '.$j->status.': '.$j->error);
        }
        echo strtoupper($extension).' '.round(filesize($path) / 1024 / 1024, 2).' MB: HTTP '.$code.', READY, '.$j->total_rows." staged rows\n";
    }
} finally {
    foreach ($jobs as [$class,$name]) {
        foreach ($class::where('filename', $name)->get() as $j) {
            Storage::delete($j->path);
            $j->rows()->delete();
            $j->delete();
        }
    }
    foreach ($temp as $p) {
        if (is_file($p)) {
            unlink($p);
        }
    }
    curl_close($curl);
}
