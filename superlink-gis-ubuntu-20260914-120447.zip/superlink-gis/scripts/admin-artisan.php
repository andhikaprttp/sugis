<?php

// Explicit maintenance entrypoint; never used by the HTTP server or workers.
$credentials = json_decode(file_get_contents(dirname(__DIR__, 2).'/.tools/database-admin.json'), true, 512, JSON_THROW_ON_ERROR);
foreach (['DB_USERNAME' => $credentials['username'], 'DB_PASSWORD' => $credentials['password']] as $key => $value) {
    putenv($key.'='.$value);
    $_ENV[$key] = $_SERVER[$key] = $value;
}
require dirname(__DIR__).'/artisan';
