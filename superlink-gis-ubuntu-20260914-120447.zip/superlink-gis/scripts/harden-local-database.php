<?php

// One-time hardening for the portable PostgreSQL cluster in ../.tools.
// Administrative credentials are written outside the application/document root.
require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$config = config('database.connections.pgsql');
if ($config['host'] !== '127.0.0.1' || (string) $config['port'] !== '55432' || $config['username'] !== 'superlink') {
    throw new RuntimeException('Only the original portable local cluster is supported.');
}
$root = dirname(__DIR__, 2);
$adminFile = $root.'/.tools/database-admin.json';
$envFile = dirname(__DIR__).'/.env';
$hbaFile = $root.'/.tools/pgdata/pg_hba.conf';
if (file_exists($adminFile) || file_exists($hbaFile.'.pre-hardening')) {
    throw new RuntimeException('Hardening backup already exists; inspect before rerunning.');
}
$connect = fn ($db, $user, $password) => new PDO("pgsql:host=127.0.0.1;port=55432;dbname=$db", $user, $password, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$admin = $connect('superlink', $config['username'], $config['password']);
$runtimePassword = bin2hex(random_bytes(32));
$adminPassword = bin2hex(random_bytes(32));
// Persist recovery information before changing credentials.
if (file_put_contents($adminFile, json_encode(['host' => '127.0.0.1', 'port' => 55432, 'username' => 'superlink', 'password' => $adminPassword], JSON_PRETTY_PRINT)) === false || ! copy($hbaFile, $hbaFile.'.pre-hardening')) {
    throw new RuntimeException('Cannot save recovery files. No database changes applied.');
}
$admin->exec('CREATE ROLE superlink_runtime LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD '.$admin->quote($runtimePassword));
$admin->exec('ALTER ROLE superlink PASSWORD '.$admin->quote($adminPassword));
foreach (['superlink', 'superlink_test'] as $database) {
    $db = $connect($database, 'superlink', $adminPassword);
    $db->exec('GRANT CONNECT ON DATABASE '.$database.' TO superlink_runtime');
    $db->exec('REVOKE CREATE ON SCHEMA public FROM PUBLIC');
    $db->exec('GRANT USAGE ON SCHEMA public TO superlink_runtime');
    $db->exec('GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO superlink_runtime');
    $db->exec('GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO superlink_runtime');
    $db->exec('ALTER DEFAULT PRIVILEGES FOR ROLE superlink IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO superlink_runtime');
    $db->exec('ALTER DEFAULT PRIVILEGES FOR ROLE superlink IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO superlink_runtime');
}
$env = file_get_contents($envFile);
$env = preg_replace('/^DB_USERNAME=.*$/m', 'DB_USERNAME=superlink_runtime', $env);
$env = preg_replace('/^DB_PASSWORD=.*$/m', 'DB_PASSWORD='.$runtimePassword, $env);
if (file_put_contents($envFile, $env) === false) {
    throw new RuntimeException('Cannot update application credentials. Restore using saved administrative credentials.');
}
$hba = preg_replace('/\btrust\s*$/m', 'scram-sha-256', file_get_contents($hbaFile));
if (file_put_contents($hbaFile, $hba) === false) {
    throw new RuntimeException('Cannot update pg_hba.conf. Runtime role is configured, but password enforcement remains pending.');
}
$admin->query('SELECT pg_reload_conf()');
$runtime = $connect('superlink', 'superlink_runtime', $runtimePassword);
$runtime->query('SELECT count(*) FROM users')->fetchColumn();
try {
    $connect('superlink', 'superlink_runtime', 'deliberately-wrong-password');
    throw new RuntimeException('Incorrect password was accepted; inspect pg_hba.conf.');
} catch (PDOException $e) {
    echo "Runtime connection OK; incorrect password rejected.\n";
}
echo "Administrative credentials: ../.tools/database-admin.json (keep private).\n";
