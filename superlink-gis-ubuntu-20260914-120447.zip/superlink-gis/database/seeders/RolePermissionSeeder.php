<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $all = ['dashboard.view', 'operations.view', 'zones.view', 'blast.view', 'blast.manage', 'blast.send'];
        foreach (['customer', 'odp', 'odc', 'pole', 'network', 'survey'] as $domain) {
            foreach (['view', 'create', 'update', 'delete'] as $action) {
                $all[] = "$domain.$action";
            }
        }$all = [...$all, 'customer.import', 'customer.export', 'customer.restore', 'customer.location', 'odp.port.manage', 'survey.approve', 'installation.update', 'gis.import', 'gis.export', 'audit.view', 'settings.manage'];
        foreach ($all as $p) {
            Permission::firstOrCreate(['name' => $p, 'guard_name' => 'web']);
        }$view = array_values(array_filter($all, fn ($p) => str_ends_with($p, '.view') && $p !== 'audit.view'));
        $roles = ['ADMIN' => $all, 'NOC' => array_values(array_filter($all, fn ($p) => $p !== 'settings.manage' && $p !== 'customer.restore')), 'SURVEYOR' => [...$view, 'customer.create', 'customer.location', 'survey.create', 'survey.update'], 'TECHNICIAN' => [...$view, 'installation.update'], 'VIEWER' => $view];
        $roles['CUSTOMER_SERVICE'] = ['blast.view', 'blast.manage', 'blast.send', 'dashboard.view', 'customer.view', 'customer.create', 'customer.update', 'customer.import', 'customer.export'];
        foreach ($roles as $name => $permissions) {
            Role::firstOrCreate(['name' => $name, 'guard_name' => 'web'])->syncPermissions($permissions);
        }app(PermissionRegistrar::class)->forgetCachedPermissions();
    }
}
