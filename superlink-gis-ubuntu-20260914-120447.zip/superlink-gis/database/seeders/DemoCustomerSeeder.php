<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Services\Customer\CustomerService;
use Illuminate\Database\Seeder;

class DemoCustomerSeeder extends Seeder
{
    public function run(): void
    {
        foreach (['Pak Syukur', 'Bu Yuli', 'Andi Lala'] as $i => $name) {
            $code = 'CUST-DEMO-00'.($i + 1);
            if (Customer::where('customer_id', $code)->exists()) {
                continue;
            }$odp = GisObject::where('code', 'ODP-CNK-A2-01')->firstOrFail();
            $port = OdpPort::where('odp_id', $odp->id)->where('port_number', $i + 1)->firstOrFail();
            app(CustomerService::class)->save(['customer_id' => $code, 'name' => $name.' [DEMO]', 'phone' => '+62812000000'.($i + 1), 'address' => 'Alamat contoh Cinangka, bukan data pelanggan nyata', 'package_name' => 'Home 30 Mbps', 'status' => 'ACTIVE', 'geometry' => ['type' => 'Point', 'coordinates' => [106.760 + $i * .0005, -6.368]], 'port_id' => $port->id, 'notes' => 'Dummy development data'], null, 'SYSTEM');
        }
    }
}
