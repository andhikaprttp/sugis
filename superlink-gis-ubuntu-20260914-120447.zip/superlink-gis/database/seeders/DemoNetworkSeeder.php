<?php

namespace Database\Seeders;

use App\Models\GisObject;
use App\Services\Network\NetworkService;
use Illuminate\Database\Seeder;

class DemoNetworkSeeder extends Seeder
{
    public function run(): void
    {
        $s = app(NetworkService::class);
        $create = function ($code, $type, $lng, $lat, $extra = []) use ($s) {
            return GisObject::where('code', $code)->first() ?? $s->save(['code' => $code, 'name' => $code.' [DEMO]', 'object_type' => $type, 'geometry' => ['type' => 'Point', 'coordinates' => [$lng, $lat]], 'notes' => 'Dummy coordinates: development sample only', ...$extra], null, 'SYSTEM');
        };
        $pop = $create('POP-CINANGKA', 'POP', 106.758, -6.371);
        $odc = $create('ODC-CNK-A2', 'ODC', 106.759, -6.37, ['pop_id' => $pop->id, 'capacity' => 96]);
        for ($i = 1; $i <= 3; $i++) {
            $create('ODP-CNK-A2-0'.$i, 'ODP', 106.759 + $i * .001, -6.37 + $i * .0005, ['odc_id' => $odc->id, 'capacity' => 8, 'splitter_type' => '1:8']);
        }for ($i = 1; $i <= 6; $i++) {
            $create('POLE-CNK-00'.$i, 'POLE', 106.759 + $i * .0006, -6.3695, ['ownership' => 'SUPERLINK', 'height' => 7]);
        }
    }
}
