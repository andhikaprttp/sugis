<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        $email = config('superlink.admin_email');
        if (User::where('email', $email)->exists()) {
            return;
        }$password = config('superlink.admin_password');
        if (! $password || strlen($password) < 12) {
            throw new \RuntimeException('Set ADMIN_PASSWORD to at least 12 characters before seeding');
        }$u = User::create(['name' => 'Superlink Administrator', 'email' => $email, 'password' => $password]);
        $u->assignRole('ADMIN');
    }
}
