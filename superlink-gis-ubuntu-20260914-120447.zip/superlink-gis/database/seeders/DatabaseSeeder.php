<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([RolePermissionSeeder::class, AdminUserSeeder::class]);
        if (config('superlink.demo_seed')) {
            $this->call([DemoNetworkSeeder::class, DemoCustomerSeeder::class]);
        }
    }
}
