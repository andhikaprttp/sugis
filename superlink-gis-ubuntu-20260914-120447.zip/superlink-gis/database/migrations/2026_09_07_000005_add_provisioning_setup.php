<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('provisioning_olts', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('external_id')->unique();
            $table->string('host')->nullable();
            $table->timestamps();
        });
        Schema::create('provisioning_templates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('olt_id')->constrained('provisioning_olts')->restrictOnDelete();
            $table->string('name');
            $table->unsignedSmallInteger('vlan');
            $table->string('line_profile');
            $table->string('service_profile');
            $table->string('wan_profile');
            $table->string('tr069_profile');
            $table->string('binding');
            $table->timestamps();
        });
        Schema::create('provisioning_connections', function (Blueprint $table) {
            $table->id();
            $table->string('cms_url')->default('http://10.1.1.21');
            $table->string('pppoe_source')->default('UNCONFIGURED');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provisioning_templates');
        Schema::dropIfExists('provisioning_olts');
        Schema::dropIfExists('provisioning_connections');
    }
};
