<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('devices', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->string('asset_tag', 100)->unique();
            $t->string('serial_number')->unique();
            $t->string('type', 20);
            $t->string('vendor')->nullable();
            $t->string('model')->nullable();
            $t->string('status', 20)->default('IN_STOCK');
            $t->string('location')->nullable();
            $t->date('purchased_at')->nullable();
            $t->text('notes')->nullable();
            $t->foreignUuid('customer_id')->nullable()->constrained('customers');
            $t->timestamps();
            $t->index(['status', 'type']);
        });
        DB::statement("ALTER TABLE devices ADD CONSTRAINT device_status CHECK(status IN ('IN_STOCK','INSTALLED','DAMAGED','RETIRED')), ADD CONSTRAINT device_type CHECK(type IN ('ONT','ROUTER','STB','OTHER')), ADD CONSTRAINT device_assignment CHECK((status='INSTALLED')=(customer_id IS NOT NULL))");
        DB::statement("CREATE UNIQUE INDEX device_customer_ont ON devices(customer_id) WHERE type='ONT' AND customer_id IS NOT NULL");
        Schema::create('device_movements', function (Blueprint $t) {
            $t->bigIncrements('id');
            $t->foreignUuid('device_id')->constrained('devices');
            $t->string('action', 20);
            $t->string('from_status', 20)->nullable();
            $t->string('to_status', 20);
            $t->foreignUuid('customer_id')->nullable()->constrained('customers');
            $t->foreignId('user_id')->nullable()->constrained('users');
            $t->text('notes')->nullable();
            $t->timestamp('created_at')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('device_movements');
        Schema::dropIfExists('devices');
    }
};
