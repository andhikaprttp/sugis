<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['import_jobs', 'customer_import_jobs', 'export_jobs'] as $name) {
            Schema::create($name, function (Blueprint $t) {
                $t->uuid('id')->primary();
                $t->string('filename');
                $t->string('path');
                $t->foreignId('uploaded_by')->constrained('users');
                $t->string('status')->default('UPLOADED');
                $t->string('mode')->default('INSERT_ONLY');
                $t->jsonb('options')->default('{}');
                $t->jsonb('counts')->default('{}');
                foreach (['total_rows', 'valid_rows', 'invalid_rows', 'duplicate_rows', 'inserted_rows', 'updated_rows', 'skipped_rows'] as $f) {
                    $t->integer($f)->default(0);
                }$t->text('error')->nullable();
                $t->timestamps();
            });
        }
        foreach (['import_objects' => 'import_jobs', 'customer_import_rows' => 'customer_import_jobs'] as $name => $parent) {
            Schema::create($name, function (Blueprint $t) use ($parent) {
                $t->uuid('id')->primary();
                $t->foreignUuid('job_id')->constrained($parent)->cascadeOnDelete();
                $t->integer('row_number');
                $t->jsonb('data');
                $t->jsonb('existing')->nullable();
                $t->jsonb('errors')->default('[]');
                $t->jsonb('warnings')->default('[]');
                $t->string('validation')->default('VALID');
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        foreach (['customer_import_rows', 'import_objects', 'export_jobs', 'customer_import_jobs', 'import_jobs'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
