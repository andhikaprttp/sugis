<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('odc_port_observations', function (Blueprint $t) {
            $t->foreignUuid('id')->primary()->constrained('odcs');
            $t->unsignedInteger('capacity');
            $t->unsignedInteger('available');
            $t->foreignId('checked_by')->constrained('users');
            $t->timestampTz('checked_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('odc_port_observations');
    }
};
