<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('blast_campaigns', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->string('name');
            $t->text('template');
            $t->jsonb('schedule');
            $t->jsonb('occurrences');
            $t->boolean('enabled')->default(false);
            $t->foreignId('created_by')->constrained('users');
            $t->timestamps();
        });
        Schema::create('blast_recipients', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('campaign_id')->constrained('blast_campaigns')->cascadeOnDelete();
            $t->string('name');
            $t->string('phone', 20);
            $t->string('invoice')->default('');
            $t->string('amount', 100)->default('');
            $t->string('due_date', 100)->default('');
            $t->text('link')->nullable();
            $t->text('custom_message')->nullable();
            $t->boolean('selected')->default(true);
            $t->boolean('paid')->default(false);
            $t->timestamps();
            $t->unique(['campaign_id', 'phone', 'invoice']);
        });
        Schema::create('blast_deliveries', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('recipient_id')->constrained('blast_recipients')->cascadeOnDelete();
            $t->string('slot', 100);
            $t->timestampTz('scheduled_at');
            $t->boolean('manual')->default(false);
            $t->string('status')->default('PENDING');
            $t->string('phone', 20);
            $t->text('message');
            $t->string('provider_id')->nullable();
            $t->string('error')->nullable();
            $t->timestamps();
            $t->unique(['recipient_id', 'slot']);
            $t->index(['status', 'scheduled_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('blast_deliveries');
        Schema::dropIfExists('blast_recipients');
        Schema::dropIfExists('blast_campaigns');
    }
};
