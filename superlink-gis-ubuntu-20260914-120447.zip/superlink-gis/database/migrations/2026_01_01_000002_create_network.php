<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('CREATE EXTENSION IF NOT EXISTS postgis');
        Schema::create('gis_objects', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->string('name');
            $t->string('code')->nullable()->unique();
            $t->string('object_type')->index();
            $t->string('status')->default('ACTIVE');
            $t->text('description')->nullable();
            $t->text('notes')->nullable();
            $t->string('source')->default('WEB');
            $t->string('source_filename')->nullable();
            $t->string('original_name')->nullable();
            $t->uuid('area_id')->nullable();
            $t->uuid('pop_id')->nullable();
            $t->foreignId('created_by')->nullable()->constrained('users');
            $t->foreignId('updated_by')->nullable()->constrained('users');
            $t->timestamps();
            $t->softDeletes();
        });
        Schema::table('gis_objects', function (Blueprint $t) {
            $t->foreign('area_id')->references('id')->on('gis_objects');
            $t->foreign('pop_id')->references('id')->on('gis_objects');
        });
        DB::statement('ALTER TABLE gis_objects ADD COLUMN geometry geometry(Geometry,4326)');
        DB::statement("ALTER TABLE gis_objects ADD CONSTRAINT gis_type CHECK(object_type IN ('UNCLASSIFIED','POP','ODC','ODP','POLE','CLOSURE','CUSTOMER','PROSPECT','FIBER_ROUTE','AREA','OTHER')), ADD CONSTRAINT gis_geometry CHECK(geometry IS NULL OR (ST_IsValid(geometry) AND GeometryType(geometry) IN ('POINT','LINESTRING','POLYGON')))");
        DB::statement('CREATE INDEX gis_geometry_gist ON gis_objects USING gist(geometry)');
        DB::statement('CREATE INDEX gis_geography_gist ON gis_objects USING gist((geometry::geography))');
        foreach (['pops', 'odcs', 'odps', 'poles', 'closures', 'fiber_routes', 'coverage_areas'] as $name) {
            Schema::create($name, function (Blueprint $t) use ($name) {
                $t->foreignUuid('id')->primary()->constrained('gis_objects');
                if ($name === 'odcs') {
                    $t->foreignUuid('pop_id')->nullable()->constrained('pops');
                    $t->unsignedInteger('capacity')->default(0);
                }if ($name === 'odps') {
                    $t->foreignUuid('odc_id')->nullable()->constrained('odcs');
                    $t->unsignedInteger('capacity')->default(8);
                    $t->string('splitter_type')->nullable();
                    $t->date('installation_date')->nullable();
                }if ($name === 'poles') {
                    $t->string('ownership')->nullable();
                    $t->decimal('height', 6, 2)->nullable();
                }if ($name === 'fiber_routes') {
                    $t->string('cable_type')->default('DROP');
                    $t->unsignedInteger('fiber_count')->default(1);
                }$t->timestamps();
            });
        }
        DB::statement('ALTER TABLE odps ADD CONSTRAINT odp_capacity CHECK(capacity BETWEEN 0 AND 1024)');
        DB::statement('ALTER TABLE odcs ADD CONSTRAINT odc_capacity CHECK(capacity>=0)');
        Schema::create('customers', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('gis_object_id')->unique()->constrained('gis_objects');
            $t->string('customer_id')->unique();
            $t->string('name');
            foreach (['phone', 'secondary_phone', 'email', 'address', 'rt', 'rw', 'village', 'district', 'city', 'province', 'package_name', 'ont_model', 'ont_vendor', 'pppoe_username'] as $field) {
                $t->string($field)->nullable();
            }$t->unsignedInteger('package_speed')->nullable();
            $t->string('ont_serial_number')->nullable()->unique();
            $t->string('status')->default('PROSPECT');
            $t->foreignUuid('pop_id')->nullable()->constrained('pops');
            $t->date('installation_date')->nullable();
            $t->date('activation_date')->nullable();
            $t->timestamps();
            $t->softDeletes();
        });
        DB::statement("ALTER TABLE customers ADD CONSTRAINT customer_status CHECK(status IN ('PROSPECT','SURVEY','WAITING_INSTALLATION','ACTIVE','SUSPENDED','INACTIVE','TERMINATED'))");
        Schema::create('surveys', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('customer_id')->constrained();
            $t->foreignUuid('odp_id')->nullable()->constrained('odps');
            $t->foreignId('surveyor_id')->constrained('users');
            $t->foreignId('assigned_to')->nullable()->constrained('users');
            $t->string('status')->default('DRAFT');
            $t->jsonb('route_nodes')->default('[]');
            $t->double('straight_distance')->nullable();
            $t->double('route_distance')->default(0);
            $t->double('allowance')->default(0);
            $t->double('estimated_cable')->default(0);
            $t->text('notes')->nullable();
            $t->timestamps();
        });
        DB::statement('ALTER TABLE surveys ADD COLUMN route geometry(LineString,4326)');
        DB::statement("ALTER TABLE surveys ADD CONSTRAINT survey_status CHECK(status IN ('DRAFT','SURVEY','FEASIBLE','NOT_FEASIBLE','WAITING_APPROVAL','APPROVED','INSTALLATION','INSTALLED','CANCELLED'))");
        Schema::create('odp_ports', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('odp_id')->constrained('odps');
            $t->unsignedInteger('port_number');
            $t->string('status')->default('AVAILABLE');
            $t->foreignUuid('customer_id')->nullable()->unique()->constrained();
            $t->foreignUuid('reserved_for')->nullable()->unique()->constrained('surveys');
            $t->timestamp('reserved_at')->nullable();
            $t->timestamp('installed_at')->nullable();
            $t->text('notes')->nullable();
            $t->timestamps();
            $t->unique(['odp_id', 'port_number']);
            $t->index(['odp_id', 'status']);
        });
        DB::statement("ALTER TABLE odp_ports ADD CONSTRAINT port_status CHECK(status IN ('AVAILABLE','RESERVED','OCCUPIED','DAMAGED','DISABLED')), ADD CONSTRAINT port_customer CHECK((status='OCCUPIED')=(customer_id IS NOT NULL)), ADD CONSTRAINT port_reservation CHECK((status='RESERVED')=(reserved_for IS NOT NULL)), ADD CONSTRAINT port_positive CHECK(port_number>0)");
        DB::unprepared(<<<'SQL'
CREATE FUNCTION check_port_capacity() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
IF NEW.port_number > (SELECT capacity FROM odps WHERE id=NEW.odp_id) THEN RAISE EXCEPTION 'Port exceeds ODP capacity'; END IF; RETURN NEW; END $$;
CREATE TRIGGER port_capacity BEFORE INSERT OR UPDATE ON odp_ports FOR EACH ROW EXECUTE FUNCTION check_port_capacity();
CREATE FUNCTION check_odp_capacity() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
IF NEW.capacity < COALESCE((SELECT max(port_number) FROM odp_ports WHERE odp_id=NEW.id),0) THEN RAISE EXCEPTION 'Remove unused ports before reducing capacity'; END IF; RETURN NEW; END $$;
CREATE TRIGGER odp_capacity BEFORE UPDATE ON odps FOR EACH ROW EXECUTE FUNCTION check_odp_capacity();
SQL);
        Schema::create('fiber_segments', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignUuid('route_id')->constrained('fiber_routes');
            $t->integer('sequence');
            $t->foreignUuid('start_node_id')->constrained('gis_objects');
            $t->foreignUuid('end_node_id')->constrained('gis_objects');
            $t->string('cable_type');
            $t->unsignedInteger('fiber_count');
            $t->string('status')->default('ACTIVE');
            $t->timestamps();
            $t->unique(['route_id', 'sequence']);
        });
        DB::statement('ALTER TABLE fiber_segments ADD COLUMN geometry geometry(LineString,4326) NOT NULL, ADD COLUMN distance double precision GENERATED ALWAYS AS (ST_Length(geometry::geography)) STORED, ADD CONSTRAINT different_nodes CHECK(start_node_id<>end_node_id), ADD CONSTRAINT positive_fibers CHECK(fiber_count>0)');
        DB::statement('CREATE INDEX segment_geometry_gist ON fiber_segments USING gist(geometry)');
        Schema::create('settings', function (Blueprint $t) {
            $t->id();
            $t->double('search_radius_m')->default(500);
            $t->double('cable_allowance_percent')->default(10);
            $t->timestamps();
        });
        DB::statement('ALTER TABLE settings ADD CONSTRAINT settings_range CHECK(id=1 AND search_radius_m BETWEEN 1 AND 50000 AND cable_allowance_percent BETWEEN 0 AND 100)');
        DB::table('settings')->insert(['id' => 1, 'search_radius_m' => 500, 'cable_allowance_percent' => 10, 'created_at' => now(), 'updated_at' => now()]);
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained('users');
            $t->string('action');
            $t->string('model');
            $t->string('model_id')->nullable();
            $t->jsonb('old_values')->nullable();
            $t->jsonb('new_values')->nullable();
            $t->string('source')->default('WEB');
            $t->timestamp('created_at')->useCurrent();
            $t->index(['model', 'model_id']);
        });
    }

    public function down(): void
    {
        foreach (['audit_logs', 'settings', 'fiber_segments', 'odp_ports', 'surveys', 'customers', 'coverage_areas', 'fiber_routes', 'closures', 'poles', 'odps', 'odcs', 'pops', 'gis_objects'] as $t) {
            Schema::dropIfExists($t);
        }DB::unprepared('DROP FUNCTION IF EXISTS check_port_capacity(); DROP FUNCTION IF EXISTS check_odp_capacity();');
    }
};
