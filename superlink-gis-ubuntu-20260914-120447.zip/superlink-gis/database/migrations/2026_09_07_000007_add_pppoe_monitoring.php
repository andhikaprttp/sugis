<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pppoe_snapshots', function (Blueprint $t) {
            $t->uuid('customer_id')->primary();
            $t->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
            $t->string('username');
            $t->string('state');
            $t->string('ip')->nullable();
            $t->string('uptime')->nullable();
            $t->timestampTz('observed_at');
        });
        Schema::create('pppoe_poll_state', function (Blueprint $t) {
            $t->id();
            $t->string('error')->nullable();
            $t->timestampTz('last_success_at')->nullable();
            $t->timestampTz('last_attempt_at')->nullable();
        });
        Schema::create('pppoe_history', function (Blueprint $t) {
            $t->id();
            $t->unsignedInteger('up');
            $t->unsignedInteger('down');
            $t->unsignedInteger('unknown');
            $t->timestampTz('observed_at')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pppoe_history');
        Schema::dropIfExists('pppoe_poll_state');
        Schema::dropIfExists('pppoe_snapshots');
    }
};
