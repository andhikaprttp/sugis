<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('monitoring_incidents', function (Blueprint $t) {
            $t->id();
            $t->string('fingerprint', 64)->index();
            $t->string('kind');
            $t->string('status')->default('OPEN')->index();
            $t->string('severity');
            $t->json('context');
            $t->timestampTz('started_at');
            $t->timestampTz('confirmed_at')->nullable();
            $t->timestampTz('resolved_at')->nullable();
            $t->timestampTz('notified_at')->nullable();
            $t->timestampTz('recovery_at')->nullable();
            $t->string('delivery_status')->nullable();
            $t->boolean('alert_eligible')->default(false);
            $t->timestampTz('acknowledged_at')->nullable();
            $t->string('acknowledged_by')->nullable();
        });
        Schema::create('telegram_state', function (Blueprint $t) {
            $t->unsignedInteger('id')->primary();
            $t->bigInteger('update_offset')->default(0);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('telegram_state');
        Schema::dropIfExists('monitoring_incidents');
    }
};
