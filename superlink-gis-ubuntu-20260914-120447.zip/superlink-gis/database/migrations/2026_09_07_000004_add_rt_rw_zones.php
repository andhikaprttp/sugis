<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('coverage_areas', function (Blueprint $t) {
            $t->string('zone_level', 2)->nullable();
            $t->string('rt', 10)->nullable();
            $t->string('rw', 10)->nullable();
            $t->string('village')->nullable();
            $t->string('district')->nullable();
            $t->string('city')->nullable();
            $t->string('color', 7)->default('#14b8a6');
            $t->index(['zone_level', 'rw', 'rt']);
        });
        DB::statement("ALTER TABLE coverage_areas ADD CONSTRAINT zone_level_valid CHECK(zone_level IS NULL OR (zone_level='RW' AND rw IS NOT NULL AND rt IS NULL) OR (zone_level='RT' AND rw IS NOT NULL AND rt IS NOT NULL))");
        Schema::table('customers', fn (Blueprint $t) => $t->index(['city', 'district', 'village', 'rw', 'rt'], 'customers_region_idx'));
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE coverage_areas DROP CONSTRAINT zone_level_valid');
        Schema::table('coverage_areas', function (Blueprint $t) {
            $t->dropIndex(['zone_level', 'rw', 'rt']);
            $t->dropColumn(['zone_level', 'rt', 'rw', 'village', 'district', 'city', 'color']);
        });
        Schema::table('customers', fn (Blueprint $t) => $t->dropIndex('customers_region_idx'));
    }
};
