<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['import_objects', 'customer_import_rows'] as $table) {
            Schema::table($table, fn (Blueprint $t) => $t->index(['job_id', 'row_number']));
        }
    }

    public function down(): void
    {
        foreach (['import_objects', 'customer_import_rows'] as $table) {
            Schema::table($table, fn (Blueprint $t) => $t->dropIndex(['job_id', 'row_number']));
        }
    }
};
