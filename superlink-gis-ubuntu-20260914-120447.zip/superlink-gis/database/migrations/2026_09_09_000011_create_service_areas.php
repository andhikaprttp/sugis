<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_areas', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->string('name');
            $t->string('village');
            $t->string('district');
            $t->string('city');
            $t->text('notes')->nullable();
            $t->foreignId('created_by')->constrained('users');
            $t->timestamps();
            $t->unique(['city', 'district', 'village', 'name']);
        });
        foreach (['gis_objects', 'import_jobs'] as $table) {
            Schema::table($table, function (Blueprint $t) {
                $t->foreignUuid('service_area_id')->nullable()->constrained('service_areas')->restrictOnDelete();
                $t->index('service_area_id');
            });
        }
    }

    public function down(): void
    {
        foreach (['gis_objects', 'import_jobs'] as $table) {
            Schema::table($table, fn (Blueprint $t) => $t->dropConstrainedForeignId('service_area_id'));
        }
        Schema::dropIfExists('service_areas');
    }
};
