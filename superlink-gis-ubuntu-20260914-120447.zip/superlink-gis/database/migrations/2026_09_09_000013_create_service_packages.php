<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_packages', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->string('name')->unique();
            $t->unsignedInteger('speed_mbps');
            $t->decimal('price', 12, 2);
            $t->boolean('active')->default(true);
            $t->timestamps();
        });
        Schema::table('customers', function (Blueprint $t) {
            $t->foreignUuid('package_id')->nullable()->constrained('service_packages')->restrictOnDelete();
            $t->decimal('package_price', 12, 2)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('customers', function (Blueprint $t) {
            $t->dropConstrainedForeignId('package_id');
            $t->dropColumn('package_price');
        });
        Schema::dropIfExists('service_packages');
    }
};
