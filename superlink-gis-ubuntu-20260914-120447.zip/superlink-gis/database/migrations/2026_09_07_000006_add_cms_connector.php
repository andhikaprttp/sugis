<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('provisioning_connections', function (Blueprint $t) {
            $t->text('cms_token')->nullable();
            $t->boolean('enabled')->default(false);
            $t->boolean('allow_writes')->default(false);
            $t->timestampTz('last_sync_at')->nullable();
            $t->string('last_error')->nullable();
        });
        Schema::create('ont_snapshots', function (Blueprint $t) {
            $t->id();
            $t->string('sn')->unique();
            $t->string('olt_external_id')->nullable();
            $t->string('pon_id')->nullable();
            $t->unsignedInteger('onu_id')->nullable();
            $t->string('ont_state')->default('UNKNOWN');
            $t->string('admin_state')->default('UNKNOWN');
            $t->string('offline_reason')->nullable();
            $t->string('rx_power')->nullable();
            $t->string('tx_power')->nullable();
            $t->timestampTz('observed_at');
        });
        Schema::create('device_operations', function (Blueprint $t) {
            $t->uuid('id')->primary();
            $t->foreignId('user_id')->constrained('users');
            $t->uuid('customer_id');
            $t->string('action');
            $t->string('status')->default('QUEUED');
            $t->text('payload')->nullable();
            $t->string('stage')->default('QUEUED');
            $t->string('message')->nullable();
            $t->timestampTz('created_at');
            $t->timestampTz('updated_at');
        });
        Schema::create('ont_events', function (Blueprint $t) {
            $t->id();
            $t->string('sn');
            $t->string('olt_external_id')->nullable();
            $t->string('state');
            $t->string('reason')->nullable();
            $t->timestampTz('observed_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ont_events');
        Schema::dropIfExists('device_operations');
        Schema::dropIfExists('ont_snapshots');
        Schema::table('provisioning_connections', fn (Blueprint $t) => $t->dropColumn(['cms_token', 'enabled', 'allow_writes', 'last_sync_at', 'last_error']));
    }
};
