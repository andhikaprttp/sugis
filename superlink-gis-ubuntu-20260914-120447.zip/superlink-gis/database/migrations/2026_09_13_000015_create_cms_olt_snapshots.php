<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cms_olt_snapshots', function (Blueprint $t) {
            $t->string('device_id')->primary();
            $t->string('external_id')->nullable();
            $t->string('name');
            $t->string('host')->nullable();
            $t->string('model')->nullable();
            $t->string('sn')->nullable();
            $t->string('state', 20);
            $t->unsignedInteger('onu_count')->default(0);
            $t->unsignedInteger('online_count')->default(0);
            $t->timestampTz('observed_at');
        });
        Schema::table('ont_snapshots', fn (Blueprint $t) => $t->string('olt_device_id')->nullable()->index());
    }

    public function down(): void
    {
        Schema::table('ont_snapshots', fn (Blueprint $t) => $t->dropColumn('olt_device_id'));
        Schema::dropIfExists('cms_olt_snapshots');
    }
};
