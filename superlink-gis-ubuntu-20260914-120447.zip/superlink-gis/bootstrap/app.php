<?php

use App\Http\Middleware\HandleInertiaRequests;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Exceptions\PostTooLargeException;
use Illuminate\Http\Request;
use Spatie\Permission\Middleware\PermissionMiddleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
        $middleware->web(append: [\App\Http\Middleware\EnsureActiveUser::class, HandleInertiaRequests::class]);
        $middleware->alias(['permission' => PermissionMiddleware::class]);
    })->withExceptions(function (Exceptions $exceptions) {
        $exceptions->dontFlash(['cms_token', 'password', 'password_confirmation', 'current_password']);
        $exceptions->render(function (PostTooLargeException $e, Request $request) {
            $message = 'Upload terlalu besar. Maksimum file 256 MB; pilih file yang lebih kecil.';

            return $request->expectsJson() && ! $request->header('X-Inertia')
                ? response()->json(['message' => $message, 'errors' => ['file' => [$message]]], 422)
                : redirect()->back()->withErrors(['file' => $message]);
        });
    })->create();
