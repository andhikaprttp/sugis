<?php

use App\Jobs\SyncCdata;
use App\Jobs\SyncPppoe;
use App\Services\Blast\ReminderDispatcher;
use App\Services\Cdata\CdataSync;
use App\Services\Monitoring\IncidentMonitor;
use App\Services\Monitoring\PppoeMonitor;
use App\Services\Telegram\AlertSender;
use App\Services\Telegram\Poller;
use App\Services\Telegram\Transport;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schedule;

Artisan::command('cdata:sync', function () {
    app(CdataSync::class)->run();
    $this->info('Sinkronisasi CMS selesai.');
});
Schedule::job(new SyncCdata)->everyMinute()->when(fn () => DB::table('provisioning_connections')->where('id', 1)->where('enabled', true)->exists());
Schedule::call(function () {
    DB::table('device_operations')->whereIn('status', ['QUEUED', 'RUNNING'])->where('updated_at', '<', now()->subMinutes(20))->update(['status' => 'UNKNOWN', 'payload' => null, 'message' => 'Operasi melewati batas waktu. Rekonsiliasi perangkat diperlukan.', 'updated_at' => now()]);
})->everyFiveMinutes();

Artisan::command('pppoe:sync', function () {
    app(PppoeMonitor::class)->sync();
    $this->info('Polling PPPoE selesai.');
});
Schedule::job(new SyncPppoe)->everyTwoMinutes()->when(fn () => app(PppoeMonitor::class)->configured());

Artisan::command('blast:run', function () {
    app(ReminderDispatcher::class)->tick();
    $this->info('Reminder diperiksa.');
});
Schedule::command('blast:run')->everyMinute()->withoutOverlapping(10);

Artisan::command('telegram:poll', function () {
    app(Poller::class)->tick();
    $this->info('Command Telegram diperiksa.');
});
Artisan::command('telegram:alerts', function () {
    app(IncidentMonitor::class)->tick();
    app(AlertSender::class)->tick();
    $this->info('Incident dan alert diperiksa.');
});
Artisan::command('telegram:check', function () {
    $bot = app(Transport::class)->call('getMe');
    $this->info('Bot terhubung: @'.($bot['username'] ?? 'unknown'));
});
Schedule::command('telegram:poll')->everyTenSeconds()->withoutOverlapping(5)->when(fn () => config('telegram.enabled'));
Schedule::command('telegram:alerts')->everyMinute()->withoutOverlapping(5)->when(fn () => config('telegram.enabled'));
