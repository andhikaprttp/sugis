<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CdataController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ExchangeController;
use App\Http\Controllers\NetworkController;
use App\Http\Controllers\OperationsController;
use App\Http\Controllers\SurveyController;
use App\Http\Controllers\ZoneController;
use App\Jobs\SyncPppoe;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\ValidationException;

Route::get('/', fn () => redirect('/dashboard'));
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'create'])->name('login');
    Route::post('/login', [AuthController::class, 'store'])->middleware('throttle:login');
});
Route::middleware('auth')->group(function () {
    Route::get('/blast', [\App\Http\Controllers\BlastController::class, 'index'])->middleware('permission:blast.view');
    Route::post('/blast/csv', [\App\Http\Controllers\BlastController::class, 'csv'])->middleware(['permission:blast.manage', 'throttle:20,1']);
    Route::post('/blast', [\App\Http\Controllers\BlastController::class, 'store'])->middleware('permission:blast.manage');
    Route::get('/blast/{campaign}', [\App\Http\Controllers\BlastController::class, 'show'])->middleware('permission:blast.view');
    Route::put('/blast/{campaign}/schedule', [\App\Http\Controllers\BlastController::class, 'schedule'])->middleware('permission:blast.manage');
    Route::post('/blast/{campaign}/enabled', [\App\Http\Controllers\BlastController::class, 'toggle'])->middleware('permission:blast.send');
    Route::put('/blast/{campaign}/recipients/{recipient}', [\App\Http\Controllers\BlastController::class, 'recipient'])->middleware('permission:blast.manage');
    Route::post('/blast/{campaign}/recipients/{recipient}/send', [\App\Http\Controllers\BlastController::class, 'manual'])->middleware(['permission:blast.send', 'throttle:10,1']);

    Route::get('/devices/import-serials', [\App\Http\Controllers\OntImportController::class, 'index'])->middleware(['permission:network.update', 'permission:customer.view']);
    Route::post('/devices/import-serials/preview', [\App\Http\Controllers\OntImportController::class, 'preview'])->middleware(['permission:network.update', 'permission:customer.view', 'throttle:60,1']);
    Route::post('/devices/import-serials', [\App\Http\Controllers\OntImportController::class, 'store'])->middleware(['permission:network.update', 'permission:customer.view', 'throttle:10,1']);
    Route::get('/packages/options', [\App\Http\Controllers\PackageController::class, 'options'])->middleware('permission:customer.update');
    Route::get('/packages', [\App\Http\Controllers\PackageController::class, 'index'])->middleware('permission:customer.view');
    Route::post('/packages', [\App\Http\Controllers\PackageController::class, 'store'])->middleware('permission:settings.manage');
    Route::put('/packages/{package}', [\App\Http\Controllers\PackageController::class, 'update'])->middleware('permission:settings.manage');
    Route::get('/areas', [\App\Http\Controllers\ServiceAreaController::class, 'index'])->middleware('permission:gis.import');
    Route::get('/areas/create', [\App\Http\Controllers\ServiceAreaController::class, 'create'])->middleware('permission:gis.import');
    Route::post('/areas', [\App\Http\Controllers\ServiceAreaController::class, 'store'])->middleware('permission:gis.import');
    Route::get('/devices', [\App\Http\Controllers\DeviceController::class, 'index'])->middleware(['permission:network.view', 'permission:customer.view']);
    Route::get('/devices/customer-options', [\App\Http\Controllers\DeviceController::class, 'customers'])->middleware(['permission:network.update', 'permission:customer.update']);
    Route::post('/devices', [\App\Http\Controllers\DeviceController::class, 'store'])->middleware(['permission:network.update', 'permission:customer.view']);
    Route::put('/devices/{device}', [\App\Http\Controllers\DeviceController::class, 'update'])->middleware(['permission:network.update', 'permission:customer.view']);
    Route::post('/devices/{device}/transition', [\App\Http\Controllers\DeviceController::class, 'transition'])->middleware(['permission:network.update', 'permission:customer.view']);
    Route::post('/map/elevation', \App\Http\Controllers\ElevationController::class)->middleware(['permission:network.view', 'throttle:30,1']);
    Route::post('/monitoring/pppoe/sync', function () {
        try {
            SyncPppoe::dispatch();
        } catch (Throwable $e) {
            throw ValidationException::withMessages(['pppoe' => 'Polling gagal. Periksa konfigurasi router dan worker.']);
        }

return back()->with('success', 'Polling PPPoE diminta. Refresh untuk melihat hasil.');
    })->middleware(['permission:network.update', 'throttle:5,1']);
    Route::get('/cdata/customers', [CdataController::class, 'customers'])->middleware('permission:customer.view');
    Route::post('/cdata/sync', [CdataController::class, 'sync'])->middleware(['permission:network.update', 'throttle:10,1']);
    Route::get('/cdata/discover', [CdataController::class, 'discover'])->middleware(['permission:network.update', 'throttle:30,1']);
    Route::post('/cdata/operate', [CdataController::class, 'operate'])->middleware(['permission:network.update', 'permission:customer.update', 'throttle:10,1']);
    Route::post('/cdata/operations/{id}/reconcile', [CdataController::class, 'reconcile'])->middleware(['permission:network.update', 'permission:customer.update']);
    Route::get('/operations/{section}', [OperationsController::class, 'index'])->middleware(['permission:operations.view', 'permission:network.view', 'permission:customer.view']);
    Route::post('/operations/{section}', [OperationsController::class, 'save'])->middleware(['permission:operations.view', 'permission:network.view', 'permission:customer.view']);
    Route::post('/logout', [AuthController::class, 'destroy']);
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->middleware('permission:dashboard.view');
    Route::get('/map', [NetworkController::class, 'map'])->middleware('permission:network.view');
    Route::get('/network/{kind}', [NetworkController::class, 'index']);
    Route::get('/network/odps/{odp}/ports', [NetworkController::class, 'manage'])->middleware('permission:odp.view');
    Route::get('/network/odps/{odp}', [NetworkController::class, 'manage'])->middleware('permission:odp.view');
    Route::get('/customers', [CustomerController::class, 'index'])->middleware('permission:customer.view');
    Route::get('/customers/create', [CustomerController::class, 'create'])->middleware('permission:customer.create');
    Route::post('/customers', [CustomerController::class, 'store'])->middleware('permission:customer.create');
    Route::post('/customers/bulk', [CustomerController::class, 'bulk']);
    foreach (['customers' => 'customer', 'gis' => 'gis'] as $prefix => $permission) {
        Route::get('/'.$prefix.'/import', [ExchangeController::class, 'index'])->middleware('permission:'.$permission.'.import');
        Route::post('/'.$prefix.'/import', [ExchangeController::class, 'upload'])->middleware(['permission:'.$permission.'.import', 'throttle:uploads']);
        Route::get('/'.$prefix.'/import/{id}/review', [ExchangeController::class, 'review'])->middleware('permission:'.$permission.'.import');
        Route::get('/'.$prefix.'/import/{id}/selection', [ExchangeController::class, 'selection'])->middleware('permission:'.$permission.'.import');
        Route::post('/'.$prefix.'/import/{id}/commit', [ExchangeController::class, 'commit'])->middleware('permission:'.$permission.'.import');
        Route::post('/'.$prefix.'/import/{id}/cancel', [ExchangeController::class, 'cancel'])->middleware('permission:'.$permission.'.import');
        Route::get('/'.$prefix.'/export', [ExchangeController::class, 'exportPage'])->middleware('permission:'.$permission.'.export');
    }
    Route::get('/customers/template', [ExchangeController::class, 'template'])->middleware('permission:customer.import');
    Route::get('/customers/import/{job}/errors', [ExchangeController::class, 'errors'])->middleware('permission:customer.import');
    Route::post('/customers/export', [ExchangeController::class, 'customerExport'])->middleware('permission:customer.export');
    Route::get('/exports/{job}/download', [ExchangeController::class, 'download'])->middleware('permission:customer.export');
    Route::post('/gis/export', [ExchangeController::class, 'gisExport'])->middleware('permission:gis.export');
    Route::get('/customers/{customer}', [CustomerController::class, 'show'])->middleware('permission:customer.view');
    Route::get('/customers/{customer}/edit', [CustomerController::class, 'edit'])->middleware('permission:customer.update');
    Route::put('/customers/{customer}', [CustomerController::class, 'update'])->middleware('permission:customer.update');
    Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])->middleware('permission:customer.delete');
    Route::post('/customers/{customer}/deactivate', [CustomerController::class, 'deactivate'])->middleware('permission:customer.update');
    Route::get('/surveys', [SurveyController::class, 'index'])->middleware('permission:survey.view');
    Route::get('/surveys/create', [SurveyController::class, 'create'])->middleware('permission:survey.create');
    Route::post('/surveys', [SurveyController::class, 'store'])->middleware('permission:survey.create');
    Route::get('/surveys/{survey}', [SurveyController::class, 'show'])->middleware('permission:survey.view');
    Route::post('/surveys/{survey}/status', [SurveyController::class, 'transition']);
    Route::get('/audit-logs', [AdminController::class, 'audit'])->middleware('permission:audit.view');
    Route::get('/zones', [ZoneController::class, 'index'])->middleware('permission:zones.view');
    Route::get('/reports', [AdminController::class, 'dashboard'])->middleware('permission:network.view');
    Route::get('/settings', [AdminController::class, 'settings'])->middleware('permission:settings.manage');
    Route::put('/settings', [AdminController::class, 'saveSettings'])->middleware('permission:settings.manage');
    Route::put('/settings/users/{user}/role', [AdminController::class, 'changeRole'])->middleware('permission:settings.manage');
    Route::post('/settings/users', [AdminController::class, 'user'])->middleware('permission:settings.manage');
    require __DIR__.'/api.php';
});
