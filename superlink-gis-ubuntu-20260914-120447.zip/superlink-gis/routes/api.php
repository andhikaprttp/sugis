<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\NetworkController;
use App\Http\Controllers\SurveyController;
use Illuminate\Support\Facades\Route;

// Internal same-origin APIs use the web session AND CSRF middleware inherited from web.php.
Route::prefix('api')->group(function () {
    Route::get('/search', \App\Http\Controllers\GlobalSearchController::class)->middleware(['permission:dashboard.view', 'throttle:60,1']);
    Route::get('/map/recommendations', [\App\Http\Controllers\RecommendationController::class, 'index'])->middleware(['permission:network.view','throttle:30,1']);
    Route::post('/map/road-route', [\App\Http\Controllers\RecommendationController::class, 'route'])->middleware(['permission:network.view','throttle:30,1']);
    Route::put('/map/odcs/{id}/port-observation', [\App\Http\Controllers\RecommendationController::class, 'ports'])->middleware(['permission:odc.update','throttle:20,1']);
    Route::get('/map/objects', [NetworkController::class, 'objects'])->middleware('permission:network.view');
    Route::get('/map/nearest-odp', [SurveyController::class, 'nearest'])->middleware('permission:survey.view');
    Route::get('/gis-objects/{object}', [NetworkController::class, 'show'])->middleware('permission:network.view');
    Route::post('/gis-objects', [NetworkController::class, 'store']);
    Route::put('/gis-objects/{object}', [NetworkController::class, 'update']);
    Route::delete('/gis-objects/{object}', [NetworkController::class, 'destroy']);
    Route::get('/odps/{odp}/ports', [NetworkController::class, 'ports'])->middleware('permission:odp.view');
    Route::post('/odps/{odp}/ports/{port}', [NetworkController::class, 'portAction'])->middleware('permission:odp.port.manage');
    Route::post('/odps/{odp}/ports/{port}/reserve', [NetworkController::class, 'portAction'])->middleware('permission:odp.port.manage');
    Route::post('/surveys/{survey}/route', [SurveyController::class, 'route'])->middleware('permission:survey.update');
    Route::put('/customers/{customer}/location', [CustomerController::class, 'locate'])->middleware('permission:customer.location');
});
