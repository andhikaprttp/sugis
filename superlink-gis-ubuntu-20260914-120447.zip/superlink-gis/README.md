# Superlink FTTH GIS & Customer Survey System

Panduan cepat: [menjalankan localhost dan upload ke VPS](docs/LOCALHOST-DAN-VPS.md). Paket source tersedia di `output/releases` setelah menjalankan `scripts/package-server.py`.

Aplikasi modular Laravel untuk inventory FTTH, peta jaringan, database pelanggan, survey instalasi, dan pertukaran KML/KMZ/XLSX. PostgreSQL/PostGIS merupakan sumber data utama. Redis hanya dipakai untuk queue/cache.

## Stack dan struktur

- PHP 8.3, Laravel 12, Eloquent, Laravel migrations, session authentication dan CSRF.
- Spatie Laravel Permission: ADMIN, NOC, SURVEYOR, TECHNICIAN, VIEWER.
- Inertia 2, Vue 3, TypeScript, Vite, Tailwind, Leaflet/Geoman.
- Laravel Excel/PhpSpreadsheet untuk workbook, DOM/XMLWriter dan ZipArchive untuk KML/KMZ.
- PostgreSQL 17/PostGIS, Redis 7, PHP-FPM, Nginx, Docker Compose.

```text
app/Models/                 Eloquent models dan relasi
app/Services/               Customer, GIS, Network, Survey, audit
app/Http/Controllers/       HTTP/Inertia dan internal API
app/Jobs/                   Queue import GIS, import Excel, export pelanggan
database/migrations/       Platform, network/spatial, exchange
database/seeders/          Role, admin, demo network/customer
resources/js/Pages/        Halaman Inertia/Vue
resources/js/Map/          Leaflet workspace dan presentation
resources/js/theme.ts      Tema dan preferensi perangkat
routes/web.php             Halaman dan session auth
routes/api.php             API internal dengan session + CSRF
docker/                    Nginx dan konfigurasi PHP
samples/                   KML/KMZ contoh, data dummy
tests/                     PHPUnit unit, HTTP, integrasi, concurrency
```

Geometri EPSG:4326 disimpan kanonis pada `gis_objects.geometry`. Tabel POP/ODC/ODP/pole/customer merujuk objek tersebut; koordinat display berasal dari GeoJSON. Route dan segment menggunakan native PostGIS LineString. Semua query jarak menggunakan cast geography agar hasil dalam meter. GiST mengindeks geometry dan geography.

Topology pelanggan berasal dari satu `odp_ports.customer_id` yang unik, kemudian ODP → ODC → POP. `customers.pop_id` hanya untuk grouping pelanggan belum terhubung port. Ketersediaan port selalu dihitung dari individual port records. Audit log setara implementasi activity log menggunakan tabel `audit_logs` yang ditulis dalam transaksi business operation.

## Menjalankan Docker pada Ubuntu 24.04

Persyaratan: Docker Engine + Compose v2, koneksi registry saat build, port 8080 bebas. Mulai dari direktori `superlink-gis`.

```bash
cp .env.example .env
```

Edit `.env`: isi `DB_PASSWORD`, `ADMIN_PASSWORD` minimal 12 karakter, dan `APP_KEY` dengan key acak. Jangan memakai password development untuk produksi. Key dapat dibuat tanpa PHP lokal:

```bash
docker run --rm php:8.3-cli php -r 'echo "base64:".base64_encode(random_bytes(32)).PHP_EOL;'
```

Salin hasil ke `APP_KEY`. Untuk demo, set `DEMO_SEED=true`; untuk produksi gunakan `APP_ENV=production`, `DEMO_SEED=false`, `APP_DEBUG=false`, `APP_URL` sesuai domain. Pertahankan `DB_HOST=postgres`, `DB_PORT=5432`, `REDIS_HOST=redis`, `QUEUE_CONNECTION=redis`, `CACHE_STORE=redis` untuk Compose.

```bash
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 init app queue nginx
```

Buka **http://localhost:8080**. Service `init` membuat direktori storage, menjalankan `migrate --force` dan seeder; app/worker menunggu init selesai. Seeder admin idempotent: tidak mengganti password akun existing. Email default `admin@superlink.local`, password mengikuti `ADMIN_PASSWORD` yang Anda isi.

Service scheduler menjalankan polling CMS dan pemeriksaan pekerjaan yang terhenti. Worker menjalankan `queue:work`; timeout 900 detik dan Redis retry_after 960 detik. Storage private dibagi app dan worker. PostgreSQL/Redis tidak dipublish ke host.

Untuk build perubahan frontend/backend:

```bash
docker compose up -d --build
```

## Development tanpa Docker

Instal PHP 8.3 dengan pdo_pgsql, pgsql, mbstring, xml/dom/xmlwriter, zip, intl, bcmath, gd, fileinfo, curl dan openssl; Composer; Node 22/npm; PostgreSQL/PostGIS; Redis.

```bash
composer install
npm ci
cp .env.example .env
php artisan key:generate
```

Sesuaikan DB/Redis ke host lokal dan isi ADMIN_PASSWORD. Buat database `superlink` dan `superlink_test` dengan user yang dapat mengaktifkan PostGIS.

```bash
php artisan migrate
php artisan db:seed
npm run build
php artisan serve --host=127.0.0.1 --port=8000
```

Terminal terpisah:

```bash
php artisan queue:work redis --timeout=900 --tries=1
npm run dev
```

URL development standar **http://localhost:8000**, Vite dev server default **5173**. Untuk menjalankan compiled assets saja, `npm run dev` tidak diperlukan.

Pada workspace Windows sesi pengembangan ini runtime portable tersedia di `../.tools`. Database lokal menggunakan `127.0.0.1:55432`, dan server verifikasi dijalankan di **http://127.0.0.1:8088**. `.env` lokal memakai queue `sync` dan file cache agar pengujian tidak bergantung Redis; deployment Compose memakai Redis sesuai `.env.example`.

```powershell
# Dari direktori superlink-gis
& '../.tools/php/php.exe' -d upload_max_filesize=256M -d post_max_size=260M -S 127.0.0.1:8080 -t public
```

Akun demo lokal yang sudah diseed: `admin@superlink.local` / `Superlink-Dev-2026!`. Data dengan `[DEMO]` dan source SYSTEM menggunakan koordinat dummy Cinangka. File runtime portable dan `.env` bukan bagian aplikasi yang perlu dideploy.

## Penggunaan

**Impor stok ONT dari teks:** buka **Impor serial ONT** pada navigasi atau dari Perangkat & Stok. Tempel satu serial per baris; spasi, koma, titik koma, serta tabel Markdown dengan `|` juga diterima. Preview menghitung jumlah serial siap masuk, duplikat teks, dan serial yang sudah terdaftar. Maksimum 1.000 serial; serial dinormalisasi menjadi huruf besar. Isi lokasi gudang (vendor/model opsional), lalu klik Masukkan ONT ke stok. Serial lama dilewati tanpa mengubah penempatan yang sudah ada; input invalid menggagalkan seluruh impor. Kode aset dibuat otomatis, status awal `IN_STOCK`, dan stok masuk dicatat pada riwayat. Jumlah stok otomatis diperbarui dan ONT bisa di-assign melalui alur pemasangan yang sama. Contoh delapan serial pada permintaan diuji di database tes, bukan ditambahkan ke stok operasional.

**Harga paket:** menu Harga paket menampilkan nama, kecepatan Mbps, harga rupiah per bulan, dan status aktif. Pengguna dengan `settings.manage` dapat membuat/mengedit/menonaktifkan paket; pengguna dengan `customer.view` dapat melihat katalog. Detail pelanggan → **Paket langganan → Pilih / ganti paket** menyediakan pencarian nama dan dropdown hingga 30 paket aktif, beserta kecepatan dan harga. Penyimpanan memerlukan `customer.update`. Nama, kecepatan, dan harga diambil dari katalog di server. Pelanggan menyimpan harga pada saat pemilihan; perubahan harga katalog tidak otomatis mengubah pelanggan lama. Pilih ulang untuk menerapkan harga terbaru, atau pilih Tanpa paket untuk melepaskannya. Paket nonaktif tidak dapat digunakan untuk pilihan baru. Data paket bebas pada pelanggan lama tetap dipertahankan sampai pengguna memilih paket katalog.

Migration `2026_09_09_000013_create_service_packages` sudah diterapkan pada database portable dan database tes; jalankan migration menggunakan akun administrasi saat memperbarui server lain.

**Pencarian global dashboard:** ketik minimal dua karakter pada kartu **Pencarian global**. Pencarian berjalan setelah jeda 350 ms dan menampilkan maksimal lima hasil per kategori: pelanggan, ODP, ODC, OLT, dan perangkat. Cari pelanggan berdasarkan nama/ID/telepon/alamat/serial ONT/username PPPoE, jaringan berdasarkan nama/kode, OLT berdasarkan nama/external ID/host, dan perangkat berdasarkan kode aset/serial/vendor/model. Klik hasil untuk membuka pelanggan, port ODP, fokus peta ODC, daftar OLT yang difilter ke perangkat itu, atau inventori aset terkait. Hasil mengikuti hak akses halaman tujuan; akun Customer Service hanya melihat pelanggan. Hasil yang sudah dihapus tidak ditampilkan. Endpoint internal `GET /api/search?q=...` memakai sesi, validasi input, dan throttle 60 request/menit.

Pemeriksaan lanjutan memperbaiki filter pencarian OLT yang sebelumnya tidak diterapkan ke daftar OLT, pencarian stok `0` yang sebelumnya terabaikan, serta payload serial/kode aset berupa array yang kini ditolak dengan validasi 422. Fokus peta dari hasil pencarian juga mengambil objek secara langsung bila objek tersebut belum termasuk daftar peta awal.

**Assign stok ONT:** buka detail pelanggan → **Assign ONT dari stok**. Daftar menampilkan ONT `IN_STOCK` dan pelanggan tujuan sudah dipilih. Klik **Assign pelanggan**, periksa serial dan nama tujuan, lalu Simpan. Dari Perangkat & Stok, gunakan pintasan **Stok ONT tersedia** untuk mencari pelanggan secara manual. Hasil pencarian menandai pelanggan yang sudah memiliki ONT atau serial lama yang berbeda. Satu pelanggan tetap hanya dapat memiliki satu ONT inventori; penempatan dan pengembalian dicatat pada riwayat mutasi.

**Tambah cakupan KMZ:** buka **Area Coverage → Tambah Area**. Pilih daerah yang sudah ada atau simpan daerah baru dengan nama area, kelurahan/desa, kecamatan, dan kota/kabupaten. Unggah KMZ/KML, tinjau klasifikasi objek, lalu commit. Untuk memperluas area yang sama, pilih **Tambah KMZ ke area** pada daftar area. Setiap upload GIS baru wajib memiliki daerah tujuan; baris impor tidak bisa mengganti daerah tujuan job. Data sebelumnya tetap tersimpan. Peta menyediakan filter daerah; jaringan lama yang belum dikelompokkan tetap tersedia di **Semua area**. Daerah adalah pengelompokan operasional, sedangkan polygon AREA/RT/RW tetap merupakan geometri batas pada peta.

**Pemuatan data:** detail aset peta dan ketersediaan port diambil secara batch, filter stok memakai partial reload tanpa menghitung ulang grafik/riwayat, dan peta pada detail/form pelanggan serta review impor baru diunduh ketika dibuka. Staging KMZ ditulis per 500 baris, dengan indeks `(job_id, row_number)` untuk pagination review. Tes 12 ODP tanpa parent menghasilkan 24 query saat serialisasi individual menjadi 2 query dengan batch; angka ini mengukur query, bukan waktu muat jaringan/browser.

Migration baru `000011_create_service_areas` dan `000012_index_import_review` sudah diterapkan ke database portable lokal dan database tes. Pada lingkungan lain, jalankan migration menggunakan akun administrasi database. Data jaringan existing tidak dihapus atau ditetapkan ke daerah secara otomatis.

**Perangkat & Stok:** buka `/devices` dari menu Infrastructure. Tambahkan setiap unit ONT, router, STB, atau perangkat lain dengan kode aset, serial unik, vendor/model, lokasi gudang, tanggal pembelian, dan catatan. Serial dan kode aset dinormalisasi menjadi huruf kapital. Stok dihitung dari unit berstatus `IN_STOCK`; status lain adalah `INSTALLED`, `DAMAGED`, dan `RETIRED`. Detail vendor/model/tanggal/catatan dapat diedit saat perangkat tidak terpasang; identitas aset dan serial tetap.

Gunakan **Pasang** untuk mencari pelanggan berdasarkan nama/ID, lalu hubungkan perangkat. Satu pelanggan hanya boleh memiliki satu ONT inventori; router/STB dapat ditambahkan terpisah. Pemasangan ONT mengisi serial/model/vendor pelanggan, dan pengembalian mengosongkannya. Untuk ONT lama yang baru tercatat di data pelanggan, daftarkan serial yang sama di inventori kemudian pasang ke pelanggan tersebut; serial berbeda ditolak agar data lama tidak tertimpa. Perubahan ini mencatat aset lokal, tidak mengirim perintah provisioning ke CMS/ONT. Perangkat yang dikembalikan dapat masuk stok, rusak, atau pensiun. Pelanggan dengan aset terpasang harus mengembalikan aset sebelum dihapus.

Grafik menampilkan komposisi status, stok per jenis, dan transaksi masuk/pasang/kembali selama enam bulan. Ringkasan selalu mencakup seluruh inventori, sedangkan daftar memiliki filter status/jenis/pelanggan dan pencarian aset/serial/model. Riwayat menampilkan 30 mutasi terakhir; audit lengkap juga dicatat. Data pelanggan lama tidak otomatis dianggap sebagai stok atau diubah saat migrasi. Hak baca memakai `network.view` + `customer.view`; pengelolaan memakai `network.update`, dengan tambahan `customer.update` untuk pemasangan/pengembalian. Jalankan `php artisan migrate --force` sebelum mengakses fitur pada instalasi lain.

**Password login:** ikon mata di samping kolom password menampilkan/menyembunyikan teks. Password tersembunyi secara default, kembali tersembunyi saat submit, dan kolom dibersihkan setelah request login selesai.

**Pilihan gaya peta:** buka tombol **Gaya** di kanan atas peta untuk Auto, Jalan, Fokus, Malam, Kontras, Sepia, atau Blueprint. Preferensi disimpan di browser. Semua pilihan adalah gaya visual tile OpenStreetMap yang sama; bukan sumber satelit/topografi baru. Filter warna hanya diterapkan pada peta dasar, sehingga warna status aset dan zona RT/RW tetap independen. Menu **Layers & Zona RT/RW** mengatur visibilitas objek jaringan.

**OLT & Pelanggan Online:** delapan menu baru tersedia di `/operations/monitoring`, `/operations/olts`, `/operations/templates`, `/operations/activation`, `/operations/actions`, `/operations/alarms`, `/operations/history`, dan `/operations/connection`. Daftar OLT manual, template VLAN/profil per OLT, serta alamat CMS/sumber PPPoE disimpan di PostgreSQL dengan validasi, hak akses, dan audit. Template pilihan otomatis mengisi pratinjau layanan di halaman aktivasi. Gunakan external ID dari CMS untuk pemetaan OLT; konfigurasi ini belum diverifikasi ke perangkat.

**Konektor CMS CDATA:** konfigurasi token terenkripsi, sinkronisasi OLT/ONT, pencocokan serial pelanggan, autodiscovery, suspend/resume dengan verifikasi SN, dan registrasi GPON SN + konfigurasi WAN PPPoE sudah diimplementasikan. Halaman riwayat mencatat tahap serta hasil operasi. Aktifkan konektor di `/operations/connection`; izinkan perintah tulis hanya setelah memeriksa pemetaan OLT/profil. Scheduler Compose meminta sync setiap dua menit. Detail setup server **10.1.1.40 ? CMS 10.1.1.21** tersedia di [Panduan Ubuntu 24.04](docs/UBUNTU-24.04.md).

Status sesi PPPoE tersedia melalui konektor RouterOS 7 opsional; RADIUS/billing lain belum diintegrasikan. ONT online tidak diperlakukan sebagai sesi PPPoE online. Dashboard menampilkan UP/DOWN/UNKNOWN, komposisi dan riwayat polling. Setup konektor serta basemap Satelit/Topografi/Jalan detail ada di [Peta dan PPPoE](docs/PETA-DAN-PPPOE.md). Integrasi CDATA diuji dengan respons tiruan, belum terhadap CMS/firmware live. Template OLT harus menghasilkan WAN PPPoE VLAN yang dipilih; flow memperbarui WAN existing, tidak mengarang konfigurasi IP/IPv6 perangkat. Hasil sebagian atau timeout ditandai UNKNOWN dan perlu rekonsiliasi.

**Zona RT/RW:** buka peta, gambar Polygon, pilih jenis AREA, lalu pilih zona RT atau RW. Isi nomor RW (dan RT untuk zona RT), wilayah administrasi, nama, serta warna. Batas wilayah digambar berdasarkan data Anda; aplikasi tidak membuat batas administratif otomatis. Panel layer dapat menampilkan/menyembunyikan seluruh zona RT, RW, coverage umum, atau setiap polygon secara terpisah. Metadata zona dapat diedit melalui detail objek.

**Statistik RT/RW:** menu Zona & Statistik RT/RW (`/zones`) menampilkan total pelanggan, aktif, pending, suspended, nonaktif, dan tanpa koordinat, dengan filter wilayah. Pengelompokan berdasarkan alamat pelanggan; nomor `1` dan `001` disatukan, tetapi kelurahan berbeda tetap terpisah. Tabel polygon menghitung pelanggan berkoordinat yang berada di dalam/di batas polygon secara terpisah. Polygon bertumpuk dapat menghitung pelanggan yang sama; angka spasial bukan total unik antar-zona.

**Batas upload lokal:** aplikasi menerima maksimal 256 MB per file. PHP harus memakai `upload_max_filesize=256M` dan `post_max_size=260M`; restart server setelah mengubah php.ini. Nginx memakai batas request 260 MB untuk memberi ruang multipart. File yang gagal diproses tampil di halaman review dengan pesan error. Upload tetap berupa staging sampai Anda menekan Commit.

Untuk memakai folder sementara milik proyek pada Windows, jalankan perintah berikut dari direktori `superlink-gis` setelah server lama dihentikan. `scripts/serve-local.ps1` menyediakan perintah yang sama bila kebijakan PowerShell mengizinkan script.

```powershell
New-Item -ItemType Directory -Force -Path storage/app/upload-tmp | Out-Null
$uploadTemp=(Resolve-Path storage/app/upload-tmp).Path
& '../.tools/php/php.exe' -d upload_max_filesize=256M -d post_max_size=260M -d "upload_tmp_dir=$uploadTemp" -S 127.0.0.1:8080 -t public
```

Kegagalan penerimaan file oleh PHP sekarang menampilkan penyebab khusus dan mencatat kode upload di log, sebelum membuat riwayat import.

Jika memakai alamat `127.0.0.1:8088`, restart proses pada port **8088** juga: ganti `127.0.0.1:8080` pada perintah di atas menjadi `127.0.0.1:8088`, atau gunakan `scripts/serve-local.ps1 -Port 8088`. Proses PHP yang sudah berjalan menyimpan konfigurasi lamanya; restart port 8080 tidak memperbarui proses port 8088.

Batas 256 MB berlaku untuk KMZ, KML, dan XLSX. Batas isi arsip setelah dekompresi adalah 512 MB; proteksi path traversal, rasio kompresi, serta maksimum 20.000 objek/baris tetap aktif. Ukuran upload yang diizinkan tidak menjamin workbook/XML besar dapat diproses dalam memory limit server.

**Map dan tema:** pilih ikon matahari/bulan/perangkat di header atau halaman login. Preferensi tema disimpan hanya pada browser, bukan data jaringan. Mode Auto peta mengikuti tema; Jalan menampilkan OSM asli, Fokus mengurangi saturasi tile, Malam memberi gaya gelap pada tile OSM. Marker/label/geometry tidak di-invert. Ketiga tampilan menggunakan sumber peta OSM yang sama, bukan citra satelit. Tombol kanan menyediakan fit network, lokasi perangkat, toggle label dan refresh. Geolocation membutuhkan izin browser dan secure context (HTTPS atau localhost).

**GIS CRUD:** gambar marker/line/polygon melalui toolbar peta. Klik objek untuk metadata, koordinat, classification, geometry editing, atau soft delete. ODP dapat diperbesar/diperkecil kapasitasnya; port non-AVAILABLE tidak dapat dihapus saat kapasitas turun. ODC memiliki child ODP. Parent berdependency tidak dapat dihapus.

**Fiber:** pilih urutan node untuk membentuk segment. Jika line dibuat/import sebagai FIBER_ROUTE tanpa pilihan node, backend membuat dua endpoint UNCLASSIFIED yang dapat diklasifikasikan kemudian, tanpa menganggapnya sebagai pole. Bentuk line tetap dipertahankan. Edit jalur harus tetap melewati node existing; pindahkan node atau pilih ulang node untuk mengubah endpoint. Memindahkan node memperbarui segment dan jarak jaringan. Route survey mempertahankan snapshot saat dihitung.

**KML/KMZ:** GIS Import → upload → worker → review. Pilih valid rows (halaman atau seluruh file), set type/code/capacity/area/POP, periksa preview peta, kemudian Commit. Objek awal UNCLASSIFIED. Invalid geometry harus diperbaiki pada file dan di-upload ulang. KML description dibaca sebagai teks; DTD/entity ditolak, ZIP tidak diekstrak ke path pengguna, jumlah/ukuran/rasio kompresi dibatasi. File contoh di `samples/`.

**Customers:** create/edit, detail, lokasi, assignment port, search/filter/sort, visibility kolom, pagination, bulk status/POP/delete/restore. Change Port memvalidasi target dan melepaskan port lama dalam transaksi. Deactivate & Release Port menonaktifkan customer dan membuka port. Delete ditolak selama masih ada dependency.

**Excel:** download template, isi header yang dikenal (urutan bebas), upload XLSX. INSERT_ONLY menandai duplicate; UPSERT memperlihatkan existing → incoming. Review warning/error dan topology sebelum Commit. Commit mengecek ulang data/customer/port; konflik menggagalkan transaksi. Kolom identitas kosong dapat mengganti nilai lama pada UPSERT; tanpa port baru, assignment port lama tetap dipertahankan. Error report tersedia. Export dapat memakai filter/selection, menghasilkan Customers/Summary/Metadata, header bold, autofilter, freeze row dan cell string aman dari formula injection. Export disiapkan worker dan diunduh oleh pemilik/admin.

**Survey:** buat prospect/customer dan lokasi; buat survey; pilih kandidat ODP ACTIVE dengan AVAILABLE port dalam radius settings; pilih node manual dan simpan kalkulasi. Alur: DRAFT → SURVEY → FEASIBLE / WAITING_APPROVAL → APPROVED → INSTALLATION → INSTALLED. Approval NOC/admin; reservasi pada survey APPROVED; instalasi mengubah RESERVED menjadi OCCUPIED. Teknisi hanya boleh memperbarui instalasi assignment miliknya. Allowance dan radius configurable pada Settings, bukan konstanta business logic.

## Testing

Gunakan database khusus `superlink_test`, bukan production. Feature tests memerlukan PostGIS nyata; tidak menggunakan SQLite pengganti.

```bash
DB_DATABASE=superlink_test php artisan migrate --force
php artisan test
npm test
npm run build
vendor/bin/pint --test
```

PowerShell:

```powershell
$env:DB_DATABASE='superlink_test'
php artisan migrate --force
php vendor/phpunit/phpunit/phpunit --testdox
Remove-Item Env:DB_DATABASE
```

Tes meliputi parser/security, login/RBAC, GIS/ODP/customer CRUD, kapasitas, nearest ODP, survey estimate, reservasi/assignment, XLSX preview/duplicate/conflict/export, audit, HTTP pages dan perebutan port oleh **dua proses PHP terpisah**. Tes frontend memeriksa semantik warna availability dan pemilihan tema/peta. Test report final dicatat di `docs/VALIDATION.md`.

## Operasional dan produksi

- Terminasi TLS di reverse proxy, set `SESSION_SECURE_COOKIE=true`, domain APP_URL benar, dan APP_DEBUG=false. Jangan expose PHP-FPM/PostgreSQL/Redis ke internet.
- Simpan APP_KEY tetap dan backup dengan aman. Rotasi password development; gunakan user database khusus aplikasi sesuai kebijakan deployment.
- Backup PostgreSQL dengan `pg_dump` dan storage private; uji restore berkala. Excel/KMZ adalah pertukaran data, bukan pengganti backup database.
- Backup sebelum migration; gunakan `php artisan migrate --force`, **jangan** migrate:fresh pada production.
- Monitor `docker compose logs queue`, failed_jobs, disk uploads/exports, memory worker. Retensi file private perlu kebijakan operasional.
- Tile OSM membutuhkan internet dan pemakaian sesuai kebijakan penyedia. Untuk traffic besar/offline gunakan tile server sendiri; atribusi tetap ditampilkan.

Contoh backup:

```bash
docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > superlink-backup.dump
docker compose exec -T app tar -czf - -C storage app/private > superlink-private-files.tar.gz
```

## Batas verifikasi dan pengembangan lanjutan

Total tiang di dashboard menggabungkan POLE, ODP, dan ODC dengan koordinat XY persis sama sebagai satu tiang fisik. Koordinat berdekatan tidak digabung; data tanpa koordinat dihitung per objek. Objek yang dihapus tidak masuk hitungan. Ringkasan tiang di peta memakai aturan sama untuk aset yang sedang ditampilkan; filter dan batas pemuatan peta dapat membuat angkanya berbeda dari total dashboard. Daftar perangkat ODP/ODC/POLE tetap menunjukkan jumlah masing-masing jenis.

Pilihan **Gaya → Satelit Esri** memakai World Imagery tanpa API key. Sumber ini menjadi alternatif MapTiler, dengan ketajaman dan usia citra berbeda menurut lokasi. Zoom 20–22 memperbesar tile level 19 dan tidak menambah resolusi asli. Atribusi penyedia tetap ditampilkan; kegagalan pemuatan kembali ke OpenStreetMap. Akses publik tanpa key bukan jaminan lisensi komersial tanpa batas; penggunaan mengikuti [ketentuan Esri](https://www.esri.com/en-us/legal/terms/web-site-service). Informasi detail citra: [World Imagery](https://www.esri.com/arcgis-blog/products/imagery/imagery/learning-more-about-the-world-imagery-basemap).

Fitur Reminder WhatsApp tersedia melalui menu sidebar `/blast`: impor CSV DOKU, nomor manual, template, jadwal bulanan, tanda lunas, dan riwayat API. Tautan WhatsApp Web tetap manual; otomatis memerlukan API pengirim dan scheduler. Lihat [panduan konfigurasi dan penggunaan](docs/WHATSAPP-REMINDERS.md).

- Docker Engine dan browser automation tidak tersedia dalam sesi ini. Build image/Compose dan visual/interaction QA browser perlu diverifikasi pada target deployment; tidak diklaim sudah lulus.
- Map load V1 dibatasi 5.000 objek per request; API mendukung bbox. Untuk jaringan besar, lanjutkan viewport fetching/clustering dan pengujian load.
- Upload maksimal 256 MB/20.000 objek/baris; parsing di worker, commit batch masih satu transaksi HTTP. Uji batch besar terhadap resource VPS sebelum penggunaan operasional.
- KML hanya mendukung Point, LineString, Polygon dan MultiGeometry dari jenis tersebut; style Google Earth, altitude, photo/overlay tidak direplikasi.
- CSV, automatic routing, OLT/ONT integration, RADIUS, monitoring, foto survey, GPS tracking, PWA dan work order adalah perluasan berikutnya; V1 memakai manual route dan data teknis ONT.
- Password reset email/2FA, retensi upload otomatis, job retry UI dan pengujian end-to-end browser dapat ditambahkan pada tahap hardening.
