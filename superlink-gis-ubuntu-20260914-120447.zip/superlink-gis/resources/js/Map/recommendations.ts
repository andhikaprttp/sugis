export function terrainCost(distance:number,heights:(number|null)[]):number|null {
 if(heights.length<2||heights.some(v=>v===null||!Number.isFinite(v)))return null;
 let change=0;for(let i=1;i<heights.length;i++)change+=Math.abs(heights[i]!-heights[i-1]!);
 return distance+10*change;
}
export function rankCandidates(rows:any[],mode:string):any[] {
 return [...rows].sort((a,b)=>{
  if(mode==='terrain')return (a.terrain??Infinity)-(b.terrain??Infinity)||a.distance-b.distance;
  if(mode==='ports')return (b.available??-1)-(a.available??-1)||(a.road_distance??Infinity)-(b.road_distance??Infinity)||a.distance-b.distance;
  return (a.road_distance??Infinity)-(b.road_distance??Infinity)||a.distance-b.distance;
 });
}
