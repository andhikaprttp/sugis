import {it,expect} from 'vitest';
import {parseCoordinates,cableEstimate} from './coordinates';
it('reads the supplied decimal and DMS coordinates',()=>{
 expect(parseCoordinates('-6.363513, 106.758732')).toEqual([-6.363513,106.758732]);
 const p=parseCoordinates(`6°21'48.7"S 106°45'31.4"E`)!;
 expect(p[0]).toBeCloseTo(-6.363527778,7);expect(p[1]).toBeCloseTo(106.758722222,7);
 expect(parseCoordinates('6°21′48.7″s 106°45′31.4″e')).toEqual(p);
});
it('rejects out of range, incomplete or ambiguous input',()=>{
 for(const s of ['91, 0','0,181',`6°60'0"S 106°0'0"E`,`90°0'1"N 0°0'0"E`,'abc','-6.3','-6,3,106,7'])expect(parseCoordinates(s)).toBeNull();
 expect(parseCoordinates('90, -180')).toEqual([90,-180]);
});
it('calculates cable slack and total fixed reserve',()=>{
 expect(cableEstimate(100,10,20)).toBeCloseTo(130);expect(cableEstimate(0,0,0)).toBe(0);
});
