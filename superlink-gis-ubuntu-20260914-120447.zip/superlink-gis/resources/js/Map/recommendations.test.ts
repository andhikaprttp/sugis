import {it,expect} from 'vitest';
import {rankCandidates,terrainCost} from './recommendations';
it('can prefer a longer but flatter path',()=>{
 const near={distance:100,terrain:terrainCost(100,[0,50,0])};
 const flat={distance:200,terrain:terrainCost(200,[0,1,0])};
 expect(rankCandidates([near,flat],'terrain')[0]).toBe(flat);
 expect(rankCandidates([near,flat],'distance')[0]).toBe(near);
});
it('does not fabricate missing terrain or port data',()=>{
 expect(terrainCost(50,[0,null])).toBeNull();
 const unknown={distance:10,available:null,terrain:null},known={distance:20,available:1,terrain:30};
 expect(rankCandidates([unknown,known],'ports')[0]).toBe(known);
 expect(rankCandidates([unknown,known],'terrain')[0]).toBe(known);
});
