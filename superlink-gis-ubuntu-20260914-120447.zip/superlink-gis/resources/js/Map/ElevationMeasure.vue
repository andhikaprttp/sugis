<script setup lang="ts">
import { reactive, computed, onBeforeUnmount, ref, watch } from "vue";
import { PathHistory } from "./pathHistory";
import Recommendations from "./Recommendations.vue";
import L from "leaflet";
import { api, errorText } from "../lib";
import { cableEstimate } from "./coordinates";
import { samplePath, distance, type Point } from "./elevation";
const props = defineProps<{ map: L.Map }>();
const emit = defineEmits<{ active: [boolean] }>();
const open = ref(false),
  adding = ref(false),
  points = ref<Point[]>([]),
  values = ref<(number | null)[]>([]),
  loading = ref(false),
  error = ref(""),
  hover = ref<number | null>(null);
const tab = ref("route");
const recommendationRadius = ref(3000);
const history = reactive(new PathHistory());
function checkpoint() {
  history.checkpoint(points.value);
}
function keyboard(e: KeyboardEvent) {
  if (e.key === "Escape") { open.value = false; return; }
  const target = e.target as HTMLElement;
  if (
    !open.value ||
    target?.closest("input,textarea,select,[contenteditable=true]") ||
    !(e.ctrlKey || e.metaKey) ||
    e.altKey
  )
    return;
  const key = e.key.toLowerCase();
  if (key === "z" || key === "y") {
    e.preventDefault();
    if (key === "y" || e.shiftKey) redo();
    else undo();
  }
}

const cable = ref(false),
  slack = ref(10),
  reserve = ref(0),
  cursorDistance = ref<number | null>(null);
let rubber: L.Polyline | undefined;
const spans = computed(() =>
  points.value.slice(1).map((p, i) => distance(points.value[i], p)),
);
const cableTotal = computed(() =>
  points.value.length > 1
    ? cableEstimate(path.value.total, slack.value, reserve.value)
    : 0,
);
function move(e: L.LeafletMouseEvent) {
  rubber?.remove();
  cursorDistance.value = null;
  if (!adding.value || !points.value.length) return;
  const last = points.value[points.value.length - 1];
  rubber = L.polyline([last, [e.latlng.lat, e.latlng.lng]], {
    color: "#f97316",
    dashArray: "5 7",
    interactive: false,
    pmIgnore: true,
  } as any).addTo(props.map);
  cursorDistance.value = distance(last, [e.latlng.lat, e.latlng.lng]);
}
function addCoordinate(p: Point) {
  if (points.value.length >= 50) return;
  cable.value = true;
  open.value = true;
  checkpoint();
  points.value = [...points.value, p];
  invalidate();
  render();
  queue();
}
function startFrom(p: Point) {
  checkpoint();
  points.value = [[...p] as Point];
  cable.value = true;
  open.value = true;
  tab.value = "recommend";
  adding.value = false;
  invalidate();
  render();
  props.map.setView(p, Math.max(props.map.getZoom(), 17));
}
function useRecommendation(route: Point[]) {
  if (
    points.value.length > 2 &&
    !confirm("Ganti jalur simulasi saat ini dengan kandidat ini?")
  )
    return;
  checkpoint();
  points.value = route;
  cable.value = true;
  tab.value = "route";
  adding.value = false;
  invalidate();
  render();
  queue();
  props.map.fitBounds(L.latLngBounds(route), {
    padding: [40, 40],
    maxZoom: 18,
  });
}
defineExpose({ addCoordinate, startFrom, toggle: () => { open.value = !open.value; } });
const group = L.layerGroup();
let marker: L.CircleMarker | undefined;
let timer: ReturnType<typeof setTimeout>;
let request: AbortController | undefined;
let generation = 0;
const path = computed(() => samplePath(points.value));
const valid = computed(() =>
  values.value.filter((v): v is number => v !== null),
);
const low = computed(() => (valid.value.length ? Math.min(...valid.value) : 0)),
  high = computed(() => (valid.value.length ? Math.max(...valid.value) : 0));
const segments = computed(() => {
  const result: string[] = [];
  let part = "";
  values.value.forEach((v, i) => {
    if (v === null) {
      if (part) result.push(part);
      part = "";
    } else
      part += `${part ? "L" : "M"}${10 + (300 * i) / Math.max(1, values.value.length - 1)},${120 - (100 * (v - low.value)) / Math.max(1, high.value - low.value)} `;
  });
  if (part) result.push(part);
  return result;
});
const selected = computed(() =>
  hover.value === null
    ? null
    : {
        distance: path.value.distances[hover.value],
        height: values.value[hover.value],
      },
);
function meters(n: number) {
  return n >= 1000 ? (n / 1000).toFixed(2) + " km" : n.toFixed(1) + " m";
}
function render() {
  group.clearLayers();
  if (!open.value) return;
  group.addTo(props.map);
  if (tab.value === "recommend" && points.value[0])
    L.circle(points.value[0], {
      radius: recommendationRadius.value,
      color: "#f97316",
      weight: 2,
      fillOpacity: 0.06,
      dashArray: "7 7",
      interactive: false,
      pmIgnore: true,
    } as any).addTo(group);
  if (points.value.length > 1)
    L.polyline(points.value, {
      color: "#f97316",
      weight: 4,
      pmIgnore: true,
    } as any).addTo(group);
  points.value.forEach((p, i) => {
    const m = L.marker(p, { draggable: true, pmIgnore: true } as any)
      .addTo(group)
      .bindTooltip(String(i + 1), { permanent: true });
    m.on("dragstart", checkpoint);
    m.on("drag", () => {
      const v = m.getLatLng();
      points.value = points.value.map((old, j) =>
        i === j ? ([v.lat, v.lng] as Point) : old,
      );
      invalidate();
      group.eachLayer((l) => {
        if (l instanceof L.Polyline) l.setLatLngs(points.value);
      });
    });
    m.on("dragend", () => {
      render();
      queue();
    });
  });
}
function invalidate() {
  rubber?.remove();
  cursorDistance.value = null;
  generation++;
  request?.abort();
  clearTimeout(timer);
  values.value = [];
  error.value = "";
  loading.value = false;
  hover.value = null;
  marker?.remove();
}
function queue() {
  clearTimeout(timer);
  timer = setTimeout(fetchProfile, 1500);
}
async function fetchProfile() {
  if (path.value.points.length < 2) return;
  if (points.value.some((p) => Math.abs(p[0]) > 60)) {
    error.value = "SRTM tersedia pada lintang -60 sampai 60 derajat.";
    return;
  }
  const id = generation;
  const controller = new AbortController();
  request = controller;
  loading.value = true;
  try {
    const { data } = await api.post(
      "/map/elevation",
      { points: path.value.points },
      { signal: controller.signal },
    );
    if (id === generation) values.value = data.elevations;
  } catch (e) {
    if (!controller.signal.aborted && id === generation)
      error.value = errorText(e);
  } finally {
    if (id === generation) loading.value = false;
  }
}
function click(e: L.LeafletMouseEvent) {
  if (!adding.value || points.value.length >= 50) return;
  checkpoint();
  points.value = [...points.value, [e.latlng.lat, e.latlng.lng]];
  invalidate();
  render();
  queue();
}
function undo() {
  if (!history.past.length) return;
  points.value = history.undo(points.value);
  invalidate();
  render();
  queue();
}
function redo() {
  if (!history.future.length) return;
  points.value = history.redo(points.value);
  invalidate();
  render();
  queue();
}
function reset() {
  if (!points.value.length) return;
  checkpoint();
  points.value = [];
  invalidate();
  render();
}
function inspect(event: PointerEvent) {
  const rect = (event.currentTarget as SVGElement).getBoundingClientRect();
  const i = Math.max(
    0,
    Math.min(
      values.value.length - 1,
      Math.round(
        ((((event.clientX - rect.left) / rect.width) * 320 - 10) / 300) *
          (values.value.length - 1),
      ),
    ),
  );
  hover.value = i;
  marker?.remove();
  if (path.value.points[i])
    marker = L.circleMarker(path.value.points[i], {
      radius: 7,
      color: "#fff",
      fillColor: "#f97316",
      fillOpacity: 1,
      interactive: false,
      pmIgnore: true,
    } as any).addTo(props.map);
}
watch(adding, () => {
  rubber?.remove();
  cursorDistance.value = null;
});
watch(open, (v) => {
  emit("active", v);
  if (v) {
    window.addEventListener("keydown", keyboard);
    props.map.pm?.disableDraw();
    adding.value = true;
    props.map.on("click", click);
    props.map.on("mousemove", move);
    render();
    queue();
  } else {
    window.removeEventListener("keydown", keyboard);
    adding.value = false;
    props.map.off("click", click);
    props.map.off("mousemove", move);
    invalidate();
    group.remove();
  }
});
onBeforeUnmount(() => {
  window.removeEventListener("keydown", keyboard);
  invalidate();
  props.map.off("click", click);
  props.map.off("mousemove", move);
  group.remove();
});
</script>
<template>
  <div
    v-show="open"
    id="cable-planner"
    class="elevation-tool map-panel"
    :class="{ 'is-open': open }"
    @click.stop
    @dblclick.stop
    @pointerdown.stop
    @wheel.stop
  >
    <div class="panel-heading"><h2>Perencanaan kabel</h2><button type="button" class="panel-close" aria-label="Tutup perencanaan kabel" @click="open = false">&#215;</button></div>
    <section
      v-if="open"
      class="mt-3 space-y-3"
      aria-label="Pengukuran dan profil elevasi"
    >
      <div class="history-toolbar">
        <button
          class="btn"
          :disabled="!history.past.length"
          title="Batalkan perubahan jalur (Ctrl/Cmd+Z)"
          @click="undo"
        >
          ? Undo</button
        ><button
          class="btn"
          :disabled="!history.future.length"
          title="Ulangi perubahan (Ctrl/Cmd+Shift+Z atau Ctrl+Y)"
          @click="redo"
        >
          ? Redo</button
        ><span class="muted text-xs">{{ history.past.length }} langkah</span>
      </div>
      <nav class="planner-tabs">
        <button :class="{ active: tab === 'route' }" @click="tab = 'route'">
          Jalur & kabel</button
        ><button
          :class="{ active: tab === 'recommend' }"
          @click="tab = 'recommend'"
        >
          Rekomendasi
        </button>
      </nav>
    <Recommendations
      v-if="tab === 'recommend'"
      :origin="points[0]"
      @route="useRecommendation"
      @radius="recommendationRadius = $event; render()"
    />
      <div v-show="tab === 'route'" class="space-y-3">
        <label class="flex items-center gap-2"
          ><input v-model="cable" type="checkbox" />Mode simulasi kabel</label
        >
        <h2>{{ cable ? "Simulasi penarikan kabel" : "Profil medan" }}</h2>
        <p class="muted text-xs">
          Klik peta untuk menambah titik, lalu geser penanda untuk mengubah
          jalur. Maksimal 50 titik.
        </p>
        <div class="flex flex-wrap gap-2">
          <button class="btn" :aria-pressed="adding" @click="adding = !adding">
            {{ adding ? "Selesai menambah" : "Tambah titik" }}</button
          ><button class="btn" :disabled="!points.length" @click="reset">
            Reset
          </button>
        </div>
        <p class="text-2xl font-bold">
          {{ meters(path.total) }}
          <span class="text-xs font-normal muted">jarak horizontal</span>
        </p>
        <p v-if="cursorDistance !== null" class="muted text-xs">
          Tarikan berikutnya {{ meters(cursorDistance) }} · total sementara
          {{ meters(path.total + cursorDistance) }}
        </p>
        <div v-if="cable" class="space-y-3 rounded border p-3">
          <div class="grid grid-cols-2 gap-2">
            <label
              >Slack (%)<input
                v-model.number="slack"
                type="number"
                min="0"
                step="1" /></label
            ><label
              >Cadangan total (m)<input
                v-model.number="reserve"
                type="number"
                min="0"
                step="1"
            /></label>
          </div>
          <p class="font-bold">Estimasi kabel: {{ meters(cableTotal) }}</p>
          <p class="muted text-xs">
            Jarak horizontal × (1 + slack/100) + cadangan total. Belum
            memperhitungkan tinggi tiang, sag, atau hambatan.
          </p>
          <ol class="max-h-24 overflow-auto text-xs">
            <li v-for="(span, i) in spans" :key="i">
              Titik {{ i + 1 }} → {{ i + 2 }}: {{ meters(span) }}
            </li>
          </ol>
          <p class="muted text-xs">
            Jalur sementara, tidak disimpan ke inventori. Gunakan pencarian
            koordinat → Tambah titik kabel untuk titik yang presisi.
          </p>
        </div>
        <p v-if="points.length < 2" class="muted">
          Tentukan minimal dua titik.
        </p>
        <p v-if="loading" role="status">Memuat elevasi…</p>
        <p v-if="error" role="alert" class="error">
          {{ error }}
          <button
            class="link"
            @click="
              invalidate();
              queue();
            "
          >
            Coba lagi
          </button>
        </p>
        <template v-if="valid.length">
          <div class="flex justify-between text-xs">
            <span>Min {{ low.toFixed(1) }} m</span
            ><span>Maks {{ high.toFixed(1) }} m</span>
          </div>
          <svg
            viewBox="0 0 320 140"
            class="w-full rounded border"
            role="img"
            aria-label="Profil elevasi: sumbu horizontal jarak, vertikal ketinggian"
            @pointermove="inspect"
            @pointerleave="
              hover = null;
              marker?.remove();
            "
          >
            <path
              d="M10 10V125H310"
              fill="none"
              stroke="currentColor"
              opacity=".3"
            />
            <path
              v-for="(d, i) in segments"
              :key="i"
              :d="d"
              fill="none"
              stroke="#f97316"
              stroke-width="2"
            />
            <line
              v-if="hover !== null"
              :x1="10 + (300 * hover) / Math.max(1, values.length - 1)"
              :x2="10 + (300 * hover) / Math.max(1, values.length - 1)"
              y1="10"
              y2="125"
              stroke="currentColor"
              stroke-dasharray="3 3"
            />
          </svg>
          <div class="flex justify-between text-xs muted">
            <span>0 m</span><span>{{ meters(path.total) }}</span>
          </div>
          <p v-if="selected" class="text-sm">
            {{ meters(selected.distance) }} ·
            {{
              selected.height === null
                ? "Tidak ada data"
                : selected.height?.toFixed(1) + " m dpl"
            }}
          </p>
          <p v-if="values.some((v) => v === null)" class="muted text-xs">
            Sebagian titik tidak memiliki data; grafik dibiarkan terputus.
          </p>
        </template>
        <p v-else-if="values.length" class="muted">
          Tidak ada data elevasi untuk jalur ini.
        </p>
        <p class="muted text-xs">
          SRTM ~30 m via
          <a
            class="link"
            href="https://www.opentopodata.org/"
            target="_blank"
            rel="noopener"
            >Open Topo Data</a
          >. Koordinat jalur dikirim untuk mengambil elevasi. Kontur perkiraan,
          bukan tinggi tiang/bangunan atau analisis Fresnel. Jarak tidak
          termasuk slack kabel.
        </p>
      </div>
    </section>
  </div>
</template>
<style scoped>
.elevation-tool {
  position: absolute;
  right: 12px;
  top: 70px;
  width: min(360px, calc(100% - 24px));
  max-height: calc(100% - 86px);
  overflow: auto;
  padding: 12px;
  border-radius: 12px;
  background: var(--surface);
  box-shadow: 0 4px 20px #0002;
  z-index: 1001;
}
@media (max-width: 600px) {
  .elevation-tool {
    top: auto;
    bottom: 40px;
    max-height: 45%;
  }
}
.planner-tabs {
  display: flex;
  padding: 4px;
  background: var(--surface-raised);
  border-radius: 10px;
  gap: 4px;
}
.planner-tabs button {
  flex: 1;
  padding: 9px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 600;
}
.planner-tabs .active {
  background: #f97316;
  color: white;
}
.history-toolbar {
  position: sticky;
  top: -12px;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--surface);
  padding: 10px 0;
  border-bottom: 1px solid var(--edge);
}
</style>
