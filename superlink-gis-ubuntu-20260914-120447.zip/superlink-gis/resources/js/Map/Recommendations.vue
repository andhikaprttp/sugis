<script setup lang="ts">
import { computed, ref, watch, onBeforeUnmount } from "vue";
import { api, errorText, can } from "../lib";
import { samplePath, type Point } from "./elevation";
import { rankCandidates, terrainCost } from "./recommendations";
const props = defineProps<{ origin?: Point }>();
const emit = defineEmits<{ route: [Point[]]; radius: [number] }>();
const type = ref("ODP"),
  mode = ref("distance"),
  radius = ref(3000),
  free = ref(true),
  rows = ref<any[]>([]),
  busy = ref(false),
  error = ref(""),
  checked = ref("");
let generation = 0;
let abort: AbortController | undefined;
let autoTimer: ReturnType<typeof setTimeout>;
const ranked = computed(() => rankCandidates(rows.value, mode.value));
function invalidate() {
  clearTimeout(autoTimer);
  generation++;
  abort?.abort();
  rows.value = [];
  checked.value = "";
  error.value = "";
  busy.value = false;
}
function scheduleSearch() {
  invalidate();
  if (props.origin) autoTimer = setTimeout(search, 400);
}
watch(
  () => [
    props.origin?.[0],
    props.origin?.[1],
    type.value,
    radius.value,
    free.value,
  ],
  scheduleSearch,
  { immediate: true },
);
watch(radius, (value) => emit("radius", Number(value)), { immediate: true });
onBeforeUnmount(invalidate);
async function search() {
  invalidate();
  if (!props.origin) return;
  const id = generation;
  abort = new AbortController();
  busy.value = true;
  try {
    const { data } = await api.get("/api/map/recommendations", {
      params: {
        lat: props.origin[0],
        lng: props.origin[1],
        type: type.value,
        radius: radius.value,
        free: free.value ? 1 : 0,
      },
      signal: abort.signal,
    });
    if (id !== generation) return;
    rows.value = data.data;
    checked.value = data.checked_at;
  } catch (e) {
    if (id === generation) error.value = errorText(e);
  } finally {
    if (id === generation) busy.value = false;
  }
}
async function terrain() {
  if (!props.origin || !rows.value.length) return;
  const id = generation;
  busy.value = true;
  error.value = "";
  abort = new AbortController();
  const paths = rows.value.map(
    (r) =>
      samplePath([props.origin!, [Number(r.lat), Number(r.lng)]], 20).points,
  );
  // Zero-distance candidates still require a valid pair for the elevation endpoint.
  const samples = paths.map((p, i) =>
    p.length
      ? p
      : [
          props.origin!,
          [Number(rows.value[i].lat), Number(rows.value[i].lng)] as Point,
        ],
  );
  try {
    const { data } = await api.post(
      "/map/elevation",
      { points: samples.flat() },
      { signal: abort.signal },
    );
    if (id !== generation) return;
    let offset = 0;
    rows.value = rows.value.map((r, i) => {
      const h = data.elevations.slice(offset, offset + samples[i].length);
      offset += samples[i].length;
      return {
        ...r,
        terrain: terrainCost(Number(r.distance), h),
        terrainChecked: true,
      };
    });
    mode.value = "terrain";
  } catch (e) {
    if (id === generation) error.value = errorText(e);
  } finally {
    if (id === generation) busy.value = false;
  }
}
async function record(r: any) {
  busy.value = true;
  error.value = "";
  try {
    await api.put("/api/map/odcs/" + r.id + "/port-observation", {
      available: Number(r.input),
    });
    await search();
  } catch (e) {
    error.value = errorText(e);
  } finally {
    busy.value = false;
  }
}
async function choose(r: any) {
  if (!props.origin || r.road_distance === null) return;
  busy.value = true;
  error.value = "";
  try {
    const { data } = await api.post("/api/map/road-route", {
      start: props.origin,
      end: [Number(r.lat), Number(r.lng)],
    });
    emit("route", data.data.points);
  } catch (e) {
    error.value = errorText(e);
  } finally {
    busy.value = false;
  }
}
</script>
<template>
  <section class="space-y-3">
    <div>
      <h2>Rekomendasi sambungan</h2>
      <p class="muted text-xs mt-1">
        Titik pertama jalur menjadi lokasi asal. Kandidat diperbarui otomatis
        saat asal atau filter berubah.
      </p>
    </div>
    <p v-if="origin" class="font-mono text-xs">
      {{ origin.map((n) => n.toFixed(6)).join(", ") }}
    </p>
    <div class="grid grid-cols-2 gap-3">
      <label
        >Perangkat<select v-model="type">
          <option>ODP</option>
          <option>ODC</option>
        </select></label
      ><label
        >Radius (m)<input
          v-model.number="radius"
          type="number"
          min="50"
          max="50000"
      /></label>
    </div>
    <label
      >Prioritas<select v-model="mode">
        <option value="distance">Jarak terdekat</option>
        <option value="terrain">Jarak + perubahan medan</option>
        <option value="ports">Port kosong terbanyak</option>
      </select></label
    >
    <label class="flex items-center gap-2 text-sm"
      ><input v-model="free" type="checkbox" />Hanya perangkat dengan port
      kosong</label
    >
    <p class="muted text-xs">
      Perangkat tidak aktif selalu dilewati. Filter port kosong juga melewati
      kapasitas yang belum diketahui.
    </p>
    <button
      class="btn primary w-full"
      :disabled="!origin || busy"
      @click="search"
    >
      {{ busy ? "Mencari kandidat…" : "Perbarui sekarang" }}
    </button>
    <button
      v-if="rows.length"
      class="btn w-full"
      :disabled="busy"
      @click="terrain"
    >
      Bandingkan medan 5 kandidat
    </button>
    <p v-if="mode === 'terrain'" class="muted text-xs">
      Skor = jarak + 10 × total perubahan elevasi. Semakin kecil semakin
      diutamakan. Jalankan perbandingan medan; data yang tidak tersedia
      ditempatkan terakhir.
    </p>
    <p v-if="error" role="alert" class="error">{{ error }}</p>
    <p v-if="checked && !rows.length" class="muted">
      Tidak ada kandidat sesuai filter. Perbesar radius atau nonaktifkan filter
      port untuk memeriksa data yang belum diketahui.
    </p>
    <article v-for="(r, i) in ranked" :key="r.id" class="recommendation-card">
      <div class="flex justify-between gap-2">
        <strong>{{ i + 1 }}. {{ r.code || r.name }}</strong
        ><span class="badge">{{
          r.road_distance === null
            ? "Rute tidak ada"
            : Math.round(r.road_distance) + " m via jalan"
        }}</span>
      </div>
      <p class="muted text-xs">{{ r.name }}</p>
      <p class="muted text-xs">Jarak lurus {{ Math.round(r.distance) }} m</p>
      <p class="mt-2 text-sm">
        {{
          r.available === null
            ? "Port belum diketahui"
            : r.available + " port kosong"
        }}
        / {{ r.capacity }}
      </p>
      <p v-if="type === 'ODC'" class="muted text-xs">
        Pemeriksaan manual: {{ r.checked_at || "belum pernah" }}. Berlaku 24 jam
        selama kapasitas tidak berubah.
      </p>
      <p class="muted text-xs">
        Medan:
        {{
          r.terrain !== undefined && r.terrain !== null
            ? "skor " + Math.round(r.terrain)
            : r.terrainChecked
              ? "data tidak lengkap"
              : "belum dianalisis"
        }}
      </p>
      <details v-if="type === 'ODC' && can('odc.update')" class="mt-2">
        <summary class="text-xs cursor-pointer">
          Catat pemeriksaan port ODC
        </summary>
        <label class="text-xs"
          >Port kosong yang diperiksa<input
            v-model="r.input"
            type="number"
            min="0"
            :max="r.capacity" /></label
        ><button
          class="btn mt-2"
          :disabled="busy || r.input === undefined || r.input === ''"
          @click="record(r)"
        >
          Simpan hasil pemeriksaan
        </button>
      </details>
      <button
        class="btn w-full mt-3"
        :disabled="
          busy ||
          r.road_distance === null ||
          (Number(r.available) === 0 && r.available !== null)
        "
        @click="choose(r)"
      >
        Simulasikan jalur ke sini
      </button>
    </article>
    <p v-if="checked" class="muted text-xs">
      Data port dibaca {{ checked }}. Maksimal 5 kandidat terdekat dalam radius
      dibandingkan. Perbarui sebelum pemasangan; rekomendasi tidak memesan port.
    </p>
    <p class="muted text-xs">
      Jalur mengikuti jaringan jalan OSRM. Geser atau tambahkan titik untuk
      mengikuti tiang dan akses lapangan. Medan SRTM tidak menunjukkan hambatan
      bangunan atau izin lintasan.
    </p>
  </section>
</template>
<style scoped>
.recommendation-card {
  padding: 14px;
  border: 1px solid var(--edge);
  border-radius: 12px;
  background: var(--surface-raised);
}
label {
  font-size: 12px;
  font-weight: 600;
}
select,
input[type="number"] {
  margin-top: 5px;
}
</style>
