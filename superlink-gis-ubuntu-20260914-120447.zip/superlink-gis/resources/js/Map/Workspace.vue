<script setup lang="ts">
import {
  shallowRef,
  computed,
  onMounted,
  onBeforeUnmount,
  ref,
  watch,
} from "vue";
import {
  Expand,
  LocateFixed,
  Tags,
  RefreshCw,
  Layers,
  Map as MapIcon,
  Moon,
  Focus,
} from "lucide-vue-next";
import { parseCoordinates } from "./coordinates";
import { countPoles } from "./infrastructure";
import ElevationMeasure from "./ElevationMeasure.vue";
import { usePage } from "@inertiajs/vue3";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "@geoman-io/leaflet-geoman-free";
import "@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css";
import { api, types, errorText, can, portColor } from "../lib";
import { isDark } from "../theme";
import {
  mapStyleOptions,
  assetColors,
  effectiveMapStyle,
  validMapStyle,
  type MapStyle,
} from "./presentation";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";
L.Icon.Default.mergeOptions({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow,
});
const props = defineProps<{
  picking?: boolean;
  routeMode?: boolean;
  preview?: any[];
  focusId?: string;
  serviceAreaId?: string;
}>();
const emit = defineEmits(["pick", "node", "planning"]);
const measureTool = ref<InstanceType<typeof ElevationMeasure>>();
const coordinateResult = computed(() => parseCoordinates(query.value));
let searchMarker: L.Marker | undefined;
function goCoordinate() {
  const p = coordinateResult.value;
  if (!p) {
    error.value =
      "Koordinat tidak valid. Gunakan latitude, longitude atau DMS dengan N/S E/W.";
    return;
  }
  map.setView(p, 18);
  searchMarker?.remove();
  searchMarker = L.marker(p, { pmIgnore: true } as any)
    .addTo(map)
    .bindTooltip(p.map((v) => v.toFixed(6)).join(", "))
    .openTooltip();
}
function cableFromSearch() {
  const p = coordinateResult.value;
  if (p) {
    selected.value = null;
    measureTool.value?.addCoordinate(p);
    goCoordinate();
  }
}
function customerHomeFromSearch() {
  const p = coordinateResult.value;
  if (p) {
    selected.value = null;
    measureTool.value?.startFrom(p);
    goCoordinate();
  }
}
function measureFromSelected() {
  if (selected.value?.geometry?.type !== "Point") return;
  const p: [number, number] = [
    selected.value.geometry.coordinates[1],
    selected.value.geometry.coordinates[0],
  ];
  selected.value = null;
  measureTool.value?.startFrom(p);
}
const readyMap = shallowRef<L.Map>();
const measuring = ref(false);
const root = ref<HTMLElement>();
let map: L.Map;
let layers = L.featureGroup();
let drawn: L.Layer | null = null;
const objects = ref<any[]>([]);
const selected = ref<any>(null);
const query = ref("");
const enabled = ref([...types]);
const error = ref("");
const busy = ref(false);
const form = ref<any>(null);
const nodes = ref<string[]>([]);
const pickingNodes = ref(false);
const dirty = ref(false);
let currentLayer: any;
let initialFit = false;
const zoneLayers = ref(["RT", "RW", "COVERAGE"]);
const hiddenZones = ref<string[]>([]);
function zoneVisible(o: any) {
  return (
    o.object_type !== "AREA" ||
    (zoneLayers.value.includes(o.network?.zone_level || "COVERAGE") &&
      !hiddenZones.value.includes(o.id))
  );
}
function toggleZone(id: string) {
  hiddenZones.value = hiddenZones.value.includes(id)
    ? hiddenZones.value.filter((x) => x !== id)
    : [...hiddenZones.value, id];
}
const editable = can("network.update") || can("odp.update");
const mapKey = computed(() =>
  String((usePage().props.basemap as any)?.maptilerKey ?? ""),
);
const remoteStyles = ["satellite", "outdoor", "maptiler"];
let basemap: L.TileLayer | undefined;
let tileRequest: AbortController | undefined;
const basemapLoading = ref(false);
const mapStyle = ref<MapStyle>("auto");
try {
  mapStyle.value = validMapStyle(localStorage.getItem("superlink.mapStyle"));
} catch {}
const visualStyle = computed(() =>
  effectiveMapStyle(mapStyle.value, isDark.value),
);
const showLabels = ref(false);
const locating = ref(false);
let positionMarker: L.CircleMarker | undefined;
let resizeObserver: ResizeObserver;
let resizeFrame = 0;
const visibleObjects = computed(() =>
  objects.value.filter(
    (o) =>
      o.geometry && enabled.value.includes(o.object_type) && zoneVisible(o),
  ),
);
const odpSummary = computed(() =>
  objects.value
    .filter((o) => o.object_type === "ODP")
    .reduce(
      (a, o) => ({
        total: a.total + 1,
        available: a.available + Number(o.availability?.available ?? 0),
      }),
      { total: 0, available: 0 },
    ),
);
function fitNetwork() {
  if (layers.getBounds().isValid())
    map.fitBounds(layers.getBounds(), { padding: [70, 90], maxZoom: 17 });
}
function chooseStyle(style: MapStyle) {
  mapStyle.value = style;
  try {
    localStorage.setItem("superlink.mapStyle", style);
  } catch {}
}

async function switchBasemap() {
  if (!map) return;
  tileRequest?.abort();
  const request = new AbortController();
  tileRequest = request;
  const style = visualStyle.value;
  const remote = remoteStyles.includes(style);
  basemapLoading.value = remote;
  try {
    let url = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
    let options: L.TileLayerOptions = {
      maxNativeZoom: 19,
      maxZoom: 20,
      className: "superlink-basemap",
      attribution:
        '? <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    };
    if (style === "topo") {
      url = "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png";
      options = {
        ...options,
        maxNativeZoom: 17,
        attribution:
          'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, SRTM | Style: &copy; <a href="https://opentopomap.org/about">OpenTopoMap</a> (CC-BY-SA)',
      };
    }
    if (style === "esri") {
      url =
        "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
      options = {
        maxNativeZoom: 19,
        maxZoom: 22,
        className: "superlink-basemap",
        attribution:
          'Tiles &copy; <a href="https://www.esri.com/">Esri</a> &mdash; Source: Esri, Vantor, Earthstar Geographics, and the GIS User Community | <a href="https://www.esri.com/en-us/legal/terms/web-site-service">Terms of Use</a>',
      };
    }
    if (remote) {
      if (!mapKey.value) {
        chooseStyle("street");
        return;
      }
      const source =
        style === "satellite"
          ? "maps/satellite/256"
          : style === "outdoor"
            ? "maps/outdoor-v4/256"
            : "maps/streets-v4/256";
      const response = await fetch(
        `https://api.maptiler.com/${source}/tiles.json?key=${encodeURIComponent(mapKey.value)}`,
        { signal: request.signal },
      );
      if (!response.ok) throw new Error("tiles");
      const metadata = await response.json();
      if (!Array.isArray(metadata.tiles) || !metadata.tiles[0])
        throw new Error("metadata");
      url = metadata.tiles[0];
      const parsed = new URL(url);
      if (
        parsed.protocol !== "https:" ||
        parsed.hostname !== "api.maptiler.com"
      )
        throw new Error("host");
      if (!parsed.searchParams.has("key"))
        url +=
          (url.includes("?") ? "&" : "?") +
          "key=" +
          encodeURIComponent(mapKey.value);
      const credit = document.createElement("span");
      credit.textContent = String(
        metadata.attribution ?? "MapTiler / OpenStreetMap contributors",
      ).replace(/<[^>]*>/g, "");
      options = {
        maxNativeZoom: Math.min(Number(metadata.maxzoom ?? 19), 22),
        maxZoom: 22,
        minZoom: Number(metadata.minzoom ?? 0),
        tileSize: 256,
        className: "superlink-basemap",
        attribution:
          '<a href="https://www.maptiler.com/copyright/">? MapTiler</a> ? ' +
          credit.innerHTML,
      };
    }
    if (request.signal.aborted) return;
    const layer = L.tileLayer(url, options);
    let failures = 0;
    layer.on("tileerror", () => {
      if (
        basemap === layer &&
        (remote || style === "topo" || style === "esri") &&
        ++failures >= 3
      ) {
        error.value =
          "Basemap penyedia gagal dimuat. Kembali ke OpenStreetMap; periksa koneksi dan ketersediaan layanan.";
        chooseStyle("street");
      }
    });
    basemap?.remove();
    basemap = layer;
    layer.addTo(map);
    layer.bringToBack();
  } catch (e) {
    if (!request.signal.aborted) {
      error.value =
        "Basemap tidak tersedia. Kembali ke OpenStreetMap; periksa API key MapTiler dan jaringan.";
      chooseStyle("street");
    }
  } finally {
    if (tileRequest === request) basemapLoading.value = false;
  }
}

function locateMe() {
  if (!navigator.geolocation) {
    error.value = "Perangkat tidak mendukung lokasi.";
    return;
  }
  locating.value = true;
  navigator.geolocation.getCurrentPosition(
    (p) => {
      locating.value = false;
      const latlng: L.LatLngTuple = [p.coords.latitude, p.coords.longitude];
      positionMarker?.remove();
      positionMarker = L.circleMarker(latlng, {
        radius: 9,
        color: "#fff",
        weight: 3,
        fillColor: "#3b82f6",
        fillOpacity: 1,
      })
        .addTo(map)
        .bindTooltip(
          "Lokasi perangkat · akurasi ±" + Math.round(p.coords.accuracy) + " m",
        );
      map.setView(latlng, 17);
    },
    () => {
      locating.value = false;
      error.value =
        "Lokasi tidak tersedia. Izinkan akses lokasi atau tentukan titik secara manual.";
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
  );
}
const symbol: Record<string, string> = {
  POP: "P",
  ODC: "DC",
  ODP: "DP",
  POLE: "T",
  CUSTOMER: "C",
  PROSPECT: "?",
  CLOSURE: "CL",
  UNCLASSIFIED: "U",
  OTHER: "•",
};
function icon(o: any) {
  if (
    map?.getZoom() < 16 &&
    ["UNCLASSIFIED", "OTHER", "POLE"].includes(o.object_type)
  )
    return L.divIcon({
      className: "compact-asset",
      html: "",
      iconSize: [10, 10],
      iconAnchor: [5, 5],
    });
  const color =
    o.object_type === "ODP"
      ? portColor(o.availability, o.status)
      : (assetColors[o.object_type] ?? "#64748b");
  const shape =
    o.object_type === "POP"
      ? "hub"
      : o.object_type === "POLE"
        ? "pole"
        : o.object_type === "CUSTOMER" || o.object_type === "PROSPECT"
          ? "home"
          : "box";
  const content = document.createElement("div");
  content.className = `network-marker marker-${shape}`;
  content.style.setProperty("--marker-color", color);
  const text = document.createElement("span");
  text.textContent = symbol[o.object_type] ?? "•";
  content.append(text);
  if (o.object_type === "ODP" && o.availability) {
    const count = document.createElement("b");
    count.className = "marker-count";
    count.textContent = String(o.availability.available);
    content.append(count);
  }
  return L.divIcon({
    className: "asset-marker",
    html: content,
    iconSize: [34, 34],
    iconAnchor: [17, 17],
  });
}
let objectRequest: AbortController | undefined;
async function load() {
  if (props.preview) {
    objects.value = props.preview;
    render();
    if (!initialFit && objects.value.length) {
      fitNetwork();
      initialFit = true;
    }
    return;
  }
  objectRequest?.abort();
  const request = new AbortController();
  objectRequest = request;
  busy.value = true;
  error.value = "";
  try {
    const response = await api.get("/api/map/objects", {
      params: { service_area_id: props.serviceAreaId || undefined },
      signal: request.signal,
    });
    if (request.signal.aborted) return;
    objects.value = response.data.data;
    if (
      props.focusId &&
      !props.serviceAreaId &&
      !objects.value.some((o) => o.id === props.focusId)
    ) {
      const focused = await api.get("/api/gis-objects/" + props.focusId, {
        signal: request.signal,
      });
      if (request.signal.aborted) return;
      objects.value.push(focused.data.data);
    }
    render();
    if (props.focusId) locate(props.focusId);
    else if (!initialFit) {
      fitNetwork();
      initialFit = true;
    }
  } catch (e) {
    if (!request.signal.aborted) error.value = errorText(e);
  } finally {
    if (objectRequest === request) busy.value = false;
  }
}
watch(
  () => props.serviceAreaId,
  () => {
    initialFit = false;
    selected.value = null;
    load();
  },
);
function render() {
  if (!map) return;
  layers.clearLayers();
  for (const o of objects.value) {
    if (
      !o.geometry ||
      !enabled.value.includes(o.object_type) ||
      !zoneVisible(o)
    )
      continue;
    const group = L.geoJSON(o.geometry, {
      pointToLayer: (_, latlng) => L.marker(latlng, { icon: icon(o) }),
      style: {
        color:
          o.object_type === "AREA"
            ? o.network?.color || "#14b8a6"
            : ["night", "blueprint"].includes(visualStyle.value)
              ? "#38bdf8"
              : "#2563eb",
        weight:
          o.object_type === "AREA"
            ? o.network?.zone_level === "RW"
              ? 3
              : 2
            : 4,
        fillOpacity: 0.1,
        dashArray:
          o.object_type === "AREA"
            ? o.network?.zone_level === "RT"
              ? "3 5"
              : "10 6"
            : undefined,
        className:
          o.geometry.type === "LineString" ? "fiber-line" : "coverage-area",
      },
    });
    group.eachLayer((layer: any) => {
      const label = document.createElement("span");
      label.textContent =
        (o.code || o.name) +
        (o.availability
          ? ` · ${o.availability.available}/${o.availability.capacity} available`
          : "");
      layer.bindTooltip(label, {
        permanent: showLabels.value,
        direction: "top",
        offset: [0, -12],
        className: "asset-tooltip",
      });
      layer.on("click", () => {
        if (measuring.value) {
          if (o.geometry.type === "Point")
            measureTool.value?.addCoordinate([
              o.geometry.coordinates[1],
              o.geometry.coordinates[0],
            ]);
          return;
        }
        if (props.routeMode) {
          emit("node", o);
          return;
        }
        if (pickingNodes.value) {
          nodes.value.push(o.id);
          return;
        }
        selected.value = o;
        currentLayer = layer;
        dirty.value = false;
      });
      layer.on("pm:edit pm:dragend", () => {
        if (selected.value?.id === o.id) {
          selected.value = { ...o, geometry: layer.toGeoJSON().geometry };
          dirty.value = true;
        }
      });
    });
    layers.addLayer(group);
  }
  layers.addTo(map);
}
function locate(id: string) {
  const o = objects.value.find((o) => o.id === id);
  if (!o?.geometry) return;
  map.fitBounds(L.geoJSON(o.geometry).getBounds().pad(0.2), { maxZoom: 18 });
  selected.value = o;
}
function newForm(geometry: any) {
  form.value = {
    name: "",
    code: "",
    object_type:
      geometry.type === "Point"
        ? "POLE"
        : geometry.type === "Polygon"
          ? "AREA"
          : "FIBER_ROUTE",
    geometry,
    status: "ACTIVE",
    capacity: 8,
    description: "",
    notes: "",
    odc_id: "",
    pop_id: "",
    ownership: "",
    height: "",
    splitter_type: "1:8",
    installation_date: "",
    zone_level: null,
    rt: "",
    rw: "",
    village: "",
    district: "",
    city: "",
    color: "#14b8a6",
  };
  nodes.value = [];
}
function edit() {
  form.value = {
    ...selected.value,
    ...selected.value.network,
    geometry: selected.value.geometry,
    id: selected.value.id,
  };
  nodes.value = [];
}
function editGeometry() {
  if (!currentLayer) {
    error.value = "Klik objek pada peta terlebih dahulu";
    return;
  }
  currentLayer.pm?.enable({ allowSelfIntersection: false });
  if (currentLayer instanceof L.Marker) currentLayer.dragging?.enable();
}
async function save() {
  if (!form.value) return;
  busy.value = true;
  error.value = "";
  try {
    const data = { ...form.value };
    if (nodes.value.length) data.nodes = nodes.value;
    for (const k of [
      "odc_id",
      "pop_id",
      "area_id",
      "height",
      "installation_date",
      "zone_level",
      "rt",
      "rw",
      "village",
      "district",
      "city",
    ])
      if (data[k] === "") data[k] = null;
    const response = data.id
      ? await api.put("/api/gis-objects/" + data.id, data)
      : await api.post("/api/gis-objects", data);
    selected.value = response.data.data;
    form.value = null;
    pickingNodes.value = false;
    if (drawn) {
      map.removeLayer(drawn);
      drawn = null;
    }
    await load();
  } catch (e) {
    error.value = errorText(e);
  } finally {
    busy.value = false;
  }
}
async function saveGeometry() {
  try {
    await api.put("/api/gis-objects/" + selected.value.id, {
      geometry: selected.value.geometry,
    });
    dirty.value = false;
    currentLayer?.pm?.disable();
    await load();
  } catch (e) {
    error.value = errorText(e);
  }
}
async function remove() {
  if (!confirm("Soft delete objek ini? Dependency akan diperiksa.")) return;
  try {
    await api.delete("/api/gis-objects/" + selected.value.id);
    selected.value = null;
    await load();
  } catch (e) {
    error.value = errorText(e);
  }
}
function cancel() {
  form.value = null;
  pickingNodes.value = false;
  if (drawn) {
    map.removeLayer(drawn);
    drawn = null;
  }
}
onMounted(() => {
  map = L.map(root.value!).setView([-6.37, 106.76], 15);
  switchBasemap();
  map.on("zoomend", () => {
    if (!selected.value && !form.value && !dirty.value) render();
  });
  L.control.scale({ position: "bottomright", imperial: false }).addTo(map);
  resizeObserver = new ResizeObserver(() => {
    cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(() =>
      map.invalidateSize({ pan: false, debounceMoveend: true }),
    );
  });
  resizeObserver.observe(root.value!);
  if (editable && !props.picking && !props.routeMode && !props.preview)
    map.pm.addControls({
      position: "topleft",
      drawMarker: true,
      drawPolyline: true,
      drawPolygon: true,
      drawCircle: false,
      drawCircleMarker: false,
      drawRectangle: false,
      drawText: false,
      editMode: false,
      dragMode: false,
      cutPolygon: false,
      removalMode: false,
      rotateMode: false,
    });
  map.on("pm:create", (event: any) => {
    drawn = event.layer;
    newForm(event.layer.toGeoJSON().geometry);
  });
  map.on("click", (e: any) => {
    if (props.picking)
      emit("pick", {
        type: "Point",
        coordinates: [e.latlng.lng, e.latlng.lat],
      });
  });
  load();
  readyMap.value = map;
});
watch(visualStyle, switchBasemap);
watch(enabled, render, { deep: true });
watch([zoneLayers, hiddenZones], render, { deep: true });
watch(showLabels, () =>
  layers.eachLayer((group: any) =>
    group.eachLayer((layer: any) => {
      const tooltip = layer.getTooltip();
      if (tooltip) {
        tooltip.options.permanent = showLabels.value;
        showLabels.value ? layer.openTooltip() : layer.closeTooltip();
      }
    }),
  ),
);
watch(visualStyle, () =>
  layers.eachLayer((group: any) =>
    group.eachLayer((layer: any) => {
      if (layer instanceof L.Polyline && !(layer instanceof L.Polygon))
        layer.setStyle({
          color: ["night", "blueprint"].includes(visualStyle.value)
            ? "#38bdf8"
            : "#2563eb",
        });
    }),
  ),
);
watch(() => props.preview, load, { deep: true });
watch(
  () => props.focusId,
  (id) => id && locate(id),
);
onBeforeUnmount(() => {
  objectRequest?.abort();
  tileRequest?.abort();
  resizeObserver?.disconnect();
  cancelAnimationFrame(resizeFrame);
  map?.remove();
});
function closeOptions(event: Event) { const details = (event.target as HTMLElement).closest("details"); if (details) { details.open = false; details.querySelector("summary")?.focus(); } }
defineExpose({ load, locate, togglePlanner: () => { selected.value = null; if (!form.value) measureTool.value?.toggle(); } });
</script>
<template>
  <div
    :class="[
      'map-workspace relative h-full min-h-[500px]',
      'map-style-' + visualStyle,
      { 'planning-open': measuring },
    ]"
  >
    <ElevationMeasure
      ref="measureTool"
      :class="{ '!hidden': selected || form }"
      v-if="readyMap && !picking && !routeMode && !preview"
      :map="readyMap"
      @active="
        measuring = $event;
        emit('planning', $event);
        selected = null;
      "
    />
    <div ref="root" class="map-canvas absolute inset-0"></div>
    <div class="map-control-stack">
<div class="map-panel map-search absolute left-14 right-3 top-3 max-w-sm">
      <input
        v-model="query"
        placeholder="Cari nama, kode, atau koordinat…"
        aria-label="Cari nama atau koordinat"
        @keydown.enter.prevent="goCoordinate"
      />
      <button v-if="query" class="panel-close search-close" aria-label="Tutup hasil pencarian" @click="query = ''">&#215;</button>
      <div v-if="coordinateResult" class="card p-3 space-y-2 text-xs">
        <p>{{ coordinateResult.map((v) => v.toFixed(6)).join(", ") }}</p>
        <button class="btn" @click="goCoordinate">Ke koordinat</button
        ><button
          v-if="!picking && !routeMode && !preview"
          class="btn"
          @click="cableFromSearch"
        >
          Tambah titik kabel
        </button>
        <button
          v-if="!picking && !routeMode && !preview"
          class="btn primary"
          @click="customerHomeFromSearch"
        >
          Rumah pelanggan · cari ODP
        </button>
      </div>
      <div
        v-if="query"
        class="mt-1 max-h-64 overflow-auto rounded-lg bg-white shadow-lg"
      >
        <button
          v-for="o in objects
            .filter((o) =>
              (o.name + ' ' + o.code)
                .toLowerCase()
                .includes(query.toLowerCase()),
            )
            .slice(0, 20)"
          :key="o.id"
          class="block w-full border-b p-3 text-left text-sm hover:bg-blue-50"
          @click="
            locate(o.id);
            query = '';
          "
        >
          {{ o.code || o.name }} <span class="muted">{{ o.object_type }}</span>
        </button>
      </div>
    </div>

<div class="map-option-row">    <details
      class="map-panel map-layer-picker absolute bottom-5 left-3 max-w-xs rounded-lg bg-white p-3 shadow"
      :open="false"
    >
      <summary class="cursor-pointer text-xs font-semibold">
        Layers & Zona RT/RW
      </summary>
      <div class="panel-heading"><h2>Layer peta</h2><button class="panel-close" aria-label="Tutup layer peta" @click="closeOptions">&#215;</button></div>
      <div class="my-3 border-b pb-3">
        <label
          v-for="z in [
            { id: 'RW', label: 'Zona RW' },
            { id: 'RT', label: 'Zona RT' },
            { id: 'COVERAGE', label: 'Coverage umum' },
          ]"
          :key="z.id"
          class="mb-2 flex items-center gap-2"
          ><input v-model="zoneLayers" type="checkbox" :value="z.id" />{{
            z.label
          }}</label
        >
        <div class="max-h-36 overflow-y-auto">
          <label
            v-for="o in objects.filter((o) => o.network?.zone_level)"
            :key="o.id"
            class="mb-2 flex items-center gap-2"
            ><input
              type="checkbox"
              :checked="!hiddenZones.includes(o.id)"
              @change="toggleZone(o.id)"
            /><span
              class="h-2 w-2 rounded"
              :style="{ background: o.network.color }"
            ></span
            >{{ o.name }}</label
          >
        </div>
        <a href="/zones" class="link text-xs">Statistik pelanggan RT/RW →</a>
      </div>
      <div class="mt-2 grid grid-cols-2 gap-2">
        <label v-for="t in types" :key="t" class="flex items-center gap-2"
          ><input v-model="enabled" type="checkbox" :value="t" />{{ t }}</label
        >
      </div>
      <p class="mt-3 text-xs">
        ODP: 🟢 &gt;50% · 🟡 1–50% · 🔴 Full<br />Abu-abu: inactive/damaged.
        Hover untuk jumlah port.
      </p>
    </details>
<details class="map-panel map-style-picker" @keydown.esc="closeOptions">
      <summary
        class="flex cursor-pointer items-center gap-2 px-3 py-2 text-sm font-semibold"
      >
        <Layers :size="17" />Gaya:
        {{ mapStyleOptions.find((o) => o.id === mapStyle)?.label }}
      </summary>
      <div class="panel-heading px-3"><h2>Gaya peta</h2><button class="panel-close" aria-label="Tutup gaya peta" @click="closeOptions">&#215;</button></div>
      <div class="map-style-options" role="group" aria-label="Gaya peta dasar">
        <button
          v-for="option in mapStyleOptions"
          :key="option.id"
          :aria-pressed="mapStyle === option.id"
          :class="{ active: mapStyle === option.id }"
          :title="option.description"
          :disabled="remoteStyles.includes(option.id) && !mapKey"
          @click="chooseStyle(option.id)"
        >
          <span
            :class="['map-style-swatch', 'swatch-' + option.id]"
            aria-hidden="true"
          ></span
          ><span>{{ option.label }}</span>
        </button>
      </div>
      <p class="px-3 pb-2 text-xs muted">
        {{
          basemapLoading
            ? "Memuat basemap?"
            : "Atur aset dan zona pada menu Layers."
        }}
      </p>
      <p v-if="!mapKey" class="px-3 pb-2 text-xs muted">
        Satelit Esri dapat dipilih tanpa API key. MapTiler membutuhkan
        MAPTILER_KEY.
      </p>
      <p v-if="visualStyle === 'esri'" class="px-3 pb-2 text-xs muted">
        Detail citra bergantung wilayah. Zoom 20–22 memperbesar citra, bukan
        menambah resolusi.
      </p>
    </details></div>
</div>
    
    <div class="map-panel network-summary">
      <span
        ><b>{{ visibleObjects.length }}</b> aset tampil</span
      ><span title="POLE, ODP, dan ODC pada koordinat sama dihitung satu tiang"
        ><b>{{ countPoles(visibleObjects) }}</b> tiang tampil</span
      ><span
        ><b>{{ odpSummary.total }}</b> ODP</span
      ><span class="summary-available"
        ><b>{{ odpSummary.available }}</b> port kosong</span
      >
    </div>
    <div class="map-panel map-quick-tools">
      <button
        title="Tampilkan seluruh jaringan"
        aria-label="Tampilkan seluruh jaringan"
        @click="fitNetwork"
      >
        <Expand :size="19" /></button
      ><button
        title="Lokasi saya"
        aria-label="Lokasi saya"
        :disabled="locating"
        @click="locateMe"
      >
        <LocateFixed
          :size="19"
          :class="{ 'animate-pulse': locating }"
        /></button
      ><button
        title="Label aset"
        aria-label="Tampilkan label aset"
        :aria-pressed="showLabels"
        :class="{ active: showLabels }"
        @click="showLabels = !showLabels"
      >
        <Tags :size="19" /></button
      ><button
        title="Muat ulang jaringan"
        aria-label="Muat ulang jaringan"
        :disabled="busy"
        @click="load"
      >
        <RefreshCw :size="18" :class="{ 'animate-spin': busy }" />
      </button>
    </div>
        <div
      v-if="busy"
      class="map-panel absolute bottom-4 left-4 rounded bg-white p-2 text-xs shadow"
    >
      Memuat data…
    </div>
    <div
      v-if="error"
      class="map-panel absolute bottom-14 left-3 right-3 error"
      role="alert"
    >
      {{ error }} <button type="button" class="panel-close" aria-label="Tutup pemberitahuan" @click="error = ''">&#215;</button>
    </div>

    <div
      v-if="picking || routeMode || pickingNodes"
      class="map-panel absolute bottom-5 left-1/2 -translate-x-1/2 rounded-lg bg-ink px-4 py-3 text-sm text-white"
    >
      {{
        picking
          ? "Klik lokasi pada peta"
          : `Klik node secara berurutan${pickingNodes ? " · " + nodes.length + " dipilih" : ""}`
      }}<button
        v-if="pickingNodes"
        class="ml-4 text-orange-300"
        @click="pickingNodes = false"
      >
        Selesai
      </button>
    </div>
    <aside
      v-if="selected && !picking && !routeMode && !form"
      class="map-panel map-object-panel absolute bottom-20 right-3 top-28 sm:top-16 w-[min(320px,calc(100%-24px))] overflow-auto rounded-xl border bg-white p-5 shadow-xl"
    >
      <button class="panel-close float-right" aria-label="Tutup detail aset" @click="selected = null">
        ✕</button
      ><span class="badge">{{ selected.object_type }}</span>
      <h2 class="mt-3">{{ selected.code || selected.name }}</h2>
      <p class="muted mt-1">{{ selected.name }}</p>
      <div class="mt-4 space-y-3 text-sm">
        <p>
          Status <strong class="float-right">{{ selected.status }}</strong>
        </p>
        <p v-if="selected.geometry?.type === 'Point'" class="font-mono text-xs">
          {{ selected.geometry.coordinates[1].toFixed(6) }},
          {{ selected.geometry.coordinates[0].toFixed(6) }}
        </p>
        <button
          v-if="selected.geometry?.type === 'Point'"
          class="btn primary w-full"
          @click="measureFromSelected"
        >
          Ukur dari
          {{ selected.object_type === "POLE" ? "tiang ini" : "titik ini" }}
        </button>
        <div v-if="selected.availability" class="rounded-lg bg-slate-50 p-3">
          <p>
            Available
            <strong class="float-right"
              >{{ selected.availability.available }} /
              {{ selected.availability.capacity }}</strong
            >
          </p>
          <p class="mt-2">
            Utilization
            <strong class="float-right"
              >{{ selected.availability.utilization }}%</strong
            >
          </p>
          <a
            :href="'/network/odps/' + selected.id + '/ports'"
            class="btn primary mt-4 w-full"
            >Manage Ports</a
          >
        </div>
        <div v-if="selected.network?.zone_level" class="rounded-lg border p-3">
          <strong>Zona {{ selected.network.zone_level }}</strong>
          <p>
            RW {{ selected.network.rw
            }}<span v-if="selected.network.rt">
              / RT {{ selected.network.rt }}</span
            >
          </p>
          <p class="muted">
            {{ selected.network.village }} · {{ selected.network.district }}
          </p>
          <a href="/zones" class="link">Statistik pelanggan →</a>
        </div>
        <p>{{ selected.description }}</p>
        <p>{{ selected.notes }}</p>
        <div class="border-t pt-3 text-xs text-slate-400">
          {{ selected.source }} · {{ selected.source_filename || "Manual entry"
          }}<br />{{ selected.original_name }}
        </div>
      </div>
      <div v-if="editable && !preview" class="mt-5 grid grid-cols-2 gap-2">
        <button class="btn" @click="edit">Edit metadata</button
        ><button class="btn" @click="editGeometry">Edit geometry</button
        ><button
          v-if="dirty"
          class="btn orange col-span-2"
          @click="saveGeometry"
        >
          Simpan geometry</button
        ><button class="btn danger col-span-2" @click="remove">
          Delete object
        </button>
      </div>
    </aside>
    <div
      v-if="form"
      class="map-panel map-edit-panel absolute right-3 top-28 sm:top-16 bottom-4 w-[min(400px,calc(100%-24px))] overflow-auto rounded-xl bg-white p-5 shadow-xl"
    >
      <div class="flex justify-between">
        <h2>{{ form.id ? "Edit" : "Add" }} GIS Object</h2>
        <button type="button" class="panel-close" aria-label="Tutup formulir aset" @click="cancel">✕</button>
      </div>
      <form class="mt-4 space-y-3" @submit.prevent="save">
        <div class="field">
          <label>Object type</label
          ><select v-model="form.object_type">
            <option
              v-for="t in types.filter(
                (t) => !['CUSTOMER', 'PROSPECT'].includes(t),
              )"
              :key="t"
            >
              {{ t }}
            </option>
          </select>
        </div>
        <div
          v-if="form.object_type === 'AREA'"
          class="space-y-3 rounded-lg border p-3"
        >
          <label
            >Jenis zona<select v-model="form.zone_level">
              <option :value="null">Coverage umum</option>
              <option value="RW">Zona RW</option>
              <option value="RT">Zona RT</option>
            </select></label
          >
          <div class="gridform">
            <label v-if="form.zone_level"
              >RW<input
                v-model="form.rw"
                placeholder="001"
                pattern="[0-9]{1,3}"
                required /></label
            ><label v-if="form.zone_level === 'RT'"
              >RT<input
                v-model="form.rt"
                placeholder="001"
                pattern="[0-9]{1,3}"
                required /></label
            ><label>Kelurahan<input v-model="form.village" /></label
            ><label>Kecamatan<input v-model="form.district" /></label
            ><label>Kota<input v-model="form.city" /></label
            ><label
              >Warna zona<input v-model="form.color" type="color" class="h-10"
            /></label>
          </div>
        </div>
        <div class="field">
          <label>Name</label><input v-model="form.name" required />
        </div>
        <div class="field">
          <label>Code</label><input v-model="form.code" />
        </div>
        <div class="field">
          <label>Status</label
          ><select v-model="form.status">
            <option
              v-for="s in ['ACTIVE', 'INACTIVE', 'DAMAGED', 'PLANNED']"
              :key="s"
            >
              {{ s }}
            </option>
          </select>
        </div>
        <div v-if="['ODP', 'ODC'].includes(form.object_type)" class="field">
          <label>Capacity</label
          ><input
            v-model.number="form.capacity"
            type="number"
            min="0"
            max="1024"
          />
        </div>
        <div v-if="form.object_type === 'ODP'" class="space-y-3">
          <label
            >Parent ODC<select v-model="form.odc_id">
              <option value="">Unassigned</option>
              <option
                v-for="o in objects.filter((o) => o.object_type === 'ODC')"
                :key="o.id"
                :value="o.id"
              >
                {{ o.code || o.name }}
              </option>
            </select></label
          ><label>Splitter<input v-model="form.splitter_type" /></label
          ><label
            >Installation date<input
              v-model="form.installation_date"
              type="date"
          /></label>
        </div>
        <label
          >POP<select v-model="form.pop_id">
            <option value="">Unassigned</option>
            <option
              v-for="o in objects.filter((o) => o.object_type === 'POP')"
              :key="o.id"
              :value="o.id"
            >
              {{ o.code || o.name }}
            </option>
          </select></label
        >
        <div v-if="form.object_type === 'POLE'" class="gridform">
          <label>Ownership<input v-model="form.ownership" /></label
          ><label
            >Height (m)<input v-model="form.height" type="number" step="0.1"
          /></label>
        </div>
        <div v-if="form.geometry.type === 'Point'" class="gridform">
          <label
            >Longitude<input
              v-model.number="form.geometry.coordinates[0]"
              type="number"
              step="any"
              min="-180"
              max="180" /></label
          ><label
            >Latitude<input
              v-model.number="form.geometry.coordinates[1]"
              type="number"
              step="any"
              min="-90"
              max="90"
          /></label>
        </div>
        <div v-if="form.object_type === 'FIBER_ROUTE'">
          <button
            type="button"
            class="btn"
            @click="pickingNodes = !pickingNodes"
          >
            Pilih node di peta ({{ nodes.length }})
          </button>
          <p class="muted mt-2">
            Pilih node start, tiang, dan endpoint. Jalur akan mengikuti urutan
            node.
          </p>
          <button type="button" class="link" @click="nodes = []">
            Reset nodes
          </button>
        </div>
        <label
          >Description<textarea v-model="form.description"></textarea></label
        ><label>Notes<textarea v-model="form.notes"></textarea></label
        ><button class="btn orange w-full" :disabled="busy">
          Simpan objek
        </button>
      </form>
    </div>
  </div>
</template>
