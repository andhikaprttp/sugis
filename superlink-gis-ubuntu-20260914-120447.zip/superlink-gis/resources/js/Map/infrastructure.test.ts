import {describe,it,expect} from 'vitest';
import {countPoles} from './infrastructure';

describe('Physical pole totals',()=>{
  const asset=(id:string,object_type:string,coordinates:number[]|null)=>({id,object_type,geometry:coordinates?{type:'Point',coordinates}:null});
  it('counts ODP and ODC once at a shared pole, ignoring altitude',()=>{
    expect(countPoles([asset('1','POLE',[106,-6]),asset('2','ODP',[106,-6,8]),asset('3','ODC',[106,-6]),asset('4','ODP',[106.000001,-6]),asset('5','CUSTOMER',[107,-6])])).toBe(2);
  });
  it('keeps unlocated supports separate and handles an empty list',()=>{
    expect(countPoles([asset('1','ODP',null),asset('2','ODC',null)])).toBe(2);
    expect(countPoles([])).toBe(0);
  });
});
