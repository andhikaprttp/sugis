import type {Point} from './elevation';
const copy=(points:Point[]):Point[]=>points.map(p=>[...p] as Point);
export class PathHistory {
 past:Point[][]=[];
 future:Point[][]=[];
 checkpoint(points:Point[]){this.past.push(copy(points));if(this.past.length>100)this.past.shift();this.future=[];}
 undo(points:Point[]):Point[]{if(!this.past.length)return points;this.future.push(copy(points));return this.past.pop()!;}
 redo(points:Point[]):Point[]{if(!this.future.length)return points;this.past.push(copy(points));return this.future.pop()!;}
}
