export type Point = [number, number];
export function distance(a:Point,b:Point):number {
  const r=Math.PI/180,dlat=(b[0]-a[0])*r,dlng=(b[1]-a[1])*r;
  const h=Math.sin(dlat/2)**2+Math.cos(a[0]*r)*Math.cos(b[0]*r)*Math.sin(dlng/2)**2;
  return 6371000*2*Math.asin(Math.sqrt(Math.min(1,h)));
}
export function samplePath(points:Point[],limit=100):{points:Point[],distances:number[],total:number} {
  const lengths=points.slice(1).map((p,i)=>distance(points[i],p));
  const total=lengths.reduce((a,b)=>a+b,0);
  if(!total)return {points:[],distances:[],total:0};
  const count=Math.min(limit,Math.max(2,Math.ceil(total/30)+1));
  const samples:Point[]=[],distances:number[]=[];let segment=0,start=0;
  for(let i=0;i<count;i++){
    const target=total*i/(count-1);
    while(segment<lengths.length-1&&start+lengths[segment]<target){start+=lengths[segment++];}
    const t=lengths[segment]?(target-start)/lengths[segment]:0,a=points[segment],b=points[segment+1];
    const dlng=((b[1]-a[1]+540)%360)-180;
    samples.push([a[0]+t*(b[0]-a[0]),((a[1]+t*dlng+540)%360)-180]);distances.push(target);
  }
  return {points:samples,distances,total};
}
