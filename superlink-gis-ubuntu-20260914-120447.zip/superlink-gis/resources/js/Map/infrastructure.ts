type Asset = {id:string;object_type:string;geometry?:{type:string;coordinates:any}|null};

/** Count physical supports among displayed assets, matching exact XY coordinates. */
export function countPoles(objects:Asset[]):number {
  const positions=new Set<string>();
  for(const object of objects){
    if(!['POLE','ODP','ODC'].includes(object.object_type))continue;
    const geometry=object.geometry;
    const key=geometry?.type==='Point'
      ? `xy:${Number(geometry.coordinates[0])},${Number(geometry.coordinates[1])}`
      : `id:${object.id}`;
    positions.add(key);
  }
  return positions.size;
}
