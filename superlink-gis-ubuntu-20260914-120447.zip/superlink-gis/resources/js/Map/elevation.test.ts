import {describe,it,expect} from 'vitest';
import {distance,samplePath} from './elevation';
describe('elevation sampling',()=>{
 it('measures a known equatorial distance',()=>expect(distance([0,0],[0,1])).toBeCloseTo(111194.93,1));
 it('preserves bends and endpoints with bounded samples',()=>{const p=samplePath([[0,0],[0,.01],[.01,.01]],3);expect(p.points[1][0]).toBeCloseTo(0,5);expect(p.points[2][0]).toBeCloseTo(.01);expect(p.points[2][1]).toBeCloseTo(.01);expect(p.distances[2]).toBe(p.total);expect(samplePath([[0,0],[0,10]]).points).toHaveLength(100);});
 it('handles empty and repeated points',()=>{expect(samplePath([]).total).toBe(0);expect(samplePath([[0,0],[0,0]]).points).toEqual([]);expect(samplePath([[0,0],[0,0],[0,.001]]).points.every(p=>p.every(Number.isFinite))).toBe(true);});
 it('crosses the dateline by the short path',()=>{const p=samplePath([[0,179.9],[0,-179.9]],3);expect(p.total).toBeLessThan(23000);expect(Math.abs(p.points[1][1])).toBeCloseTo(180);});
});
