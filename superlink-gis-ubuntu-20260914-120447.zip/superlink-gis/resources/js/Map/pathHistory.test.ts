import {it,expect} from 'vitest';
import {PathHistory} from './pathHistory';
import type {Point} from './elevation';
it('undoes additions, drag, reset and replacement with independent snapshots',()=>{
 const h=new PathHistory();let p:Point[]=[];
 h.checkpoint(p);p=[[1,2]];h.checkpoint(p);p[0][0]=3;
 expect(h.undo(p)).toEqual([[1,2]]);p=h.redo([[1,2]]);expect(p).toEqual([[3,2]]);
 h.checkpoint(p);p=[];p=h.undo(p);expect(p).toEqual([[3,2]]);
 h.checkpoint(p);p=[[5,6],[7,8]];expect(h.undo(p)).toEqual([[3,2]]);
});
it('clears redo on a new edit and caps undo history',()=>{
 const h=new PathHistory();h.checkpoint([]);h.undo([[1,2]]);h.checkpoint([[9,9]]);expect(h.future).toHaveLength(0);
 for(let i=0;i<110;i++)h.checkpoint([[i,i]]);expect(h.past).toHaveLength(100);
});
