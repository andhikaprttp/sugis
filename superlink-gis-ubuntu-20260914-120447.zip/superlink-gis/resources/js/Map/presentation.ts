export type MapStyle = 'auto' | 'street' | 'focus' | 'night' | 'contrast' | 'sepia' | 'blueprint' | 'topo' | 'satellite' | 'esri' | 'outdoor' | 'maptiler';
export function validMapStyle(value: string | null): MapStyle {
  return ['topo', 'auto', 'street', 'focus', 'night', 'contrast', 'sepia', 'blueprint', 'satellite', 'esri', 'outdoor', 'maptiler'].includes(value ?? '') ? value as MapStyle : 'auto';
}
export function effectiveMapStyle(style: MapStyle, dark: boolean): Exclude<MapStyle, 'auto'> {
  return style === 'auto' ? (dark ? 'night' : 'street') : style;
}
export const assetColors: Record<string, string> = {
  POP: '#f97316', ODC: '#8b5cf6', POLE: '#64748b', CLOSURE: '#06b6d4',
  CUSTOMER: '#3b82f6', PROSPECT: '#db2777', UNCLASSIFIED: '#64748b', OTHER: '#64748b',
};

export const mapStyleOptions: {id:MapStyle,label:string,description:string}[] = [
 {id:'topo',label:'Topo gratis',description:'OpenTopoMap, tanpa API key'},
 {id:'esri',label:'Satelit Esri',description:'World Imagery tanpa API key; detail bergantung wilayah'},
 {id:'satellite',label:'Satelit MapTiler',description:'Citra satelit MapTiler; perlu API key'},
 {id:'outdoor',label:'Topografi',description:'MapTiler Outdoor; perlu API key'},
 {id:'maptiler',label:'Jalan detail',description:'MapTiler Streets; perlu API key'},
 {id:'auto',label:'Auto',description:'Mengikuti tema aplikasi'},
 {id:'street',label:'Jalan',description:'Warna asli OpenStreetMap'},
 {id:'focus',label:'Fokus',description:'Warna tenang untuk membaca jaringan'},
 {id:'night',label:'Malam',description:'Latar gelap untuk malam hari'},
 {id:'contrast',label:'Kontras',description:'Jalan dan batas lebih tegas'},
 {id:'sepia',label:'Sepia',description:'Nuansa hangat seperti peta cetak'},
 {id:'blueprint',label:'Blueprint',description:'Nuansa biru gelap untuk jaringan'},
];
