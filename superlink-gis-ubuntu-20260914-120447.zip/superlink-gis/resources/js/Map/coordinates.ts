import type {Point} from './elevation';
export function parseCoordinates(input:string):Point|null {
 const s=input.trim().replace(/[−–]/g,'-').replace(/[′’]/g,"'").replace(/[″“”]/g,'"');
 const decimal=s.match(/^([+-]?\d+(?:\.\d+)?)\s*[,;]\s*([+-]?\d+(?:\.\d+)?)$/);
 if(decimal){const p:Point=[Number(decimal[1]),Number(decimal[2])];return Math.abs(p[0])<=90&&Math.abs(p[1])<=180?p:null;}
 const dms=s.match(/^(\d{1,2})\s*°\s*(\d{1,2})\s*'\s*(\d{1,2}(?:\.\d+)?)\s*"\s*([NS])\s*[,;]?\s*(\d{1,3})\s*°\s*(\d{1,2})\s*'\s*(\d{1,2}(?:\.\d+)?)\s*"\s*([EW])$/i);
 if(!dms)return null;
 const [a,b,c,d,e,f]=[1,2,3,5,6,7].map(i=>Number(dms[i]));
 if(b>=60||c>=60||e>=60||f>=60)return null;
 const lat=a+b/60+c/3600,lng=d+e/60+f/3600;
 return lat<=90&&lng<=180?[lat*(dms[4].toUpperCase()==='S'?-1:1),lng*(dms[8].toUpperCase()==='W'?-1:1)]:null;
}
export function cableEstimate(length:number,slack:number,reserve:number):number {
 return length*(1+Math.max(0,Number(slack)||0)/100)+Math.max(0,Number(reserve)||0);
}
