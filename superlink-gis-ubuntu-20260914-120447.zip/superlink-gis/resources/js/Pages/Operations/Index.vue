<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {Head, Link, router, useForm, usePoll} from '@inertiajs/vue3';
import {Activity, Server, SlidersHorizontal, PlugZap, Power, Bell, History, Cable, CircleHelp} from 'lucide-vue-next';
import AppLayout from '../../Layouts/AppLayout.vue';
import Pagination from '../../Components/Pagination.vue';
import CmsPanel from './CmsPanel.vue';
import DeviceCards from './DeviceCards.vue';
import {can} from '../../lib';
const props=defineProps<{section:string,connector:any,operations:any,events:any,customers:any,customerCount:number,cmsOlts:any,cmsOnus:any,olts:any[],templates:any[],connection:any,filters:any}>();
usePoll(15000, {only:['customers','cmsOlts','cmsOnus','connector','events']});
const menus=[
 {key:'monitoring',name:'Monitoring pelanggan',icon:Activity,desc:'Status sesi PPPoE, koneksi ONT, dan daya optik pelanggan.'},
 {key:'olts',name:'Daftar OLT',icon:Server,desc:'Pilih OLT untuk melihat status perangkat dan ONT pelanggan.'},
 {key:'templates',name:'Template layanan',icon:SlidersHorizontal,desc:'Tentukan VLAN dan profil sekali untuk aktivasi pelanggan berikutnya.'},
 {key:'activation',name:'Aktivasi ONT',icon:PlugZap,desc:'Pilih OLT dan template, lalu tinjau konfigurasi layanan.'},
 {key:'actions',name:'Suspend & aktifkan',icon:Power,desc:'Kelola tindakan administratif ONT per pelanggan.'},
 {key:'alarms',name:'Alarm & dying gasp',icon:Bell,desc:'Pantau penyebab putus, kehilangan daya, dan alarm jaringan.'},
 {key:'history',name:'Riwayat operasi',icon:History,desc:'Hasil aktivasi, suspend, dan konfigurasi yang dikirim ke perangkat.'},
 {key:'connection',name:'Koneksi CMS & PPPoE',icon:Cable,desc:'Siapkan alamat CMS dan sumber informasi sesi PPPoE.'},
];
function fresh(c:any){return c.observed_at && Date.now()-new Date(c.observed_at).getTime()<300000;}
const current=computed(()=>menus.find(m=>m.key===props.section)!);
const tabs=computed(()=>menus.filter(m=>m.key!=='connection'||can('settings.manage')));
const search=ref(props.filters.search??'');const state=ref(props.filters.state??'');const selected=ref<any>(null);
const blankOlt={id:null as number|null,name:'',external_id:'',host:''};const olt=useForm({...blankOlt});
const blankTemplate={id:null as number|null,olt_id:'',name:'',vlan:100,line_profile:'',service_profile:'',wan_profile:'',tr069_profile:'',binding:'LAN1'};
const template=useForm({...blankTemplate});
const connection=useForm({cms_url:props.connection?.cms_url??'http://10.1.1.21',pppoe_source:props.connection?.pppoe_source??'UNCONFIGURED'});
const activation=ref({olt:'',template:''});
const availableTemplates=computed(()=>props.templates.filter(t=>String(t.olt_id)===activation.value.olt));
const activationTemplate=computed(()=>availableTemplates.value.find(t=>String(t.id)===activation.value.template));
watch(()=>activation.value.olt,()=>activation.value.template='');
watch(()=>props.section,()=>{selected.value=null;search.value=props.filters.search??'';state.value=props.filters.state??'';olt.defaults({...blankOlt});olt.reset();olt.clearErrors();template.defaults({...blankTemplate});template.reset();template.clearErrors();connection.cms_url=props.connection?.cms_url??'http://10.1.1.21';connection.pppoe_source=props.connection?.pppoe_source??'UNCONFIGURED';});
function filter(){selected.value=null;router.get('/operations/'+props.section,{search:search.value,state:state.value,cms_olt:props.filters.cms_olt},{preserveState:true});}
function editOlt(row:any){Object.assign(olt,{id:row.id,name:row.name,external_id:row.external_id,host:row.host??''});}
function editTemplate(row:any){Object.assign(template,Object.fromEntries(Object.keys(blankTemplate).map(k=>[k,row[k]])));}
function oltName(id:number){return props.olts.find(o=>o.id===id)?.name??'OLT belum dipilih';}
</script>

<template>
 <Head :title="current.name"/><AppLayout title="OLT & Pelanggan Online"><div class="page operations-page">
  <div class="heading"><div><p class="muted text-xs tracking-widest">NETWORK OPERATIONS</p><h1 class="mt-2">{{current.name}}</h1><p class="muted mt-2">{{current.desc}}</p></div><span class="badge self-start"><CircleHelp class="mr-2 h-4 w-4"/>{{connector?.last_sync_at?'CMS pernah tersinkron':'Belum tersinkron'}}</span></div>
  <nav class="flex flex-wrap gap-2" aria-label="Menu operasi"><Link v-for="item in tabs" :key="item.key" :href="'/operations/'+item.key" :class="['btn',section===item.key?'primary':'']"><component :is="item.icon" class="h-4 w-4"/>{{item.name}}</Link></nav>
  <CmsPanel :key="section" :section="section" :connector="connector" :connection="props.connection" :olts="olts" :templates="templates" :operations="operations" :events="events"/>

  <form v-if="['olts','monitoring'].includes(section)" class="card flex flex-wrap items-end gap-3 p-4" @submit.prevent="filter"><label class="flex-1">Cari nama / deskripsi ONT / serial<input v-model="search" placeholder="Nama pelanggan dari CMS atau serial ONT"></label><label>Status<select v-model="state"><option value="">Semua</option><option value="ONLINE">Online</option><option value="OFFLINE">Offline</option><option value="UNKNOWN">Belum diketahui</option></select></label><button class="btn primary">Cari</button></form>
  <DeviceCards v-if="cmsOlts" :olts="cmsOlts" :onus="cmsOnus" :selected="filters.cms_olt" :section="section"/>
  <template v-if="(section==='monitoring'||section==='actions') && filters.cms_olt">
   <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-5"><div class="card p-5"><p class="muted">Pelanggan terdaftar</p><strong class="mt-2 block text-3xl">{{customerCount}}</strong></div><div v-for="label in ['Sesi PPPoE','Monitoring ONT','Administratif','Penyebab offline']" :key="label" class="card p-5"><p class="muted">{{label}}</p><strong class="mt-2 block text-3xl">—</strong><p class="muted mt-2 text-xs">Lihat status per pelanggan</p></div></div>
   <form class="card flex flex-wrap items-end gap-3 p-4" @submit.prevent="filter"><label class="min-w-60 flex-1">Cari pelanggan<input v-model="search" placeholder="Nama, ID, username PPPoE, atau SN"></label><label>Status jaringan<select v-model="state"><option value="">Semua</option><option value="UNKNOWN">Belum diketahui</option><option value="ONLINE">ONT online</option><option value="OFFLINE">ONT offline</option><option value="DEACTIVATED">ONT deactivated</option><option value="DYING_GASP">ONT dying gasp</option></select></label><button class="btn primary">Terapkan</button></form>
   <div class="tablewrap"><table><thead><tr><th>Pelanggan / PPPoE</th><th>Serial ONT</th><th>OLT / PON / ONU</th><th>Langganan</th><th>Sesi PPPoE</th><th>ONT / Administratif</th><th>Penyebab offline</th><th>RX / TX</th><th></th></tr></thead><tbody><tr v-for="c in customers.data" :key="c.id"><td><Link :href="'/customers/'+c.id" class="link">{{c.name}}</Link><p class="muted text-xs">{{c.customer_id}} · {{c.pppoe_username||'PPPoE belum diisi'}}</p></td><td>{{c.ont_serial_number||'Belum dipetakan'}}</td><td>{{c.olt_name||c.olt_external_id||'Belum terhubung'}}<p class="muted text-xs">{{c.olt_host||'-'}} / PON {{c.pon_id??'-'}} / ONU {{c.onu_id??'-'}}</p></td><td><span class="badge">{{c.status}}</span></td><td><span class="badge" :style="{color:c.pppoe_state==='UP'?'#10b981':c.pppoe_state==='DOWN'?'#f43f5e':'var(--muted)'}">{{c.pppoe_state==='UNKNOWN'?'Belum diketahui':c.pppoe_state}}</span></td><td>{{fresh(c)?c.ont_state:"UNKNOWN"}} / {{fresh(c)?c.admin_state:"UNKNOWN"}}<p v-if="!fresh(c)" class="muted text-xs">Data belum tersedia / kedaluwarsa</p></td><td>{{c.offline_reason??"-"}}</td><td>{{c.rx_power??"-"}} / {{c.tx_power??"-"}}</td><td><button class="btn" @click="selected=c">{{section==='actions'?'Kelola':'Detail'}}</button></td></tr><tr v-if="!customers.data.length"><td colspan="9" class="p-8 text-center muted">{{state&&state!=='UNKNOWN'?'Belum ada telemetri untuk status ini. Hubungkan sumber monitoring terlebih dahulu.':'Tidak ada pelanggan yang sesuai pencarian.'}}</td></tr></tbody></table></div><Pagination :links="customers.links"/>
   <div v-if="selected" class="card space-y-4 p-6"><div class="heading"><h2>{{selected.name}}</h2><button class="btn" @click="selected=null">Tutup</button></div><p class="muted">SN: {{selected.ont_serial_number||'Belum diisi'}} · PPPoE: {{selected.pppoe_username||'Belum diisi'}} · Sinkronisasi terakhir: {{selected.observed_at??"belum pernah"}}</p><p class="muted">Identitas OLT / PON / ONU harus diverifikasi dari CMS sebelum tindakan diaktifkan.</p><div class="flex flex-wrap gap-2"><CmsPanel :key="selected.id" :section="section" :connector="connector" :olts="olts" :templates="templates" :selected="selected"/><Link :href="'/customers/'+selected.id" class="btn">Buka pelanggan</Link></div></div>
   <div class="grid gap-4 lg:grid-cols-3"><div class="card p-5"><h2>Online / offline</h2><p class="muted mt-2">Sesi PPPoE berasal dari router/RADIUS. Koneksi ONT berasal dari CMS. Keduanya bisa berbeda.</p></div><div class="card p-5"><h2>Deactivated</h2><p class="muted mt-2">ONT dinonaktifkan secara administratif. Status langganan pelanggan tetap dicatat terpisah.</p></div><div class="card p-5"><h2>Dying gasp</h2><p class="muted mt-2">ONT melaporkan kehilangan daya. Ditampilkan sebagai penyebab offline, bukan status suspend. ONT offline tidak otomatis dianggap dying gasp.</p></div></div>
  </template>

  <template v-if="section==='olts'">
   <h2>Pemetaan OLT untuk operasi perangkat</h2>
   <div class="grid items-start gap-6 xl:grid-cols-2"><div class="tablewrap"><table><thead><tr><th>OLT</th><th>External ID CMS</th><th>Status</th><th></th></tr></thead><tbody><tr v-for="row in olts" :key="row.id"><td>{{row.name}}<p class="muted text-xs">{{row.host||'IP belum diisi'}}</p></td><td>{{row.external_id}}</td><td class="muted">Belum diverifikasi</td><td><button v-if="can('network.update')" class="btn" @click="editOlt(row)">Edit</button></td></tr><tr v-if="!olts.length"><td colspan="4" class="p-8 text-center muted">Belum ada OLT. Daftarkan identitas OLT dari CMS Anda.</td></tr></tbody></table></div>
   <form v-if="can('network.update')" class="card space-y-4 p-6" @submit.prevent="olt.post('/operations/olts',{onSuccess:()=>olt.reset()})"><h2>{{olt.id?'Edit OLT':'Daftarkan OLT'}}</h2><p class="muted">Ini menyimpan pemetaan lokal; tidak menambahkan perangkat ke CMS.</p><p v-if="Object.keys(olt.errors).length" class="error">{{Object.values(olt.errors).join(' · ')}}</p><label>Nama OLT<input v-model="olt.name" required placeholder="OLT Bojongsari"></label><label>External ID dari CMS<input v-model="olt.external_id" required placeholder="Identitas unik OLT pada CMS"></label><label>IP manajemen OLT<input v-model="olt.host" placeholder="Opsional"></label><div class="flex gap-2"><button class="btn primary" :disabled="olt.processing">Simpan OLT</button><button v-if="olt.id" type="button" class="btn" @click="olt.reset()">Batal edit</button></div></form></div>
  </template>

  <template v-if="section==='templates'">
   <div class="grid items-start gap-6 xl:grid-cols-2"><div class="space-y-4"><div v-for="row in templates" :key="row.id" class="card p-5"><div class="heading"><div><h2>{{row.name}}</h2><p class="muted mt-1">{{oltName(row.olt_id)}}</p></div><span class="badge">VLAN {{row.vlan}}</span></div><p class="muted mt-4">PPPoE · Tagged · {{row.binding}}</p><p class="muted mt-2">Line: {{row.line_profile}} · Service: {{row.service_profile}}</p><button v-if="can('network.update')" class="btn mt-4" @click="editTemplate(row)">Edit template</button></div><div v-if="!templates.length" class="card p-8"><h2>Definisikan layanan pertama</h2><p class="muted mt-2">Simpan VLAN dan nama profil yang sudah tersedia di masing-masing OLT. Template bisa dipilih di menu Aktivasi ONT.</p></div></div>
   <form v-if="can('network.update')" class="card space-y-4 p-6" @submit.prevent="template.post('/operations/templates',{onSuccess:()=>template.reset()})"><h2>{{template.id?'Edit template':'Template baru'}}</h2><p v-if="Object.keys(template.errors).length" class="error">{{Object.values(template.errors).join(' · ')}}</p><label>Nama layanan<input v-model="template.name" required placeholder="Internet Rumah"></label><label>OLT<select v-model="template.olt_id" required><option value="" disabled>Pilih OLT</option><option v-for="row in olts" :key="row.id" :value="row.id">{{row.name}}</option></select></label><label>VLAN internet<input v-model.number="template.vlan" type="number" min="1" max="4094" required></label><div class="gridform"><label>Line Profile<input v-model="template.line_profile" required></label><label>Service Profile<input v-model="template.service_profile" required></label><label>WAN Profile<input v-model="template.wan_profile" required></label><label>TR-069 Profile<input v-model="template.tr069_profile" required></label></div><label>Binding LAN / SSID<input v-model="template.binding" required placeholder="LAN1,SSID4"></label><p class="muted">Mode PPPoE, VLAN tagged. Gunakan profil OLT yang sudah tersedia dan menghasilkan WAN PPPoE VLAN ini. Binding: LAN1?LAN4; SSID4?SSID12 memakai indeks CDATA, dipisah koma.</p><div class="flex gap-2"><button class="btn primary" :disabled="template.processing||!olts.length">Simpan template</button><button v-if="template.id" class="btn" type="button" @click="template.reset()">Batal edit</button></div><Link v-if="!olts.length" href="/operations/olts" class="link">Daftarkan OLT terlebih dahulu</Link></form></div>
  </template>


 </div></AppLayout>
</template>

<style scoped>
.operations-page button:disabled {cursor:not-allowed;}
.operations-page .border {border-color:var(--edge);}
</style>
