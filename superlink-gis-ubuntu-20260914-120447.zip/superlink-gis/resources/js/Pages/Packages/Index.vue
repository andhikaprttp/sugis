<script setup lang="ts">
import {ref} from 'vue';
import {Head,router,useForm} from '@inertiajs/vue3';
import AppLayout from '../../Layouts/AppLayout.vue';
import Pagination from '../../Components/Pagination.vue';
import {can} from '../../lib';
defineProps<{packages:any}>();const search=ref('');const editing=ref<string|null>(null);
const form=useForm({name:'',speed_mbps:20,price:0,active:true});
const rupiah=(n:any)=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0,maximumFractionDigits:2}).format(Number(n));
function edit(p:any){editing.value=p.id;form.clearErrors();Object.assign(form,{name:p.name,speed_mbps:p.speed_mbps,price:Number(p.price),active:p.active});document.getElementById('package-form')?.scrollIntoView({behavior:'smooth'});}
function save(){const options={preserveScroll:true,onSuccess:()=>{editing.value=null;form.reset();}};if(editing.value)form.put('/packages/'+editing.value,options);else form.post('/packages',options);}
</script>
<template><Head title="Harga paket"/><AppLayout title="Harga paket"><div class="page"><div><h1>Harga paket</h1><p class="muted mt-2">Katalog paket internet. Harga dalam rupiah per bulan.</p></div>
<form class="flex gap-2" @submit.prevent="router.get('/packages',{search},{preserveState:true})"><input v-model="search" placeholder="Cari nama paket…" aria-label="Cari paket"/><button class="btn">Cari</button></form>
<div class="tablewrap"><table><thead><tr><th>Paket</th><th>Kecepatan</th><th>Harga / bulan</th><th>Status</th><th v-if="can('settings.manage')">Aksi</th></tr></thead><tbody><tr v-for="p in packages.data" :key="p.id"><td>{{p.name}}</td><td>{{p.speed_mbps}} Mbps</td><td>{{rupiah(p.price)}}</td><td>{{p.active?'Aktif':'Nonaktif'}}</td><td v-if="can('settings.manage')"><button class="btn" @click="edit(p)">Edit</button></td></tr><tr v-if="!packages.data.length"><td colspan="5" class="py-8 text-center muted">Belum ada paket yang cocok.</td></tr></tbody></table></div><Pagination :links="packages.links"/>
<form v-if="can('settings.manage')" id="package-form" class="card space-y-4 p-6" @submit.prevent="save"><h2>{{editing?'Edit paket':'Tambah paket'}}</h2><div class="gridform"><label>Nama paket<input v-model="form.name" required maxlength="255"/></label><label>Kecepatan (Mbps)<input v-model.number="form.speed_mbps" type="number" min="1" max="100000" required/></label><label>Harga per bulan (Rp)<input v-model.number="form.price" type="number" min="0" max="9999999999.99" step="0.01" required/></label><label class="flex items-center gap-2"><input v-model="form.active" type="checkbox"/>Aktif / dapat dipilih</label></div><p class="muted">Harga pelanggan lama tidak berubah otomatis. Nonaktifkan paket untuk menghentikan pilihan baru.</p><p v-if="Object.keys(form.errors).length" class="error">{{Object.values(form.errors).join(' · ')}}</p><div class="flex gap-2"><button class="btn primary" :disabled="form.processing">Simpan paket</button><button v-if="editing" type="button" class="btn" @click="editing=null;form.reset();form.clearErrors()">Batal</button></div></form>
</div></AppLayout></template>
