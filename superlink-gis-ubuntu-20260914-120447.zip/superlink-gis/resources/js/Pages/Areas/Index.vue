<script setup lang="ts">
import {Head,Link} from '@inertiajs/vue3';
import AppLayout from '../../Layouts/AppLayout.vue';
import Pagination from '../../Components/Pagination.vue';
defineProps<{areas:any}>();
</script>
<template><Head title="Area Coverage"/><AppLayout title="Area Coverage"><div class="page">
    <div class="heading"><div><h1>Area Coverage</h1><p class="muted mt-2">Kelola daerah yang dicakup dan tambahkan jaringan dari KMZ/KML.</p></div><Link href="/areas/create" class="btn primary">Tambah Area</Link></div>
    <div class="tablewrap"><table><thead><tr><th>Area</th><th>Daerah</th><th>Objek</th><th>Impor</th><th>Aksi</th></tr></thead><tbody>
        <tr v-for="area in areas.data" :key="area.id"><td class="font-semibold">{{area.name}}</td><td>{{area.village}}<div class="muted text-xs">{{area.district}}, {{area.city}}</div></td><td>{{area.objects_count}}</td><td>{{area.imports_count}}</td><td><div class="flex flex-wrap gap-2"><Link class="btn" :href="'/areas/create?service_area_id='+area.id">Tambah KMZ ke area</Link><Link class="btn" :href="'/map?service_area_id='+area.id">Lihat peta</Link></div></td></tr>
        <tr v-if="!areas.data.length"><td colspan="5" class="py-10 text-center">Belum ada daerah. Pilih Tambah Area untuk mulai mengimpor cakupan.</td></tr>
    </tbody></table></div><Pagination :links="areas.links"/>
    <p class="muted">Data jaringan lama tetap tersedia di peta Semua area. Menambah KMZ tidak menghapus cakupan sebelumnya.</p>
</div></AppLayout></template>
