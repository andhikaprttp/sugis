<script setup lang="ts">
import {computed,ref,watch} from 'vue';
import {Head,Link,useForm} from '@inertiajs/vue3';
import AppLayout from '../../Layouts/AppLayout.vue';
type Area={id:string;name:string;village:string;district:string;city:string};
const props=defineProps<{areas:Area[];selectedAreaId:string|null}>();
const creating=ref(!props.areas.length);
const area=useForm({name:'',village:'',district:'',city:'',notes:''});
const upload=useForm<{service_area_id:string;file:File|null}>({service_area_id:props.selectedAreaId??'',file:null});
watch(()=>props.selectedAreaId,id=>{if(id){upload.service_area_id=id;creating.value=false;area.reset();}});
const selected=computed(()=>props.areas.find(a=>a.id===upload.service_area_id));
function submit(){if(!upload.file)return;if(upload.file.size>256*1024*1024){upload.setError('file','Maksimum file 256 MB.');return;}upload.post('/gis/import',{forceFormData:true});}
</script>
<template><Head title="Tambah Area"/><AppLayout title="Tambah Area"><div class="page max-w-4xl">
    <div class="heading"><div><h1>Tambah Area</h1><p class="muted mt-2">Tentukan daerah tujuan, lalu unggah KMZ/KML untuk menambahkan cakupan.</p></div><Link class="btn" href="/areas">Daftar area</Link></div>
    <section class="card space-y-4 p-6"><h2>1. Tentukan daerah</h2>
        <div class="flex flex-wrap gap-2"><button class="btn" :class="!creating?'primary':''" :disabled="!areas.length||upload.processing" @click="creating=false">Area yang sudah ada</button><button class="btn" :class="creating?'primary':''" :disabled="upload.processing" @click="creating=true">Daerah baru</button></div>
        <form v-if="creating" class="space-y-4" @submit.prevent="area.post('/areas',{preserveScroll:true})">
            <div v-if="Object.keys(area.errors).length" class="error">{{Object.values(area.errors).join(' · ')}}</div>
            <div class="gridform"><label>Nama area<input v-model="area.name" required maxlength="255" placeholder="Contoh: Coverage Cinangka Barat"/></label><label>Kelurahan / Desa<input v-model="area.village" required maxlength="255"/></label><label>Kecamatan<input v-model="area.district" required maxlength="255"/></label><label>Kota / Kabupaten<input v-model="area.city" required maxlength="255"/></label></div>
            <label>Catatan<textarea v-model="area.notes" maxlength="3000"/></label><button class="btn primary" :disabled="area.processing">Simpan daerah & lanjutkan</button>
        </form>
        <label v-else>Daerah tujuan<select v-model="upload.service_area_id" :disabled="upload.processing"><option value="">Pilih daerah</option><option v-for="a in areas" :key="a.id" :value="a.id">{{a.name}} — {{a.village}}, {{a.district}}, {{a.city}}</option></select></label>
    </section>
    <form v-if="!creating&&selected" class="card space-y-4 p-6" @submit.prevent="submit"><h2>2. Tambahkan KMZ / KML</h2><div class="rounded-lg border p-4"><strong>{{selected.name}}</strong><p class="muted">{{selected.village}}, {{selected.district}}, {{selected.city}}</p></div>
        <p class="muted">Data lama tetap tersimpan. File baru ditinjau dahulu sebelum masuk ke area ini. Maksimum 256 MB dan 20.000 objek.</p><div v-if="Object.keys(upload.errors).length" class="error">{{Object.values(upload.errors).join(' · ')}}</div>
        <input type="file" accept=".kmz,.kml" required :disabled="upload.processing" @change="upload.file=($event.target as HTMLInputElement).files?.[0]??null"/>
        <button class="btn primary" :disabled="upload.processing">{{upload.processing?'Memproses…':'Upload & tinjau'}}</button><p v-if="upload.progress" class="muted">Upload {{upload.progress.percentage}}%</p>
    </form>
</div></AppLayout></template>
