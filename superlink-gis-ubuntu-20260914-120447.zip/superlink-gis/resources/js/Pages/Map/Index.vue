<script setup lang="ts">
import AppLayout from '../../Layouts/AppLayout.vue';
import Workspace from '../../Map/Workspace.vue';
import {Head,Link} from '@inertiajs/vue3';
import {ref} from 'vue';
import {can} from '../../lib';
defineProps<{serviceAreas:{id:string;name:string;village:string}[]}>();
const workspace=ref<InstanceType<typeof Workspace>>();
const planning=ref(false);
const params=new URLSearchParams(window.location.search);
const focusId=params.get('focus')??undefined;
const serviceAreaId=ref(params.get('service_area_id')??'');
function selectArea(){const url=new URL(window.location.href);if(serviceAreaId.value)url.searchParams.set('service_area_id',serviceAreaId.value);else url.searchParams.delete('service_area_id');window.history.replaceState({},'',url);}
</script>
<template><Head title="Network Map"/><AppLayout title="Network Map"><template #actions><button class="btn planner-nav" :class="{primary:planning}" :aria-expanded="planning" aria-controls="cable-planner" @click="workspace?.togglePlanner()">Perencanaan kabel</button></template><div class="map-page"><div class="map-area-toolbar flex flex-wrap items-center gap-3 border-b px-5 py-3"><label class="flex items-center gap-2">Daerah<select v-model="serviceAreaId" @change="selectArea"><option value="">Semua area</option><option v-for="a in serviceAreas" :key="a.id" :value="a.id">{{a.name}} — {{a.village}}</option></select></label><Link v-if="can('gis.import')" class="btn" href="/areas/create">Tambah Area / KMZ</Link></div><div class="map-screen"><Workspace ref="workspace" @planning="planning=$event" :focus-id="focusId" :service-area-id="serviceAreaId"/></div></div></AppLayout></template>
