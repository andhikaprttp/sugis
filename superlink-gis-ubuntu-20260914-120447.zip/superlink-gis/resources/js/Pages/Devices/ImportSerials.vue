<script setup lang="ts">
import {ref,watch,onBeforeUnmount} from 'vue';
import {Head,Link,useForm} from '@inertiajs/vue3';
import AppLayout from '../../Layouts/AppLayout.vue';
import {api,errorText} from '../../lib';
const form=useForm({serials:'',location:'Gudang utama',vendor:'',model:''});
const preview=ref<any>(null);const busy=ref(false);const error=ref('');
let timer:ReturnType<typeof setTimeout>;let request:AbortController|undefined;
async function check(){const current=new AbortController();request=current;busy.value=true;try{const response=await api.post('/devices/import-serials/preview',{serials:form.serials},{signal:current.signal});if(!current.signal.aborted)preview.value=response.data;}catch(e){if(!current.signal.aborted)error.value=errorText(e);}finally{if(request===current)busy.value=false;}}
watch(()=>form.serials,()=>{clearTimeout(timer);request?.abort();preview.value=null;error.value='';busy.value=false;if(form.serials.trim()){busy.value=true;timer=setTimeout(check,400);}});
onBeforeUnmount(()=>{clearTimeout(timer);request?.abort();});
</script>
<template><Head title="Impor serial ONT"/><AppLayout title="Impor serial ONT"><div class="page max-w-4xl"><div class="heading"><div><h1>Impor serial ONT</h1><p class="muted mt-2">Tempel daftar serial dari teks atau tabel. Maksimum 1.000 serial per impor.</p></div><Link class="btn" href="/devices?type=ONT&status=IN_STOCK">Stok ONT</Link></div>
<form class="card space-y-5 p-6" @submit.prevent="form.post('/devices/import-serials')"><label>Daftar serial<textarea v-model="form.serials" :disabled="form.processing" rows="10" maxlength="150000" required class="font-mono" placeholder="YEKGCB923474&#10;YEKGCBF47032&#10;YEKGCBBE6D04"/></label><p class="muted text-xs">Satu serial per baris. Pemisah spasi, koma, titik koma, dan tabel dengan tanda | juga diterima. Kode aset dibuat otomatis.</p>
<p v-if="busy" role="status" class="muted">Menghitung serial…</p><div v-if="preview" class="grid grid-cols-2 gap-3 sm:grid-cols-4"><div class="stat"><span>Total teks</span><strong>{{preview.total}}</strong></div><div class="stat"><span>Siap masuk stok</span><strong>{{preview.ready.length}}</strong></div><div class="stat"><span>Sudah terdaftar</span><strong>{{preview.existing.length}}</strong></div><div class="stat"><span>Duplikat teks</span><strong>{{preview.duplicates}}</strong></div></div>
<p v-if="preview?.invalid.length" class="error">Serial tidak valid: {{preview.invalid.join(', ')}}</p><details v-if="preview?.existing.length"><summary>Serial yang dilewati</summary><p class="break-words font-mono text-sm">{{preview.existing.join(', ')}}</p></details>
<div class="gridform"><label>Lokasi stok<input v-model="form.location" required maxlength="255"/></label><label>Vendor (opsional)<input v-model="form.vendor" maxlength="255"/></label><label>Model (opsional)<input v-model="form.model" maxlength="255"/></label></div>
<p v-if="error" class="error" role="alert">{{error}}</p><p v-if="Object.keys(form.errors).length" class="error" role="alert">{{Object.values(form.errors).join(' · ')}}</p><button class="btn primary" :disabled="busy||form.processing||!preview?.ready.length||!!preview?.invalid.length">{{form.processing?'Mengimpor…':'Masukkan '+(preview?.ready.length??0)+' ONT ke stok'}}</button>
</form></div></AppLayout></template>
