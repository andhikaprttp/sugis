<script setup lang="ts">
import { computed, ref, nextTick, onBeforeUnmount } from 'vue';
import { Head, Link, router, useForm } from '@inertiajs/vue3';
import { Package, Plus, Search, ArrowUpRight, RotateCcw, Pencil, X } from 'lucide-vue-next';
import AppLayout from '../../Layouts/AppLayout.vue';
import { api, can, errorText } from '../../lib';

type Customer = { id:string; customer_id:string; name:string; ont_serial_number?:string; address?:string; assignment_blocked?:string|null };
type Device = { id:string; asset_tag:string; serial_number:string; type:string; vendor:string|null; model:string|null; status:string; location:string|null; purchased_at:string|null; notes:string|null; customer:Customer|null };
const props = defineProps<{ devices:any; filters:any; summary:Record<string,number>; types:{type:string;total:number;stock:number}[]; trend:{month:string;received:number;assigned:number;returned:number}[]; history:any[]; selectedCustomer:Customer|null }>();
const labels:Record<string,string> = { IN_STOCK:'Dalam stok', INSTALLED:'Terpasang', DAMAGED:'Rusak', RETIRED:'Pensiun' };
const colors:Record<string,string> = { IN_STOCK:'#10b981', INSTALLED:'#3b82f6', DAMAGED:'#f59e0b', RETIRED:'#94a3b8' };
const actions:Record<string,string> = { RECEIVE:'Stok masuk', ASSIGN:'Pemasangan', RETURN:'Pengembalian', STATUS:'Ubah status' };
const total = computed(() => Object.values(props.summary).reduce((a,b) => a+b,0));
const typeMax = computed(() => Math.max(1,...props.types.map(t => Number(t.total))));
const trendMax = computed(() => Math.max(1,...props.trend.flatMap(t => [t.received,t.assigned,t.returned])));
const search = ref(props.filters.search ?? '');
const status = ref(props.filters.status ?? '');
const type = ref(props.filters.type ?? '');
function filter(clearCustomer=false) { router.get('/devices', {search:search.value,status:status.value,type:type.value,customer_id:clearCustomer ? undefined : props.filters.customer_id,assign_to:clearCustomer ? undefined : props.filters.assign_to}, {preserveState:true,preserveScroll:true,only:['devices','filters','selectedCustomer',...(clearCustomer?['history']:[])]}); }
const mode = ref<'create'|'edit'|'ASSIGN'|'RETURN'|'STATUS'|null>(null);
const active = ref<Device|null>(null);
const form = useForm({ asset_tag:'',serial_number:'',type:'ONT',vendor:'',model:'',location:'Gudang utama',purchased_at:'',notes:'',action:'',customer_id:'',status:'IN_STOCK' });
const customerSearch = ref('');
const options = ref<Customer[]>([]);
const searching = ref(false);
const lookupError = ref('');
let lookupRequest:AbortController|undefined;
onBeforeUnmount(()=>lookupRequest?.abort());
async function open(next:typeof mode.value, device:Device|null=null) {
    lookupRequest?.abort(); searching.value=false; form.reset(); form.clearErrors(); active.value=device; mode.value=next; options.value=[]; customerSearch.value=''; lookupError.value='';
    if(next==='edit' && device) Object.assign(form,{vendor:device.vendor??'',model:device.model??'',purchased_at:device.purchased_at??'',notes:device.notes??''});
    if(next==='STATUS' && device) form.status=device.status==='IN_STOCK'?'DAMAGED':'IN_STOCK';
    if(next==='ASSIGN' && props.selectedCustomer) {options.value=[props.selectedCustomer]; form.customer_id=props.selectedCustomer.id;}
    await nextTick(); document.getElementById('device-form')?.scrollIntoView({behavior:'smooth',block:'start'});
    document.querySelector<HTMLInputElement>('#device-form input')?.focus({preventScroll:true});
}
async function findCustomers() {
    if(customerSearch.value.trim().length<2)return;
    lookupRequest?.abort();const request=new AbortController();lookupRequest=request;
    searching.value=true; lookupError.value='';
    try { const response=await api.get('/devices/customer-options',{params:{search:customerSearch.value.trim(),device_id:active.value?.id},signal:request.signal});if(request.signal.aborted)return;options.value=response.data;form.customer_id=''; }
    catch(e) {if(!request.signal.aborted)lookupError.value=errorText(e);} finally {if(lookupRequest===request)searching.value=false;}
}
function submit() {
    const options={preserveScroll:true,onSuccess:()=>{mode.value=null;}};
    if(mode.value==='create') form.post('/devices',options);
    else if(mode.value==='edit') form.put(`/devices/${active.value!.id}`,options);
    else {form.action=mode.value!; form.post(`/devices/${active.value!.id}/transition`,options);}
}
function date(value:string) {return new Date(value).toLocaleString('id-ID');}
</script>

<template>
    <Head title="Perangkat & Stok"/>
    <AppLayout title="Perangkat & Stok">
        <div class="page">
            <div class="heading">
                <div><span class="badge"><Package :size="14" class="mr-2"/>Inventori perangkat</span><h1 class="mt-3">Perangkat & Stok</h1><p class="muted mt-2">Pantau aset, ketersediaan gudang, dan perangkat yang terpasang pada pelanggan.</p></div>
                <Link v-if="can('network.update')" class="btn primary" href="/devices/import-serials">Impor serial ONT</Link><Link class="btn" href="/devices?type=ONT&status=IN_STOCK">Stok ONT tersedia</Link><button v-if="can('network.update')" class="btn primary" @click="open('create')"><Plus :size="16"/>Tambah perangkat</button>
            </div>

            <div class="grid grid-cols-2 gap-4 xl:grid-cols-4">
                <button v-for="(label,key) in labels" :key="key" class="stat text-left" @click="status=key;filter()">
                    <span class="flex items-center gap-2 text-sm"><span class="h-2 w-2 rounded-full" :style="{background:colors[key]}"></span>{{label}}</span>
                    <strong>{{summary[key].toLocaleString('id-ID')}}</strong><span class="muted text-xs">unit perangkat</span>
                </button>
            </div>
            <p class="muted text-xs">Grafik dan ringkasan menampilkan seluruh inventori · {{total}} unit tercatat</p>
            <div class="grid gap-5 xl:grid-cols-3">
                <section class="card p-5"><h2>Komposisi status</h2><p class="muted mt-1">Distribusi seluruh perangkat</p>
                    <div v-if="total" class="mt-6 flex h-7 overflow-hidden rounded-full" role="img" :aria-label="Object.keys(labels).map(k=>labels[k]+': '+summary[k]).join(', ')">
                        <div v-for="(_,key) in labels" :key="key" :style="{width:(summary[key]/total*100)+'%',background:colors[key]}" :title="labels[key]+': '+summary[key]"></div>
                    </div><p v-else class="muted py-5">Belum ada perangkat. Tambahkan stok pertama Anda.</p>
                    <dl class="mt-5 space-y-3"><div v-for="(label,key) in labels" :key="key" class="flex justify-between text-sm"><dt class="flex items-center gap-2"><span class="h-2 w-2 rounded-full" :style="{background:colors[key]}"></span>{{label}}</dt><dd>{{summary[key]}} <span class="muted text-xs">({{total?Math.round(summary[key]/total*100):0}}%)</span></dd></div></dl>
                </section>
                <section class="card p-5"><h2>Stok per jenis</h2><p class="muted mt-1">Hijau: tersedia · Abu-abu: total</p>
                    <div class="mt-5 space-y-4"><div v-for="row in types" :key="row.type"><div class="mb-2 flex justify-between text-sm"><span>{{row.type}}</span><span>{{row.stock}} / {{row.total}} unit</span></div><div class="h-3 rounded-full" style="background:var(--surface-raised)"><div class="h-full rounded-full bg-slate-300" :style="{width:(Number(row.total)/typeMax*100)+'%'}"><div class="h-full rounded-full bg-emerald-500" :style="{width:(Number(row.stock)/Number(row.total)*100)+'%'}"></div></div></div></div><p v-if="!types.length" class="muted">Grafik akan tampil setelah perangkat ditambahkan.</p></div>
                </section>
                <section class="card p-5"><h2>Mutasi 6 bulan</h2><p class="muted mt-1">Jumlah transaksi perangkat per bulan</p>
                    <div class="mt-5 flex h-36 gap-3" role="img" aria-label="Grafik stok masuk, pemasangan, dan pengembalian enam bulan terakhir; angka tersedia pada tabel di bawah."><div v-for="row in trend" :key="row.month" class="flex min-w-0 flex-1 flex-col"><div class="flex flex-1 items-end justify-center gap-1 border-b" style="border-color:var(--edge)"><div v-for="(value,i) in [row.received,row.assigned,row.returned]" :key="i" class="w-3 rounded-t" :style="{height:(value/trendMax*100)+'%',background:['#10b981','#3b82f6','#f59e0b'][i]}" :title="`${row.month}: ${value}`"></div></div><span class="mt-2 text-center text-[10px]">{{row.month.slice(5)}}/{{row.month.slice(2,4)}}</span></div></div>
                    <div class="mt-3 flex flex-wrap gap-3 text-xs"><span class="text-emerald-600">● Masuk</span><span class="text-blue-500">● Pasang</span><span class="text-amber-600">● Kembali</span></div>
                    <details class="mt-3 text-xs"><summary class="cursor-pointer">Lihat angka mutasi</summary><table class="mt-2 w-full"><thead><tr><th>Bulan</th><th>Masuk</th><th>Pasang</th><th>Kembali</th></tr></thead><tbody><tr v-for="row in trend" :key="row.month"><td>{{row.month}}</td><td>{{row.received}}</td><td>{{row.assigned}}</td><td>{{row.returned}}</td></tr></tbody></table></details>
                </section>
            </div>

            <section class="space-y-4"><div v-if="filters.assign_to&&selectedCustomer" class="card p-4"><strong>Pilih ONT untuk {{selectedCustomer.name}}</strong><p class="muted">Klik Assign pelanggan pada stok yang akan dipasang. Pelanggan tujuan sudah terisi.</p></div>
                <div class="heading"><div><h2>Daftar perangkat</h2><p v-if="selectedCustomer" class="muted mt-1">Pelanggan: {{selectedCustomer.name}} <button class="link ml-2" @click="filter(true)">Tampilkan semua stok</button></p></div><span class="badge">{{devices.total}} hasil</span></div>
                <form class="flex flex-wrap items-end gap-3" @submit.prevent="filter()"><label class="min-w-[200px] flex-1">Cari aset, serial, atau model<input v-model="search" class="mt-1" placeholder="Contoh: ONT-001 atau serial perangkat"/></label><label>Status<select v-model="status" class="mt-1" @change="filter()"><option value="">Semua status</option><option v-for="(label,key) in labels" :key="key" :value="key">{{label}}</option></select></label><label>Jenis<select v-model="type" class="mt-1" @change="filter()"><option value="">Semua jenis</option><option v-for="t in ['ONT','ROUTER','STB','OTHER']" :key="t">{{t}}</option></select></label><button class="btn" type="submit"><Search :size="16"/>Cari</button></form>
                <div class="tablewrap"><table><thead><tr><th>Aset / Serial</th><th>Perangkat</th><th>Status</th><th>Lokasi / Pelanggan</th><th>Aksi</th></tr></thead><tbody>
                    <tr v-for="device in devices.data as Device[]" :key="device.id"><td><div class="font-semibold">{{device.asset_tag}}</div><div class="muted mt-1 font-mono text-xs">{{device.serial_number}}</div></td><td>{{device.type}}<div class="muted mt-1 text-xs">{{[device.vendor,device.model].filter(Boolean).join(' · ')||'Model belum diisi'}}</div></td><td><span class="inline-flex items-center gap-2 whitespace-nowrap text-xs"><span class="h-2 w-2 rounded-full" :style="{background:colors[device.status]}"></span>{{labels[device.status]}}</span></td><td><Link v-if="device.customer" class="link" :href="'/customers/'+device.customer.id">{{device.customer.name}}<span class="muted block text-xs">{{device.customer.customer_id}}</span></Link><span v-else>{{device.location||'—'}}</span></td><td><div v-if="can('network.update')" class="flex flex-wrap gap-2"><button v-if="device.status==='IN_STOCK'&&can('customer.update')" class="btn" @click="open('ASSIGN',device)"><ArrowUpRight :size="14"/>Assign pelanggan</button><button v-if="device.status==='INSTALLED'&&can('customer.update')" class="btn" @click="open('RETURN',device)"><RotateCcw :size="14"/>Kembalikan</button><template v-if="device.status!=='INSTALLED'"><button class="btn" @click="open('STATUS',device)">Status</button><button class="btn" :aria-label="'Edit '+device.asset_tag" @click="open('edit',device)"><Pencil :size="14"/></button></template></div><span v-else class="muted text-xs">Hanya lihat</span></td></tr>
                    <tr v-if="!devices.data.length"><td colspan="5" class="py-10 text-center"><Package class="mx-auto mb-3 text-slate-400" :size="28"/><p>Belum ada perangkat yang cocok.</p><p class="muted mt-1">Tambahkan perangkat atau ubah filter pencarian.</p></td></tr>
                </tbody></table></div>
                <div class="flex items-center justify-between"><p class="muted text-xs">Halaman {{devices.current_page}} dari {{devices.last_page}}</p><div class="flex gap-2"><Link v-if="devices.prev_page_url" class="btn" :href="devices.prev_page_url" preserve-scroll>Sebelumnya</Link><Link v-if="devices.next_page_url" class="btn" :href="devices.next_page_url" preserve-scroll>Berikutnya</Link></div></div>
            </section>
            <section><h2>Riwayat mutasi</h2><p class="muted mt-1 mb-4">30 transaksi terakhir{{selectedCustomer?' untuk pelanggan ini':''}}. Pencarian dan filter status berlaku pada daftar perangkat.</p><div class="tablewrap"><table><thead><tr><th>Waktu</th><th>Aset</th><th>Mutasi</th><th>Pelanggan / Petugas</th><th>Catatan</th></tr></thead><tbody><tr v-for="row in history" :key="row.id"><td class="whitespace-nowrap">{{date(row.created_at)}}</td><td>{{row.asset_tag}}<div class="muted text-xs">{{row.serial_number}}</div></td><td>{{actions[row.action]}}<div class="muted text-xs">{{row.from_status?labels[row.from_status]+' → ':''}}{{labels[row.to_status]}}</div></td><td>{{row.customer_name||'—'}}<div class="muted text-xs">{{row.actor||'Sistem'}}</div></td><td class="max-w-xs whitespace-pre-wrap break-words">{{row.notes||'—'}}</td></tr><tr v-if="!history.length"><td colspan="5" class="py-8 text-center muted">Belum ada mutasi perangkat.</td></tr></tbody></table></div></section>

            <section v-if="mode" class="card p-6" id="device-form" role="region" aria-label="Form perangkat">
                <div class="heading"><div><h2>{{mode==='create'?'Tambah perangkat ke stok':mode==='edit'?'Edit detail perangkat':mode==='ASSIGN'?'Pasang ke pelanggan':mode==='RETURN'?'Kembalikan perangkat':'Ubah status perangkat'}}</h2><p v-if="active" class="muted mt-1">{{active.asset_tag}} · {{active.serial_number}}</p></div><button class="btn" aria-label="Tutup form" :disabled="form.processing" @click="mode=null"><X :size="16"/></button></div>
                <form class="mt-5 space-y-5" @submit.prevent="submit()">
                    <div v-if="Object.keys(form.errors).length" class="error" role="alert">{{Object.values(form.errors).join(' · ')}}</div>
                    <div v-if="mode==='create'||mode==='edit'" class="gridform">
                        <template v-if="mode==='create'"><label>Kode aset<input v-model="form.asset_tag" required maxlength="100" placeholder="ONT-0001"/></label><label>Serial number<input v-model="form.serial_number" required maxlength="255" placeholder="Serial unik perangkat"/></label><label>Jenis perangkat<select v-model="form.type"><option v-for="t in ['ONT','ROUTER','STB','OTHER']" :key="t">{{t}}</option></select></label><label>Lokasi stok<input v-model="form.location" required maxlength="255"/></label></template>
                        <label>Vendor / Merek<input v-model="form.vendor" maxlength="255" placeholder="Contoh: CDATA"/></label><label>Model<input v-model="form.model" maxlength="255" placeholder="Model perangkat"/></label><label>Tanggal pembelian<input v-model="form.purchased_at" type="date"/></label>
                    </div>
                    <div v-if="mode==='ASSIGN'" class="space-y-3"><p class="muted">ONT akan mengisi serial, model, dan vendor pada pelanggan. Untuk mengganti ONT inventori, kembalikan ONT lama terlebih dahulu.</p><label>Cari pelanggan (minimal 2 karakter)<div class="mt-1 flex gap-2"><input v-model="customerSearch" placeholder="Nama atau ID pelanggan" @keydown.enter.prevent="findCustomers()"/><button type="button" class="btn" :disabled="searching||customerSearch.trim().length<2" @click="findCustomers()">{{searching?'Mencari…':'Cari'}}</button></div></label><p v-if="lookupError" class="error">{{lookupError}}</p><label>Pelanggan<select v-model="form.customer_id" required><option value="">Pilih hasil pencarian</option><option v-for="c in options" :key="c.id" :value="c.id" :disabled="!!c.assignment_blocked">{{c.assignment_blocked?c.assignment_blocked+' ? ':''}}{{c.customer_id}} · {{c.name}}{{c.ont_serial_number?' · ONT '+c.ont_serial_number:''}}</option></select></label><p v-if="!options.length" class="muted text-xs">Cari pelanggan untuk menampilkan hingga 20 hasil.</p></div>
                    <div v-if="mode==='RETURN'||mode==='STATUS'" class="gridform"><label>Status tujuan<select v-model="form.status"><option v-for="s in ['IN_STOCK','DAMAGED','RETIRED']" :key="s" :value="s">{{labels[s]}}</option></select></label><label>Lokasi penyimpanan<input v-model="form.location" required maxlength="255"/></label><p v-if="mode==='RETURN'" class="muted md:col-span-2">Penempatan pelanggan dilepas. Untuk ONT, data serial, model, dan vendor pelanggan juga dikosongkan.</p></div>
                    <label>Catatan<textarea v-model="form.notes" maxlength="3000" rows="3" placeholder="Kondisi perangkat, nomor pembelian, atau alasan mutasi"></textarea></label>
                    <div class="flex gap-2"><button type="submit" class="btn primary" :disabled="form.processing">{{form.processing?'Menyimpan…':'Simpan'}}</button><button type="button" class="btn" :disabled="form.processing" @click="mode=null">Batal</button></div>
                </form>
            </section>
        </div>
    </AppLayout>
</template>
