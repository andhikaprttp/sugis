import axios from 'axios';
import { usePage } from '@inertiajs/vue3';
export const types=['UNCLASSIFIED','POP','ODC','ODP','POLE','CLOSURE','CUSTOMER','PROSPECT','FIBER_ROUTE','AREA','OTHER'];
export const statuses=['PROSPECT','SURVEY','WAITING_INSTALLATION','ACTIVE','SUSPENDED','INACTIVE','TERMINATED'];
export const api=axios.create({headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest'}});
export function errorText(e:any):string{return Object.values(e?.response?.data?.errors??{}).flat().join(' · ')||e?.response?.data?.message||e.message||'Permintaan gagal';}
export function can(permission:string):boolean{const p=usePage().props as any;return p.auth?.roles?.includes('ADMIN')||p.auth?.permissions?.includes(permission);}
export function formatMeters(n:any){return Number(n??0).toLocaleString('id-ID',{maximumFractionDigits:1})+' m';}
export function portColor(a:any,status:string){if(status!=='ACTIVE')return '#94a3b8';if(!a?.available)return '#dc4545';return a.available/Math.max(1,a.capacity)>.5?'#16836e':'#d49a17';}
