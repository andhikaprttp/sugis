import { computed, ref } from 'vue';

export type ThemePreference = 'light' | 'dark' | 'system';
const preference = ref<ThemePreference>('system');
const systemDark = ref(false);
export const isDark = computed(() => preference.value === 'dark' || (preference.value === 'system' && systemDark.value));

export function validTheme(value: string | null): ThemePreference {
  return value === 'light' || value === 'dark' ? value : 'system';
}

function applyTheme() {
  document.documentElement.classList.toggle('dark', isDark.value);
  document.documentElement.style.colorScheme = isDark.value ? 'dark' : 'light';
}

export function initializeTheme() {
  try { preference.value = validTheme(localStorage.getItem('superlink.theme')); } catch { /* Storage may be disabled. */ }
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  systemDark.value = media.matches;
  media.addEventListener('change', event => { systemDark.value = event.matches; applyTheme(); });
  window.addEventListener('storage', event => {
    if (event.key === 'superlink.theme') { preference.value = validTheme(event.newValue); applyTheme(); }
  });
  applyTheme();
}

export function useTheme() {
  function setTheme(value: ThemePreference) {
    preference.value = validTheme(value);
    try { localStorage.setItem('superlink.theme', preference.value); } catch { /* Preference still applies to this tab. */ }
    applyTheme();
  }
  return { preference, isDark, setTheme };
}
