<script setup lang="ts">
import { Link } from '@inertiajs/vue3';
import { Package } from 'lucide-vue-next';
import { can } from '../lib';
defineProps<{customer:any}>();
</script>
<template>
    <section class="card p-6">
        <Link v-if="can('network.update')&&can('customer.update')&&!customer.devices?.some((d:any)=>d.type==='ONT')" class="btn primary mb-4" :href="'/devices?type=ONT&status=IN_STOCK&assign_to='+customer.id">Assign ONT dari stok</Link>
        <div class="heading"><h2 class="flex items-center gap-2"><Package :size="20"/>Perangkat pelanggan</h2><Link v-if="can('network.view')" class="btn" :href="'/devices?customer_id='+customer.id">Perangkat & Stok</Link></div>
        <div v-if="customer.devices?.length" class="mt-4 grid gap-3 sm:grid-cols-2"><div v-for="device in customer.devices" :key="device.id" class="rounded-lg border p-4"><span class="badge">{{device.type}} · Terpasang</span><p class="mt-3 font-semibold">{{device.asset_tag}}</p><p class="muted mt-1">{{[device.vendor,device.model].filter(Boolean).join(' · ')||'Model belum diisi'}}</p><p class="mt-2 break-all font-mono text-xs">SN: {{device.serial_number}}</p></div></div>
        <p v-else class="muted mt-4">Belum ada perangkat inventori yang dipasang. Tambahkan unit ke stok, lalu pilih Pasang untuk menghubungkannya ke pelanggan ini.</p>
        <p v-if="!customer.devices?.some((d:any)=>d.type==='ONT')&&customer.ont_serial_number" class="muted mt-3 text-xs">ONT {{customer.ont_serial_number}} masih berupa data pelanggan. Daftarkan serial yang sama di stok lalu pasang ke pelanggan ini untuk mulai mencatat aset.</p>
    </section>
</template>
