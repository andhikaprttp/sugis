<script setup lang="ts">
import {ref,watch,onBeforeUnmount} from 'vue';
import {useForm} from '@inertiajs/vue3';
import {api,can,errorText} from '../lib';
const props=defineProps<{customer:any}>();
const open=ref(false);const query=ref('');const options=ref<any[]>([]);const busy=ref(false);const error=ref('');
const form=useForm<{package_id:string|null}>({package_id:props.customer.package_id??null});
const rupiah=(n:any)=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0,maximumFractionDigits:2}).format(Number(n));
let timer:ReturnType<typeof setTimeout>;let request:AbortController|undefined;
async function load(){request?.abort();const current=new AbortController();request=current;busy.value=true;error.value='';try{const r=await api.get('/packages/options',{params:{search:query.value},signal:current.signal});if(!current.signal.aborted)options.value=r.data;}catch(e){if(!current.signal.aborted)error.value=errorText(e);}finally{if(request===current)busy.value=false;}}
watch(query,()=>{request?.abort();clearTimeout(timer);timer=setTimeout(load,300);});
watch(()=>props.customer.package_id,id=>{form.package_id=id??null;});
onBeforeUnmount(()=>{clearTimeout(timer);request?.abort();});
</script>
<template><section class="card space-y-4 p-6"><div class="heading"><h2>Paket langganan</h2><button v-if="can('customer.update')" class="btn" @click="open=!open;if(open)load()">{{open?'Tutup':'Pilih / ganti paket'}}</button></div>
<div><strong>{{customer.package_name||'Belum ada paket'}}</strong><p class="muted">{{customer.package_speed?customer.package_speed+' Mbps':''}}<span v-if="customer.package_price!==null&&customer.package_price!==undefined"> · {{rupiah(customer.package_price)}} / bulan</span></p></div>
<form v-if="open&&can('customer.update')" class="space-y-3" @submit.prevent="form.put('/customers/'+customer.id,{preserveScroll:true,onSuccess:()=>open=false})"><label>Cari nama paket<input v-model="query" placeholder="Ketik nama paket…" maxlength="100"/></label><p v-if="busy" class="muted" role="status">Mencari paket…</p><label>Pilih paket<select v-model="form.package_id" :disabled="busy||form.processing"><option :value="null">Tanpa paket</option><option v-if="customer.package_id&&!options.some(p=>p.id===customer.package_id)" :value="customer.package_id">{{customer.package_name}} (paket saat ini)</option><option v-for="p in options" :key="p.id" :value="p.id">{{p.name}} — {{p.speed_mbps}} Mbps — {{rupiah(p.price)}} / bulan</option></select></label><p class="muted text-xs">Menampilkan hingga 30 paket aktif. Persempit pencarian jika paket belum terlihat. Harga katalog diterapkan saat disimpan.</p><p v-if="error" class="error">{{error}}</p><p v-if="Object.keys(form.errors).length" class="error">{{Object.values(form.errors).join(' · ')}}</p><button class="btn primary" :disabled="busy||form.processing||!!error">Simpan pilihan paket</button></form>
</section></template>
