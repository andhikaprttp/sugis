<script setup lang="ts">import {t} from '../locale';
import { Moon, Sun, Monitor } from 'lucide-vue-next';
import { useTheme, type ThemePreference } from '../theme';
const { preference, setTheme } = useTheme();
const options: { value: ThemePreference; label: string; icon: any }[] = [
  { value: 'light', label: 'Mode terang', icon: Sun },
  { value: 'dark', label: 'Mode gelap', icon: Moon },
  { value: 'system', label: 'Ikuti tema perangkat', icon: Monitor },
];
</script>
<template>
  <div class="theme-switch" role="group" :aria-label="t('Tema aplikasi')">
    <button v-for="option in options" :key="option.value" type="button" :aria-label="t(option.label)"
      :title="t(option.label)" :aria-pressed="preference === option.value" :class="{ active: preference === option.value }"
      @click="setTheme(option.value)"><component :is="option.icon" :size="16" /></button>
  </div>
</template>
