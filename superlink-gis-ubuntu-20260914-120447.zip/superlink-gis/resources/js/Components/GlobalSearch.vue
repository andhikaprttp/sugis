<script setup lang="ts">
import {computed,onBeforeUnmount,ref,watch} from 'vue';
import {Link} from '@inertiajs/vue3';
import {Search,X} from 'lucide-vue-next';
import {t} from '../locale';
import {api,errorText} from '../lib';
type Item={id:string|number;title:string;subtitle:string;url:string};
type Group={key:string;label:string;has_more:boolean;items:Item[]};
const query=ref('');
const groups=ref<Group[]>([]);
const busy=ref(false);
const searched=ref(false);
const error=ref('');
const count=computed(()=>groups.value.reduce((sum,g)=>sum+g.items.length,0));
let timer:ReturnType<typeof setTimeout>|undefined;
let request:AbortController|undefined;
function cancel(){clearTimeout(timer);request?.abort();busy.value=false;}
async function search(){
    cancel();const q=query.value.trim();if(q.length<2)return;
    const current=new AbortController();request=current;busy.value=true;error.value='';
    try{const response=await api.get('/api/search',{params:{q},signal:current.signal});if(current.signal.aborted)return;groups.value=response.data.groups;searched.value=true;}
    catch(e){if(!current.signal.aborted){groups.value=[];error.value=errorText(e);}}
    finally{if(request===current)busy.value=false;}
}
watch(query,()=>{cancel();groups.value=[];searched.value=false;error.value='';if(query.value.trim().length>=2){busy.value=true;timer=setTimeout(search,350);}});
onBeforeUnmount(cancel);
</script>
<template><section class="card p-3">
<form class="flex items-center gap-2" role="search" @submit.prevent="search"><Search :size="18" class="muted ml-2 shrink-0" aria-hidden="true"/><input v-model="query" type="search" :aria-label="t('search')" :placeholder="t('search')" autocomplete="off" maxlength="100" class="min-w-0 flex-1 !border-0 !bg-transparent !shadow-none" @keydown.esc="query=''"/><button v-if="query" type="button" class="btn" :aria-label="t('clear')" @click="query=''"><X :size="16"/></button></form>
<p v-if="query" class="muted px-2 pt-2 text-sm" role="status" aria-live="polite">{{busy?t('searching'):searched?(count?count+' '+t('results'):t('empty')):t('minimum')}}</p>
<p v-if="error" class="error mt-3" role="alert">{{error}}</p>
<div v-if="searched&&count" class="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-3"><section v-for="group in groups.filter(g=>g.items.length)" :key="group.key" class="min-w-0 rounded-lg border p-3"><h3 class="font-semibold">{{t(group.key)}}</h3><ul class="mt-2 space-y-1"><li v-for="item in group.items" :key="item.id"><Link :href="item.url" class="block rounded-lg p-2 focus-visible:ring-2 focus-visible:ring-blue-500"><span class="link block break-words font-medium">{{item.title}}</span><span class="muted block break-words text-xs">{{item.subtitle}}</span></Link></li></ul><p v-if="group.has_more" class="muted mt-2 text-xs">{{t('more')}}</p></section></div>
</section></template>
