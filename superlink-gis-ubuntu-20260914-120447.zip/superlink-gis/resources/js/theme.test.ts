import { describe, it, expect } from 'vitest';
import { validTheme } from './theme';
import { effectiveMapStyle, validMapStyle } from './Map/presentation';

describe('Theme and map preference behavior', () => {
  it('defaults unknown preferences to the system theme', () => {
    expect(validTheme(null)).toBe('system');
    expect(validTheme('invalid')).toBe('system');
    expect(validTheme('dark')).toBe('dark');
  });
  it('uses a night basemap with dark mode only when automatic is selected', () => {
    expect(effectiveMapStyle('auto', true)).toBe('night');
    expect(effectiveMapStyle('auto', false)).toBe('street');
    expect(effectiveMapStyle('street', true)).toBe('street');
    expect(effectiveMapStyle('focus', true)).toBe('focus');
    expect(validMapStyle('broken')).toBe('auto');
    expect(validMapStyle('satellite')).toBe('satellite');
    expect(validMapStyle('esri')).toBe('esri');
    expect(effectiveMapStyle('esri',true)).toBe('esri');
    expect(effectiveMapStyle('satellite',true)).toBe('satellite');
    expect(validMapStyle('outdoor')).toBe('outdoor');
    for (const style of ['contrast','sepia','blueprint'] as const) {
      expect(validMapStyle(style)).toBe(style);
      expect(effectiveMapStyle(style,true)).toBe(style);
      expect(effectiveMapStyle(style,false)).toBe(style);
    }
  });
});
