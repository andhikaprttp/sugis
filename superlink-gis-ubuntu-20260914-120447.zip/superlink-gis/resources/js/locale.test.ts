import {afterEach,expect,it,vi} from 'vitest';
import {language,setLanguage,t,validLanguage,initializeLanguage} from './locale';

afterEach(()=>{vi.unstubAllGlobals();setLanguage('id');});
it('switches existing translations immediately and preserves unknown labels',()=>{
  setLanguage('en');expect(t('customers')).toBe('Customers');expect(t('ODP')).toBe('ODP');
  setLanguage('id');expect(t('customers')).toBe('Pelanggan');expect(validLanguage('invalid')).toBe('id');
});
it('restores saved language and updates document language',()=>{
  const storage={getItem:vi.fn(()=> 'en'),setItem:vi.fn()};
  const document={documentElement:{lang:''}};
  vi.stubGlobal('localStorage',storage);vi.stubGlobal('document',document);vi.stubGlobal('window',{addEventListener:vi.fn()});
  initializeLanguage();expect(language.value).toBe('en');expect(document.documentElement.lang).toBe('en');
  setLanguage('id');expect(storage.setItem).toHaveBeenLastCalledWith('superlink.language','id');
});
it('still switches language when browser storage is unavailable',()=>{
  vi.stubGlobal('localStorage',{setItem:()=>{throw new Error('disabled');}});
  expect(()=>setLanguage('en')).not.toThrow();expect(t('devices')).toBe('Devices');
});
