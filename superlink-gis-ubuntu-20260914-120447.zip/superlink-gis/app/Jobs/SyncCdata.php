<?php

namespace App\Jobs;

use App\Services\Cdata\CdataSync;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class SyncCdata implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 850;

    public function handle(CdataSync $sync): void
    {
        $sync->run();
    }
}
