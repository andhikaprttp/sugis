<?php

namespace App\Jobs;

use App\Models\Customer;
use App\Models\User;
use App\Services\Cdata\CdataClient;
use App\Services\Cdata\CdataSync;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class RunDeviceOperation implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 300;

    public function __construct(public string $operationId) {}

    private function stage(string $stage): void
    {
        DB::table('device_operations')->where('id', $this->operationId)->update(['stage' => $stage, 'updated_at' => now()]);
    }

    public function handle(CdataClient $api): void
    {
        if (! DB::table('device_operations')->where('id', $this->operationId)->where('status', 'QUEUED')->update(['status' => 'RUNNING', 'updated_at' => now()])) {
            return;
        }
        $op = DB::table('device_operations')->find($this->operationId);
        $lock = null;
        $mutating = false;
        try {
            $p = json_decode(Crypt::decryptString($op->payload), true, 512, JSON_THROW_ON_ERROR);
            $actor = User::find($op->user_id);
            if (! $actor?->active || ! $actor->can('network.update') || ! $actor->can('customer.update')) {
                throw new RuntimeException('Hak akses operator sudah berubah.');
            }
            $customer = Customer::findOrFail($op->customer_id);
            if (CdataSync::sn($customer->ont_serial_number) !== $p['sn']) {
                throw new RuntimeException('SN pelanggan telah berubah.');
            }
            $lock = Cache::lock('cdata-olt-operation:'.$p['olt'], 360);
            if (! $lock->get()) {
                throw new RuntimeException('OLT sedang menjalankan operasi lain.');
            }
            $args = ['PonId' => $p['pon'], 'OnuId' => $p['onu']];
            $this->stage('VERIFY_IDENTITY');
            if ($op->action === 'ACTIVATE') {
                $found = false;
                for ($page = 1; $page <= 200; $page++) {
                    $d = $api->module('onu_autofind_info', $p['olt'], ['PageNumber' => $page, 'PageSize' => 100, 'PonId' => $p['pon']]);
                    if (! is_array($d['AutofindInfo'] ?? null)) {
                        throw new RuntimeException('Autodiscovery CMS tidak valid.');
                    }
                    foreach ($d['AutofindInfo'] as $row) {
                        if (CdataSync::sn($row['SnVal'] ?? null) === $p['sn'] && ($row['PonId'] ?? null) === $p['pon']) {
                            $found = true;
                        }
                    }
                    if ($found || count($d['AutofindInfo']) < 100) {
                        break;
                    }
                }
                if (! $found) {
                    throw new RuntimeException('SN tidak lagi ditemukan pada PON pilihan.');
                }
                $existing = $api->module('onu_list_get', $p['olt'], [...$args, 'PageNumber' => 1, 'PageSize' => 100]);
                if (! isset($existing['list']) || ! is_array($existing['list']) || count($existing['list'])) {
                    throw new RuntimeException('ONU ID belum terbukti kosong. Pilih ID kosong.');
                }
                $t = $p['template'];
                $this->stage('REGISTER_ONU');
                $mutating = true;
                $api->module('onu_manual_add', $p['olt'], [...$args, 'OnuType' => 3, 'AuthMode' => 0, 'SnVal' => $p['sn'], 'Type' => 1, 'LineProfileName' => $t['line_profile'], 'SrvProfileName' => $t['service_profile'], 'WanProfileName' => $t['wan_profile'], 'TR069ProfileName' => $t['tr069_profile']], true);
            }
            $detail = $api->module('onu_info_detail', $p['olt'], $args);
            if (CdataSync::sn($detail['PonSn'] ?? null) !== $p['sn']) {
                throw new RuntimeException('SN perangkat tidak cocok dengan pelanggan.');
            }
            if ($op->action === 'ACTIVATE') {
                $this->stage('CONFIGURE_WAN');
                $data = $api->module('onu_wan_get', $p['olt'], $args);
                $wans = $data['WanInfo'] ?? [];
                if (isset($wans['Index'])) {
                    $wans = [$wans];
                }
                $matches = array_values(array_filter($wans, fn ($w) => (int) ($w['vlanId'] ?? -1) === (int) $p['template']['vlan'] && (int) ($w['service_type'] ?? 0) === 2));
                if (count($matches) !== 1) {
                    throw new RuntimeException('ONT terdaftar; WAN PPPoE dengan VLAN template belum tersedia atau ambigu. Periksa profil melalui CMS sebelum melanjutkan.');
                }
                $wan = $matches[0];
                foreach (['Index', 'WanName', 'vlanId', 'enable_vlan', '802_1_mark', 'service_type', 'connection_type', 'ip_protocol', 'enable_igmp_mld_proxy', 'MTU', 'ipv4', 'port_binding'] as $field) {
                    if (! array_key_exists($field, $wan)) {
                        throw new RuntimeException('WAN profil belum lengkap. Periksa konfigurasi CMS.');
                    }
                }
                $binding = ['lan' => [], 'ssid' => []];
                foreach (explode(',', $p['template']['binding']) as $port) {
                    if (preg_match('/^LAN([1-4])$/', trim($port), $m)) {
                        $binding['lan'][] = (int) $m[1] - 1;
                    } elseif (preg_match('/^SSID([4-9]|1[0-2])$/', trim($port), $m)) {
                        $binding['ssid'][] = (int) $m[1];
                    } else {
                        throw new RuntimeException('Binding template tidak valid.');
                    }
                }
                $allowed = ['Index', 'WanName', 'vlanId', '802_1_mark', 'service_type', 'connection_type', 'ip_protocol', 'enable_igmp_mld_proxy', 'multicast_vlan_id', 'MTU', 'ipv4', 'ipv6'];
                $body = [...array_intersect_key($wan, array_flip($allowed)), ...$args, 'Operate' => 2, 'enable_vlan' => true, 'port_binding' => $binding, 'ppp' => ['username' => $p['username'], 'password' => $p['password']]];
                $api->module('onu_wan_set', $p['olt'], $body, true);
                $this->stage('VERIFY_WAN');
                $verify = $api->module('onu_wan_get', $p['olt'], $args)['WanInfo'] ?? [];
                if (isset($verify['Index'])) {
                    $verify = [$verify];
                }
                $ok = false;
                foreach ($verify as $w) {
                    if ((int) ($w['Index'] ?? -1) === (int) $wan['Index'] && (int) ($w['vlanId'] ?? -1) === (int) $p['template']['vlan'] && ($w['ppp']['username'] ?? null) === $p['username']) {
                        $ok = true;
                    }
                }
                if (! $ok) {
                    throw new RuntimeException('WAN belum terverifikasi setelah perubahan. Periksa perangkat.');
                }
                $customer->update(['pppoe_username' => $p['username']]);
                $message = 'Registrasi dan username/VLAN WAN terverifikasi. Sesi PPPoE/password belum dapat dibuktikan dari readback CMS.';
            } else {
                $deactive = $op->action === 'SUSPEND' ? 1 : 0;
                $this->stage('SET_ADMIN_STATE');
                $mutating = true;
                $result = $api->module('onu_active_batch', $p['olt'], ['OnuList' => [[...$args, 'Deactive' => $deactive]]], true);
                if ((int) ($result['SuccessNum'] ?? 0) !== 1) {
                    throw new RuntimeException('Jumlah keberhasilan operasi tidak sesuai.');
                }
                $this->stage('VERIFY_ADMIN_STATE');
                $detail = $api->module('onu_info_detail', $p['olt'], $args);
                if (CdataSync::sn($detail['PonSn'] ?? null) !== $p['sn'] || ! array_key_exists('ControlFlag', $detail) || (int) $detail['ControlFlag'] !== 1 - $deactive) {
                    throw new RuntimeException('Status administratif belum terverifikasi.');
                }
                DB::table('ont_snapshots')->where('sn', $p['sn'])->update(['admin_state' => $deactive ? 'DEACTIVATED' : 'ACTIVE']);
                $message = 'Status administratif ONT terverifikasi. Status langganan tidak diubah.';
            }
            DB::table('device_operations')->where('id', $op->id)->update(['status' => 'SUCCEEDED', 'stage' => 'DONE', 'message' => $message, 'payload' => null, 'updated_at' => now()]);
        } catch (\Throwable $e) {
            DB::table('device_operations')->where('id', $op->id)->update(['status' => $mutating ? 'UNKNOWN' : 'FAILED', 'message' => $e instanceof RuntimeException && ! ($e instanceof QueryException) ? mb_substr($e->getMessage(), 0, 250) : 'Operasi tidak selesai. Periksa keadaan perangkat melalui CMS.', 'payload' => null, 'updated_at' => now()]);
        } finally {
            $lock?->release();
        }
    }

    public function failed(?\Throwable $e): void
    {
        DB::table('device_operations')->where('id', $this->operationId)->whereIn('status', ['QUEUED', 'RUNNING'])->update(['status' => 'UNKNOWN', 'payload' => null, 'message' => 'Worker terhenti. Periksa perangkat sebelum mencoba operasi baru.', 'updated_at' => now()]);
    }
}
