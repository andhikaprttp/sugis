<?php

namespace App\Jobs;

use App\Models\ImportJob;
use App\Services\Gis\GeometryService;
use App\Services\Gis\KmzImportService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class ProcessKmzImport implements ShouldQueue
{
    use Queueable;

    public int $timeout = 900;

    public int $tries = 1;

    public function __construct(public string $jobId) {}

    public function handle(KmzImportService $parser): void
    {
        $job = ImportJob::findOrFail($this->jobId);
        if (! ImportJob::whereKey($this->jobId)->where('status', 'UPLOADED')->update(['status' => 'PROCESSING'])) {
            return;
        }
        try {
            $parsed = $parser->parse(Storage::path($job->path), $job->filename);
            DB::transaction(function () use ($job, $parsed) {
                $job->rows()->delete();
                $batch = [];
                $now = now();
                foreach ($parsed['objects'] as $i => $data) {
                    $errors = [];
                    try {
                        app(GeometryService::class)->validate($data['geometry']);
                    } catch (ValidationException $e) {
                        $errors = $e->errors();
                    }
                    $batch[] = ['id' => (string) Str::uuid(), 'job_id' => $job->id, 'row_number' => $i + 1, 'data' => json_encode($data, JSON_THROW_ON_ERROR), 'errors' => json_encode($errors, JSON_THROW_ON_ERROR), 'validation' => $errors ? 'INVALID' : 'VALID', 'created_at' => $now, 'updated_at' => $now];
                    if (count($batch) === 500) {
                        DB::table('import_objects')->insert($batch);
                        $batch = [];
                    }
                }
                if ($batch) {
                    DB::table('import_objects')->insert($batch);
                }
                $job->update(['status' => 'READY', 'counts' => $parsed['counts'], 'total_rows' => count($parsed['objects'])]);
            });
        } catch (\Throwable $e) {
            $job->update(['status' => 'FAILED', 'error' => mb_substr($e->getMessage(), 0, 2000)]);
            throw $e;
        }
    }

    public function failed(?\Throwable $e): void
    {
        ImportJob::whereKey($this->jobId)->where('status', '!=', 'FAILED')->update(['status' => 'FAILED', 'error' => 'Pemrosesan terhenti. Periksa worker lalu upload ulang.']);
    }
}
