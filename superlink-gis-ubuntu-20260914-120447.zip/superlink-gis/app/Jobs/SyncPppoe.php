<?php

namespace App\Jobs;

use App\Services\Monitoring\PppoeMonitor;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class SyncPppoe implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 90;

    public function handle(PppoeMonitor $monitor): void
    {
        $monitor->sync();
    }
}
