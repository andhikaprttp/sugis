<?php

namespace App\Jobs;

use App\Models\ExportJob;
use App\Models\User;
use App\Services\AuditService;
use App\Services\Customer\SpreadsheetService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class GenerateCustomerExport implements ShouldQueue
{
    use Queueable;

    public int $timeout = 900;

    public int $tries = 1;

    public function __construct(public string $jobId) {}

    public function handle(SpreadsheetService $service): void
    {
        $j = ExportJob::findOrFail($this->jobId);
        $j->update(['status' => 'PROCESSING']);
        try {
            $book = $service->export($j->options, User::findOrFail($j->uploaded_by)->email);
            $writer = new Xlsx($book);
            $writer->save(Storage::path($j->path));
            $book->disconnectWorksheets();
            $j->update(['status' => 'COMPLETED']);
            AuditService::record('Customer Export', 'ExportJob', $j->id, null, $j->options, 'SYSTEM', $j->uploaded_by);
        } catch (\Throwable $e) {
            $j->update(['status' => 'FAILED', 'error' => 'Export failed; inspect worker logs.']);
            throw $e;
        }
    }
}
