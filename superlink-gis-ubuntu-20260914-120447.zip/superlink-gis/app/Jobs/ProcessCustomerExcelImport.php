<?php

namespace App\Jobs;

use App\Models\CustomerImportJob;
use App\Services\Customer\SpreadsheetService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class ProcessCustomerExcelImport implements ShouldQueue
{
    use Queueable;

    public int $timeout = 900;

    public int $tries = 1;

    public function __construct(public string $jobId) {}

    public function handle(SpreadsheetService $service): void
    {
        $j = CustomerImportJob::findOrFail($this->jobId);
        if ($j->status !== 'UPLOADED') {
            return;
        }$j->update(['status' => 'VALIDATING']);
        try {
            $service->parse($j);
        } catch (\Throwable $e) {
            $j->update(['status' => 'FAILED', 'error' => mb_substr($e->getMessage(), 0, 2000)]);
            throw $e;
        }
    }

    public function failed(?\Throwable $e): void
    {
        CustomerImportJob::whereKey($this->jobId)->where('status', '!=', 'FAILED')->update(['status' => 'FAILED', 'error' => 'Pemrosesan terhenti. Periksa worker lalu upload ulang.']);
    }
}
