<?php

namespace App\Jobs;

use App\Models\BlastDelivery;
use App\Models\User;
use App\Services\Blast\MessageBuilder;
use App\Services\Blast\WhatsAppSender;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\DB;

class SendBlastDelivery implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 45;

    public function __construct(public string $deliveryId) {}

    public function handle(WhatsAppSender $sender): void
    {
        $delivery = DB::transaction(function () use ($sender) {
            $d = BlastDelivery::whereKey($this->deliveryId)->lockForUpdate()->first();
            if (! $d || $d->status !== 'QUEUED') {
                return null;
            }
            $r = $d->recipient;
            $campaign = $r->campaign;
            $actor = User::find($campaign->created_by);
            if (! $r->selected || $r->paid || (! $d->manual && (! $campaign->enabled || ! in_array($d->slot, $campaign->occurrences, true))) || ! $actor?->active || ! $actor->can('blast.send')) {
                $d->update(['status' => 'CANCELLED', 'error' => 'Penerima dihentikan, lunas, jadwal dijeda, atau akses pengirim dicabut.']);

                return null;
            }
            if ($d->scheduled_at->lt(now()->subMinutes(config('blast.late_minutes')))) {
                $d->update(['status' => 'EXPIRED', 'error' => 'Jadwal terlewat lebih dari batas toleransi.']);

                return null;
            }
            if (! $sender->configured()) {
                $d->update(['status' => 'BLOCKED', 'error' => 'API pengirim tidak aktif.']);

                return null;
            }
            $d->update(['status' => 'SENDING', 'phone' => $r->phone, 'message' => app(MessageBuilder::class)->render($campaign->template, $r)]);

            return $d;
        });
        if (! $delivery) {
            return;
        }
        $result = $sender->send($delivery->phone, $delivery->message);
        BlastDelivery::whereKey($delivery->id)->where('status', 'SENDING')->update([...$result, 'updated_at' => now()]);
    }
}
