<?php

namespace App\Http\Resources;

use App\Models\Odc;
use App\Models\Odp;
use App\Services\Network\NetworkService;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class GisObjectResource extends JsonResource
{
    public static function collection($resource)
    {
        $items = $resource instanceof Paginator ? $resource->getCollection() : collect($resource);
        $byType = $items->groupBy('object_type');
        foreach (NetworkService::TABLES as $type => $table) {
            $group = $byType->get($type, collect());
            if ($group->isEmpty()) {
                continue;
            }
            $ids = $group->pluck('id');
            $networks = match ($type) {
                'ODP' => Odp::with('odc.object', 'odc.pop.object')->whereIn('id', $ids)->get()->keyBy('id'),
                'ODC' => Odc::with('pop.object', 'odps.object')->whereIn('id', $ids)->get()->keyBy('id'),
                default => DB::table($table)->whereIn('id', $ids)->get()->keyBy('id'),
            };
            $counts = $type === 'ODP'
                ? DB::table('odp_ports')->whereIn('odp_id', $ids)->selectRaw('odp_id, status, count(*) as total')->groupBy('odp_id', 'status')->get()->groupBy('odp_id')
                : collect();
            foreach ($group as $object) {
                $network = $networks->get($object->id);
                $object->setRelation('networkDetails', $network);
                if ($type === 'ODP') {
                    $object->setRelation('portAvailability', $network?->availability($counts->get($object->id, collect())->pluck('total', 'status')->all()));
                }
            }
        }

        return parent::collection($resource);
    }

    public function toArray($request): array
    {
        $data = ['id' => $this->id, 'name' => $this->name, 'code' => $this->code, 'object_type' => $this->object_type, 'geometry' => $this->geojson, 'status' => $this->status, 'description' => $this->description, 'notes' => $this->notes, 'source' => $this->source, 'source_filename' => $this->source_filename, 'original_name' => $this->original_name, 'area_id' => $this->area_id, 'pop_id' => $this->pop_id, 'updated_at' => $this->updated_at];
        $data['service_area_id'] = $this->service_area_id;
        if ($this->resource->relationLoaded('networkDetails')) {
            $data['network'] = $this->resource->getRelation('networkDetails');
            if ($this->object_type === 'ODP') {
                $data['availability'] = $this->resource->getRelation('portAvailability');
            }
        } elseif ($this->object_type === 'ODP') {
            $o = Odp::with('odc.object', 'odc.pop.object')->find($this->id);
            $data['network'] = $o;
            $data['availability'] = $o?->availability();
        } elseif ($this->object_type === 'ODC') {
            $data['network'] = Odc::with('pop.object', 'odps.object')->find($this->id);
        } elseif (isset(NetworkService::TABLES[$this->object_type])) {
            $data['network'] = DB::table(NetworkService::TABLES[$this->object_type])->where('id', $this->id)->first();
        }

        return $data;
    }
}
