<?php

namespace App\Http\Controllers;

use App\Services\OntSerialImport;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class OntImportController
{
    public function index()
    {
        return Inertia::render('Devices/ImportSerials');
    }

    public function preview(Request $request, OntSerialImport $service)
    {
        $v = $request->validate(['serials' => 'required|string|max:150000']);

        return response()->json($service->preview($v['serials']));
    }

    public function store(Request $request, OntSerialImport $service)
    {
        $v = $request->validate(['serials' => 'required|string|max:150000', 'location' => 'required|string|max:255', 'vendor' => 'nullable|string|max:255', 'model' => 'nullable|string|max:255']);
        try {
            $result = $service->import($v);
        } catch (UniqueConstraintViolationException $e) {
            throw ValidationException::withMessages(['serials' => 'Stok berubah saat impor. Periksa ulang daftar lalu coba lagi.']);
        }

        return redirect('/devices?type=ONT&status=IN_STOCK')->with('success', count($result['ready']).' ONT masuk stok; '.count($result['existing']).' serial sudah terdaftar; '.$result['duplicates'].' duplikat teks dilewati.');
    }
}
