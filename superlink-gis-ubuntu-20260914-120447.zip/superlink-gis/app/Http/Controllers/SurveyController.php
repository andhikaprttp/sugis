<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Survey;
use App\Services\Survey\SurveyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;

class SurveyController
{
    private function editable(Survey $s): void
    {
        abort_unless(auth()->user()->hasAnyRole(['ADMIN', 'NOC']) || $s->surveyor_id === auth()->id(), 403);
    }

    public function index()
    {
        return Inertia::render('Survey/Index', ['surveys' => Survey::with('customer', 'odp.object', 'surveyor:id,name')->when(auth()->user()->hasRole('TECHNICIAN'), fn ($q) => $q->where('assigned_to', auth()->id()))->latest()->paginate(30)]);
    }

    public function create()
    {
        return Inertia::render('Survey/Create', ['customers' => Customer::select('id', 'name', 'customer_id', 'gis_object_id')->orderBy('name')->limit(2000)->get()]);
    }

    public function store(Request $r, SurveyService $s)
    {
        $v = $r->validate(['customer_id' => 'required|uuid|exists:customers,id', 'notes' => 'nullable|string|max:10000']);
        $survey = $s->create($v);

        return redirect('/surveys/'.$survey->id);
    }

    public function show(Survey $survey)
    {
        return Inertia::render('Survey/Show', ['survey' => $survey->load('customer.object', 'odp.object', 'surveyor:id,name', 'reservation')]);
    }

    public function nearest(Request $r, SurveyService $s)
    {
        $v = $r->validate(['longitude' => 'required|numeric|between:-180,180', 'latitude' => 'required|numeric|between:-90,90']);

        return response()->json(['data' => $s->nearest($v['longitude'], $v['latitude'])]);
    }

    public function route(Request $r, Survey $survey, SurveyService $s)
    {
        $this->editable($survey);
        $v = $r->validate(['nodes' => 'required|array|min:2|max:200', 'nodes.*' => 'uuid']);

        return response()->json(['data' => $s->route($survey, $v['nodes'])]);
    }

    public function transition(Request $r, Survey $survey, SurveyService $s)
    {
        $v = $r->validate(['status' => 'required|string', 'assigned_to' => 'nullable|integer|exists:users,id']);
        if ($v['status'] === 'APPROVED') {
            Gate::authorize('survey.approve');
        } elseif (in_array($v['status'], ['INSTALLATION', 'INSTALLED'])) {
            Gate::authorize('installation.update');
            if (auth()->user()->hasRole('TECHNICIAN')) {
                abort_unless($survey->assigned_to === auth()->id(), 403);
            }
        } else {
            Gate::authorize('survey.update');
            $this->editable($survey);
        }if (! empty($v['assigned_to'])) {
            Gate::authorize('survey.approve');
        }$s->transition($survey, $v['status'], $v['assigned_to'] ?? null);

        return back()->with('success','Status survey diperbarui');
    }
}
