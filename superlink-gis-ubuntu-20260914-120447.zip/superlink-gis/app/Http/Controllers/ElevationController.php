<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;

class ElevationController
{
    public function __invoke(Request $request)
    {
        $data = $request->validate([
            'points' => 'required|array|min:2|max:100',
            'points.*' => 'required|array|size:2',
            'points.*.0' => 'required|numeric|between:-60,60',
            'points.*.1' => 'required|numeric|between:-180,180',
        ]);
        $locations = collect($data['points'])->map(fn ($p) => sprintf('%.6F,%.6F', $p[0], $p[1]))->implode('|');
        $key = 'elevation:srtm30m:'.hash('sha256', $locations);
        if (($cached = Cache::get($key)) !== null) {
            return response()->json(['elevations' => $cached]);
        }
        // Shared budget across users and workers for the public service.
        $lock = Cache::lock('elevation:request-lock', 25);
        abort_unless($lock->get(), 429, 'Elevasi sedang diminta pengguna lain. Coba lagi sebentar.');
        try {
            abort_if(RateLimiter::tooManyAttempts('elevation:second', 1) || RateLimiter::tooManyAttempts('elevation:day', 950), 429, 'Batas layanan elevasi tercapai. Coba lagi nanti.');
            RateLimiter::hit('elevation:second', 2);
            RateLimiter::hit('elevation:day', 86400);
            try {
                $response = Http::acceptJson()->connectTimeout(5)->timeout(20)->withOptions(['allow_redirects' => false])->get('https://api.opentopodata.org/v1/srtm30m', ['locations' => $locations]);
            } catch (\Throwable $e) {
                abort(503, 'Layanan elevasi tidak dapat dijangkau. Jarak tetap dapat diukur.');
            }
            $rows = $response->json('results');
            abort_unless($response->successful() && $response->json('status') === 'OK' && is_array($rows) && array_is_list($rows) && count($rows) === count($data['points']), 503, 'Layanan elevasi tidak tersedia atau respons tidak lengkap.');
            $elevations = [];
            foreach ($rows as $row) {
                abort_unless(is_array($row) && array_key_exists('elevation', $row) && ($row['elevation'] === null || is_numeric($row['elevation'])), 503, 'Respons elevasi tidak valid.');
                $elevations[] = $row['elevation'] === null ? null : (float) $row['elevation'];
            }
            Cache::put($key, $elevations, now()->addDay());

            return response()->json(['elevations' => $elevations]);
        } finally {
            $lock->release();
        }
    }
}
