<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Device;
use App\Models\GisObject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GlobalSearchController
{
    public function __invoke(Request $request)
    {
        $input = $request->validate(['q' => 'required|string|min:2|max:100']);
        $term = trim($input['q']);
        abort_if(mb_strlen($term) < 2, 422);
        // Bind the input and treat LIKE wildcards as literal search text.
        $pattern = '%'.str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $term).'%';
        $groups = [];
        $allowed = fn (array $permissions) => collect($permissions)->every(fn ($p) => $request->user()->can($p));
        $match = function ($query, array $columns) use ($pattern) {
            return $query->where(function ($q) use ($columns, $pattern) {
                foreach ($columns as $column) {
                    $q->orWhere($column, 'ilike', $pattern);
                }
            });
        };
        $add = function (string $key, string $label, $query, callable $transform) use (&$groups) {
            $rows = $query->limit(6)->get();
            $groups[] = ['key' => $key, 'label' => $label, 'has_more' => $rows->count() > 5, 'items' => $rows->take(5)->map($transform)->values()];
        };
        if ($allowed(['customer.view'])) {
            $add('customers', 'Pelanggan', $match(Customer::select('id', 'name', 'customer_id', 'address'), ['name', 'customer_id', 'phone', 'address', 'ont_serial_number', 'pppoe_username'])->orderBy('name')->orderBy('id'),
                fn ($c) => ['id' => $c->id, 'title' => $c->name, 'subtitle' => $c->customer_id.' · '.$c->address, 'url' => '/customers/'.$c->id]);
        }
        foreach (['ODP' => ['odp.view'], 'ODC' => ['odc.view', 'network.view']] as $type => $permissions) {
            if ($allowed($permissions)) {
                $add(strtolower($type), $type, $match(GisObject::select('id', 'name', 'code')->where('object_type', $type), ['name', 'code'])->orderBy('name')->orderBy('id'),
                    fn ($g) => ['id' => $g->id, 'title' => $g->code ?: $g->name, 'subtitle' => $g->name, 'url' => $type === 'ODP' ? '/network/odps/'.$g->id.'/ports' : '/map?focus='.$g->id]);
            }
        }
        if ($allowed(['operations.view', 'network.view', 'customer.view'])) {
            $add('olts', 'OLT', $match(DB::table('provisioning_olts')->select('id', 'name', 'external_id', 'host'), ['name', 'external_id', 'host'])->orderBy('name')->orderBy('id'),
                fn ($o) => ['id' => $o->id, 'title' => $o->name, 'subtitle' => $o->external_id.' · '.$o->host, 'url' => '/operations/olts?olt_id='.$o->id]);
        }
        if ($allowed(['network.view', 'customer.view'])) {
            $add('devices', 'Perangkat', $match(Device::select('id', 'asset_tag', 'serial_number', 'type', 'model', 'status'), ['asset_tag', 'serial_number', 'vendor', 'model'])->orderBy('asset_tag')->orderBy('id'),
                fn ($d) => ['id' => $d->id, 'title' => $d->asset_tag, 'subtitle' => $d->type.' · '.$d->serial_number.' · '.$d->status, 'url' => '/devices?device_id='.$d->id]);
        }

        return response()->json(['groups' => $groups]);
    }
}
