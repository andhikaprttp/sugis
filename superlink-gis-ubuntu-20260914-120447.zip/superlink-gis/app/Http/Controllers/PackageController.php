<?php

namespace App\Http\Controllers;

use App\Models\ServicePackage;
use App\Services\AuditService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class PackageController
{
    public function index(Request $request)
    {
        $v = $request->validate(['search' => 'nullable|string|max:100']);
        $term = $v['search'] ?? '';

        return Inertia::render('Packages/Index', ['packages' => ServicePackage::when($term !== '', fn ($q) => $q->where('name', 'ilike', '%'.$term.'%'))->orderBy('name')->paginate(30)->withQueryString()]);
    }

    public function options(Request $request)
    {
        $v = $request->validate(['search' => 'nullable|string|max:100']);
        $term = $v['search'] ?? '';

        return ServicePackage::where('active', true)->when($term !== '', fn ($q) => $q->where('name', 'ilike', '%'.$term.'%'))->orderBy('name')->limit(30)->get(['id', 'name', 'speed_mbps', 'price']);
    }

    public function store(Request $request)
    {
        return $this->save($request, new ServicePackage);
    }

    public function update(Request $request, ServicePackage $package)
    {
        return $this->save($request, $package);
    }

    private function save(Request $request, ServicePackage $package)
    {
        $v = $request->validate(['name' => ['required', 'string', 'max:255', Rule::unique('service_packages')->ignore($package->id)], 'speed_mbps' => 'required|integer|between:1,100000', 'price' => 'required|numeric|decimal:0,2|between:0,9999999999.99', 'active' => 'required|boolean']);
        DB::transaction(function () use ($package, $v) {
            if ($package->exists) {
                $package = ServicePackage::whereKey($package->id)->lockForUpdate()->firstOrFail();
            }
            $old = $package->exists ? $package->toArray() : null;
            $package->fill($v)->save();
            AuditService::record($old ? 'Update' : 'Create', 'ServicePackage', $package->id, $old, $package->toArray());
        });

        return back()->with('success', 'Paket disimpan. Harga pelanggan yang sudah terpasang tidak berubah otomatis.');
    }
}
