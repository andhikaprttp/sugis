<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Models\Setting;
use App\Models\Survey;
use App\Models\User;
use App\Services\AuditService;
use App\Services\Monitoring\PppoeMonitor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class AdminController
{
    public function dashboard()
    {
        $pppoe = app(PppoeMonitor::class)->summary();
        if (! auth()->user()->can('network.view')) {
            return Inertia::render('Dashboard/CustomerService', ['pppoe' => $pppoe, 'total' => Customer::count(), 'statuses' => Customer::selectRaw('status,count(*) as total')->groupBy('status')->pluck('total', 'status')]);
        }

        return Inertia::render('Dashboard/Index', ['poleCount' => app(\App\Services\Network\InfrastructureSummary::class)->poleCount(), 'pppoe' => $pppoe, 'customerStatuses' => Customer::selectRaw('status,count(*) as total')->groupBy('status')->pluck('total', 'status'), 'objects' => GisObject::selectRaw('object_type,count(*) as total')->groupBy('object_type')->pluck('total', 'object_type'), 'customers' => Customer::count(), 'ports' => OdpPort::selectRaw('status,count(*) as total')->groupBy('status')->pluck('total', 'status'), 'surveys' => Survey::selectRaw('status,count(*) as total')->groupBy('status')->pluck('total', 'status'), 'full' => DB::select("SELECT g.id,g.code,o.capacity,count(*) FILTER(WHERE p.status='AVAILABLE') as available FROM odps o JOIN gis_objects g ON g.id=o.id JOIN odp_ports p ON p.odp_id=o.id WHERE g.deleted_at IS NULL GROUP BY g.id,g.code,o.capacity HAVING count(*) FILTER(WHERE p.status='AVAILABLE')<=2 ORDER BY available LIMIT 12")]);
    }

    public function audit()
    {
        return Inertia::render('Audit/Index', ['logs' => DB::table('audit_logs')->leftJoin('users', 'users.id', '=', 'audit_logs.user_id')->select('audit_logs.*', 'users.name as user_name')->orderByDesc('audit_logs.id')->paginate(50)]);
    }

    public function settings()
    {
        return Inertia::render('Settings/Index', ['settings' => Setting::findOrFail(1), 'users' => User::with('roles')->select('id', 'name', 'email', 'active')->get()]);
    }

    public function saveSettings(Request $r)
    {
        $v = $r->validate(['search_radius_m' => 'required|numeric|between:1,50000', 'cable_allowance_percent' => 'required|numeric|between:0,100']);
        DB::transaction(function () use ($v) {
            $s = Setting::findOrFail(1);
            $old = $s->toArray();
            $s->update($v);
            AuditService::record('Update', 'Setting', '1', $old, $s->toArray());
        });

        return back()->with('success', 'Settings disimpan');
    }

    public function user(Request $r)
    {
        abort_unless(auth()->user()->hasRole('ADMIN'), 403);
        $v = $r->validate(['name' => 'required|string|max:255', 'email' => 'required|email|unique:users', 'password' => 'required|string|min:12', 'role' => 'required|in:ADMIN,NOC,SURVEYOR,TECHNICIAN,VIEWER,CUSTOMER_SERVICE']);
        DB::transaction(function () use ($v) {
            $u = User::create(array_intersect_key($v, array_flip(['name', 'email', 'password'])));
            $u->assignRole($v['role']);
            AuditService::record('Create', 'User', (string) $u->id, null, $u->only('name', 'email'));
        });

        return back()->with('success', 'User dibuat');
    }

    public function changeRole(Request $r, User $user)
    {
        abort_unless(auth()->user()->hasRole('ADMIN'), 403);
        $v = $r->validate(['role' => 'required|in:ADMIN,NOC,SURVEYOR,TECHNICIAN,VIEWER,CUSTOMER_SERVICE']);
        abort_if($user->id === auth()->id(), 422, 'Role akun sendiri tidak dapat diubah di sini.');
        DB::transaction(function () use ($user, $v) {
            $old = $user->getRoleNames()->all();
            $user->syncRoles([$v['role']]);
            $user->syncPermissions([]);
            AuditService::record('Change role', 'User', (string) $user->id, ['roles' => $old], ['roles' => [$v['role']]]);
        });

        return back()->with('success', 'Role pengguna diperbarui.');
    }
}
