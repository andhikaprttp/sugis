<?php

namespace App\Http\Controllers;

use App\Services\AuditService;
use App\Services\Gis\RoadRoutingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RecommendationController
{
    public function index(Request $request, RoadRoutingService $routing)
    {
        $v = $request->validate(['lat' => 'required|numeric|between:-90,90', 'lng' => 'required|numeric|between:-180,180', 'radius' => 'required|numeric|between:50,50000', 'type' => 'required|in:ODP,ODC', 'free' => 'required|boolean']);
        $q = DB::table('gis_objects as g')->whereNull('g.deleted_at')->where('g.status', 'ACTIVE')->where('g.object_type', $v['type'])
            ->whereRaw("GeometryType(g.geometry)='POINT'")
            ->whereRaw('ST_DWithin(g.geometry::geography,ST_SetSRID(ST_MakePoint(?,?),4326)::geography,?)', [$v['lng'], $v['lat'], $v['radius']])
            ->select('g.id', 'g.name', 'g.code', 'g.object_type')
            ->selectRaw('ST_Y(g.geometry) as lat,ST_X(g.geometry) as lng,ST_Distance(g.geometry::geography,ST_SetSRID(ST_MakePoint(?,?),4326)::geography) as distance', [$v['lng'], $v['lat']]);
        if ($v['type'] === 'ODP') {
            $q->join('odps as n', 'n.id', '=', 'g.id')->selectRaw("n.capacity,(SELECT COUNT(*) FROM odp_ports p WHERE p.odp_id=g.id AND p.status='AVAILABLE' AND p.customer_id IS NULL AND p.reserved_for IS NULL) as available,NULL as checked_at");
        } else {
            $q->join('odcs as n', 'n.id', '=', 'g.id')->leftJoin('odc_port_observations as o', 'o.id', '=', 'g.id')->addSelect('n.capacity', 'o.checked_at')->selectRaw('CASE WHEN o.capacity=n.capacity AND o.checked_at>=? THEN o.available ELSE NULL END as available', [now()->subDay()]);
        }
        // Filter eligibility before limiting, so a full nearest cabinet cannot hide alternatives.
        $results = DB::query()->fromSub($q, 'c')->when($v['free'], fn ($q) => $q->where('available', '>', 0))->orderBy('distance')->orderBy('id')->limit(5)->get();
        try {
            $distances = $routing->distances([(float) $v['lat'], (float) $v['lng']], $results->map(fn ($r) => [(float) $r->lat, (float) $r->lng])->all());
            foreach ($results as $index => $result) {
                $result->road_distance = $distances[$index] ?? null;
            }
        } catch (\RuntimeException $e) {
            foreach ($results as $result) {
                $result->road_distance = null;
            }
        }

        return response()->json(['data' => $results, 'checked_at' => now()->toIso8601String()]);
    }

    public function route(Request $request, RoadRoutingService $routing)
    {
        $v = $request->validate([
            'start' => 'required|array|size:2', 'start.0' => 'required|numeric|between:-90,90', 'start.1' => 'required|numeric|between:-180,180',
            'end' => 'required|array|size:2', 'end.0' => 'required|numeric|between:-90,90', 'end.1' => 'required|numeric|between:-180,180',
        ]);
        try {
            return response()->json(['data' => $routing->route($v['start'], $v['end'])]);
        } catch (\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 503);
        }
    }

    public function ports(Request $request, string $id)
    {
        $v = $request->validate(['available' => 'required|integer|min:0']);
        DB::transaction(function () use ($v, $id, $request) {
            $odc = DB::table('odcs')->where('id', $id)->lockForUpdate()->first();
            abort_unless($odc && DB::table('gis_objects')->where('id', $id)->whereNull('deleted_at')->exists(), 404);
            abort_if($v['available'] > $odc->capacity, 422, 'Port kosong tidak boleh melebihi kapasitas ODC.');
            $old = (array) DB::table('odc_port_observations')->where('id', $id)->first();
            $new = ['capacity' => $odc->capacity, 'available' => $v['available'], 'checked_by' => $request->user()->id, 'checked_at' => now()->toIso8601String()];
            DB::table('odc_port_observations')->updateOrInsert(['id' => $id], $new);
            AuditService::record('ODC Port Observation', 'Odc', $id, $old, $new);
        });

        return response()->json(['message' => 'Hasil pemeriksaan port ODC disimpan.']);
    }
}
