<?php

namespace App\Http\Controllers;

use App\Http\Resources\GisObjectResource;
use App\Models\GisObject;
use App\Models\Odp;
use App\Models\OdpPort;
use App\Models\Survey;
use App\Services\Network\NetworkService;
use App\Services\Network\PortService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;

class NetworkController
{
    private function permission(string $type, string $action): void
    {
        Gate::authorize(strtolower(match ($type) {
            'ODP' => 'odp','ODC' => 'odc','POLE' => 'pole',default => 'network'
        }).'.'.$action);
    }

    public function index(Request $r, string $kind)
    {
        $r->validate(['search' => 'nullable|string|max:255']);
        $type = ['pops' => 'POP', 'odcs' => 'ODC', 'odps' => 'ODP', 'poles' => 'POLE', 'closures' => 'CLOSURE', 'fiber-routes' => 'FIBER_ROUTE'][$kind] ?? abort(404);
        $this->permission($type, 'view');

        return Inertia::render('Network/Index', ['kind' => $kind, 'type' => $type, 'objects' => GisObjectResource::collection(GisObject::withGeometry()->where('object_type', $type)->when($r->search, fn ($q) => $q->where(fn ($q) => $q->where('name', 'ilike', '%'.$r->search.'%')->orWhere('code', 'ilike', '%'.$r->search.'%')))->orderBy('code')->paginate(30)->withQueryString())]);
    }

    public function map()
    {
        return Inertia::render('Map/Index', ['serviceAreas' => \App\Models\ServiceArea::orderBy('name')->get(['id', 'name', 'village', 'district', 'city'])]);
    }

    public function objects(Request $r)
    {
        $r->validate([
            'type' => ['nullable', 'string', \Illuminate\Validation\Rule::in(\App\Services\Gis\GeometryService::TYPES)],
            'search' => 'nullable|string|max:255',
            'bbox' => 'nullable|string|max:200',
            'area_id' => 'nullable|uuid',
            'service_area_id' => 'nullable|uuid|exists:service_areas,id',
        ]);
        $q = GisObject::withGeometry();
        if ($r->filled('service_area_id')) {
            $q->where('service_area_id', $r->service_area_id);
        }
        if ($r->filled('type')) {
            $q->where('object_type', $r->type);
        }if ($r->filled('search')) {
            $q->where(fn ($q) => $q->where('name', 'ilike', '%'.$r->search.'%')->orWhere('code', 'ilike', '%'.$r->search.'%')->orWhereHas('customer', fn ($c) => $c->where('address', 'ilike', '%'.$r->search.'%')->orWhere('customer_id', 'ilike', '%'.$r->search.'%')));
        }if ($r->filled('bbox')) {
            $b = explode(',', $r->bbox);
            abort_unless(count($b) === 4 && count(array_filter($b, 'is_numeric')) === 4, 422);
            $b = array_map('floatval', $b);
            abort_unless(is_finite(array_sum($b)) && abs($b[0]) <= 180 && abs($b[2]) <= 180 && abs($b[1]) <= 90 && abs($b[3]) <= 90 && $b[1] <= $b[3], 422);
            $q->whereRaw('ST_Intersects(geometry,ST_MakeEnvelope(?,?,?,?,4326))', $b);
        }if ($r->filled('area_id')) {
            $q->whereRaw('ST_Contains((SELECT geometry FROM gis_objects WHERE id=? AND object_type=\'AREA\'),gis_objects.geometry)', [$r->area_id]);
        }

return GisObjectResource::collection($q->limit(5000)->get());
    }

    public function show(GisObject $object)
    {
        return new GisObjectResource(GisObject::withGeometry()->findOrFail($object->id));
    }

    public function store(Request $r, NetworkService $s)
    {
        $r->validate(['object_type' => ['sometimes', 'string', \Illuminate\Validation\Rule::in(\App\Services\Gis\GeometryService::TYPES)], 'geometry' => 'nullable|array']);
        $this->permission($r->input('object_type', 'UNCLASSIFIED'), 'create');

        return new GisObjectResource($s->save($r->all()));
    }

    public function update(Request $r, GisObject $object, NetworkService $s)
    {
        $r->validate(['object_type' => ['sometimes', 'string', \Illuminate\Validation\Rule::in(\App\Services\Gis\GeometryService::TYPES)], 'geometry' => 'nullable|array']);
        $this->permission($object->object_type, 'update');
        if ($r->filled('object_type')) {
            $this->permission($r->object_type, 'create');
        }

return new GisObjectResource($s->save($r->all(), $object));
    }

    public function destroy(GisObject $object, NetworkService $s)
    {
        $this->permission($object->object_type, 'delete');
        $s->delete($object);

        return response()->json(['message' => 'Object deleted']);
    }

    public function ports(Odp $odp)
    {
        return response()->json(['data' => $odp->ports()->with('customer:id,name', 'survey.customer:id,name')->orderBy('port_number')->get(), 'availability' => $odp->availability()]);
    }

    public function manage(Odp $odp)
    {
        return Inertia::render('Network/Ports', ['odp' => new GisObjectResource(GisObject::withGeometry()->findOrFail($odp->id))]);
    }

    public function portAction(Request $r, Odp $odp, OdpPort $port, PortService $s)
    {
        abort_unless($port->odp_id === $odp->id, 404);
        $v = $r->validate(['action' => 'required|in:reserve,release,status', 'survey_id' => 'required_if:action,reserve|uuid', 'status' => 'required_if:action,status|in:AVAILABLE,DAMAGED,DISABLED', 'notes' => 'nullable|string|max:5000']);
        match ($v['action']) {
            'reserve' => $s->reserve($port, Survey::findOrFail($v['survey_id'])),'release' => $s->release($port),'status' => $s->status($port,$v['status'],$v['notes'] ?? null)
        };

        return $this->ports($odp);
    }
}
