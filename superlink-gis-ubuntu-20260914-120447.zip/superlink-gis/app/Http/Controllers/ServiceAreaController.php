<?php

namespace App\Http\Controllers;

use App\Models\ServiceArea;
use App\Services\AuditService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class ServiceAreaController
{
    public function index()
    {
        return Inertia::render('Areas/Index', ['areas' => ServiceArea::withCount('objects', 'imports')->orderBy('name')->paginate(30)]);
    }

    public function create(Request $request)
    {
        $v = $request->validate(['service_area_id' => 'nullable|uuid|exists:service_areas,id']);

        return Inertia::render('Areas/Create', [
            'areas' => ServiceArea::orderBy('name')->get(['id', 'name', 'village', 'district', 'city']),
            'selectedAreaId' => $v['service_area_id'] ?? null,
        ]);
    }

    public function store(Request $request)
    {
        foreach (['name', 'village', 'district', 'city'] as $field) {
            if (is_string($request->input($field))) {
                $request->merge([$field => trim($request->input($field))]);
            }
        }
        $region = $request->validate([
            'village' => 'required|string|max:255', 'district' => 'required|string|max:255', 'city' => 'required|string|max:255', 'notes' => 'nullable|string|max:3000',
        ]);
        $data = [...$region, ...$request->validate([
            'name' => ['required', 'string', 'max:255', Rule::unique('service_areas')->where(fn ($q) => $q->where('city', $region['city'])->where('district', $region['district'])->where('village', $region['village']))],
        ])];
        $area = DB::transaction(function () use ($data, $request) {
            $area = ServiceArea::create([...$data, 'created_by' => $request->user()->id]);
            AuditService::record('Create', 'ServiceArea', $area->id, null, $area->toArray());

            return $area;
        });

        return redirect('/areas/create?service_area_id='.$area->id)->with('success', 'Daerah disimpan. Pilih file KMZ/KML untuk menambahkan cakupan.');
    }
}
