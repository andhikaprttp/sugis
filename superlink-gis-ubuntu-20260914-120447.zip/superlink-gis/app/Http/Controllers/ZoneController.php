<?php

namespace App\Http\Controllers;

use App\Services\Gis\ZoneService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ZoneController
{
    public function index(Request $request, ZoneService $service)
    {
        $filters = $request->validate(['level' => 'nullable|in:RT,RW', 'city' => 'nullable|string|max:255', 'district' => 'nullable|string|max:255', 'village' => 'nullable|string|max:255', 'rt' => 'nullable|regex:/^\d{1,3}$/', 'rw' => 'nullable|regex:/^\d{1,3}$/']);

        return Inertia::render('Zones/Index', [...$service->statistics($filters), 'filters' => $filters]);
    }
}
