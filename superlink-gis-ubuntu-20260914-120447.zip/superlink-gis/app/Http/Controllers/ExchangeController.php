<?php

namespace App\Http\Controllers;

use App\Jobs\GenerateCustomerExport;
use App\Jobs\ProcessCustomerExcelImport;
use App\Jobs\ProcessKmzImport;
use App\Models\CustomerImportJob;
use App\Models\ExportJob;
use App\Models\ImportJob;
use App\Services\AuditService;
use App\Services\Customer\CustomerService;
use App\Services\Customer\SpreadsheetService;
use App\Services\Gis\KmlExportService;
use App\Services\Gis\KmzExportService;
use App\Services\Network\NetworkService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExchangeController
{
    private function owner($job): void
    {
        abort_unless($job->uploaded_by === auth()->id() || auth()->user()->hasRole('ADMIN'), 403);
    }

    public function index(Request $r)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $class = $excel ? CustomerImportJob::class : ImportJob::class;

        return Inertia::render('GIS/Import', ['excel' => $excel, 'jobs' => $class::where('uploaded_by', auth()->id())->latest()->paginate(20)]);
    }

    public function upload(Request $r)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $incoming = $r->file('file');
        if ($incoming && ! $incoming->isValid()) {
            $code = $incoming->getError();
            logger()->warning('Upload rejected by PHP', [
                'upload_error' => $code,
                'upload_max_filesize' => ini_get('upload_max_filesize'),
                'post_max_size' => ini_get('post_max_size'),
            ]);
            $message = match ($code) {
                UPLOAD_ERR_INI_SIZE => 'File melebihi batas upload PHP server ('.ini_get('upload_max_filesize').'). Batas aplikasi 256 MB. Jalankan ulang server dengan konfigurasi upload yang sesuai.',
                UPLOAD_ERR_FORM_SIZE => 'File melebihi batas ukuran formulir upload.',
                UPLOAD_ERR_PARTIAL => 'File hanya diterima sebagian. Pilih ulang file dari disk lokal lalu ulangi upload.',
                UPLOAD_ERR_NO_TMP_DIR => 'Folder sementara upload server tidak tersedia. Jalankan ulang server melalui scripts/serve-local.ps1.',
                UPLOAD_ERR_CANT_WRITE => 'Server tidak dapat menulis file sementara upload. Periksa izin folder sementara dan ruang disk server.',
                UPLOAD_ERR_EXTENSION => 'Upload dihentikan oleh ekstensi PHP server.',
                default => 'PHP gagal menerima file (kode '.$code.'). Pilih ulang file lalu coba lagi.',
            };
            throw ValidationException::withMessages(['file' => $message]);
        }
        $r->validate(['file' => 'required|file|max:262144', 'mode' => 'nullable|in:INSERT_ONLY,UPSERT']);
        if (! $excel) {
            $r->validate(['service_area_id' => 'required|uuid|exists:service_areas,id']);
        }
        $f = $r->file('file');
        $ext = strtolower($f->getClientOriginalExtension());
        if (! in_array($ext, $excel ? ['xlsx'] : ['kml', 'kmz'])) {
            throw ValidationException::withMessages(['file' => $excel ? 'Gunakan file .xlsx untuk import pelanggan.' : 'Gunakan file .kml atau .kmz untuk import GIS.']);
        }
        $filename = basename(str_replace('\\', '/', $f->getClientOriginalName()));
        $path = $f->store('imports');
        $class = $excel ? CustomerImportJob::class : ImportJob::class;
        $j = $class::create(['filename' => $filename, 'path' => $path, 'uploaded_by' => auth()->id(), 'mode' => $r->input('mode', 'INSERT_ONLY'), ...($excel ? [] : ['service_area_id' => $r->service_area_id])]);
        try {
            $excel ? ProcessCustomerExcelImport::dispatch($j->id) : ProcessKmzImport::dispatch($j->id);
        } catch (\Throwable $e) {
            // Sync development queues must still reach a readable FAILED review page.
            report($e);
            if ($j->fresh()->status !== 'FAILED') {
                $j->update(['status' => 'FAILED', 'error' => 'Pemrosesan tidak dapat dimulai. Periksa koneksi queue/worker, lalu upload ulang.']);
            }
        }

        return redirect(($excel ? '/customers/import/' : '/gis/import/').$j->id.'/review');
    }

    public function review(Request $r, string $id)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $class = $excel ? CustomerImportJob::class : ImportJob::class;
        $j = $class::findOrFail($id);
        $this->owner($j);

        return Inertia::render('GIS/ImportReview', ['excel' => $excel, 'job' => $excel ? $j : $j->load('serviceArea'), 'rows' => $j->rows()->paginate(100)]);
    }

    public function selection(Request $r, string $id)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $class = $excel ? CustomerImportJob::class : ImportJob::class;
        $j = $class::findOrFail($id);
        $this->owner($j);

        return response()->json(['data' => $j->rows()->whereIn('validation', ['VALID', 'WARNING'])->pluck('id')]);
    }

    public function commit(Request $r, string $id, NetworkService $network, SpreadsheetService $s)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $v = $r->validate(['ids' => 'required|array|min:1|max:20000', 'ids.*' => 'uuid', 'changes' => 'nullable|array', 'changes.*.object_type' => 'nullable|string', 'changes.*.capacity' => 'nullable|integer|min:0|max:1024', 'changes.*.code' => 'nullable|string|max:255', 'changes.*.name' => 'nullable|string|max:255', 'changes.*.area_id' => 'nullable|uuid', 'changes.*.pop_id' => 'nullable|uuid', 'changes.*.odc_id' => 'nullable|uuid', 'changes.*.customer_id' => 'nullable|string|max:255']);
        $class = $excel ? CustomerImportJob::class : ImportJob::class;
        $j = $class::findOrFail($id);
        $this->owner($j);
        if ($excel) {
            $s->commit($j, $v['ids']);
        } else {
            DB::transaction(function () use ($j, $v, $network) {
                $j = ImportJob::whereKey($j->id)->lockForUpdate()->firstOrFail();
                if ($j->status !== 'READY') {
                    throw ValidationException::withMessages(['job' => 'Job bukan READY']);
                }$rows = $j->rows()->whereIn('id', $v['ids'])->get();
                abort_unless($rows->count() === count(array_unique($v['ids'])), 422);
                foreach ($rows as $row) {
                    if ($row->validation === 'INVALID') {
                        throw ValidationException::withMessages(['rows' => 'Geometri invalid harus diperbaiki melalui re-upload']);
                    }$data = [...$row->data, ...array_intersect_key($v['changes'][$row->id] ?? [], array_flip(['object_type', 'code', 'name', 'capacity', 'area_id', 'pop_id', 'odc_id', 'customer_id'])), 'source_filename' => $j->filename];
                    // The destination belongs to the job, never to editable row input.
                    $data['service_area_id'] = $j->service_area_id;
                    if (in_array($data['object_type'], ['CUSTOMER', 'PROSPECT'])) {
                        Gate::authorize('customer.create');
                        $customer = app(CustomerService::class)->save([...$data, 'status' => 'PROSPECT', 'customer_id' => $data['customer_id'] ?? 'IMP-'.substr($row->id, 0, 8)], null, 'KMZ_IMPORT');
                        $customer->object()->update(['service_area_id' => $j->service_area_id]);
                    } else {
                        $network->save($data, null, 'KMZ_IMPORT');
                    }
                }$j->update(['status' => 'COMPLETED', 'inserted_rows' => $rows->count(), 'skipped_rows' => $j->total_rows - $rows->count()]);
                AuditService::record('KMZ Import', 'ImportJob', $j->id, null, ['count' => $rows->count()], 'KMZ_IMPORT');
            });
        }

        return back()->with('success', 'Import selesai dan data dapat diedit');
    }

    public function cancel(Request $r, string $id)
    {
        $excel = str_starts_with($r->path(), 'customers');
        $class = $excel ? CustomerImportJob::class : ImportJob::class;
        $j = $class::findOrFail($id);
        $this->owner($j);
        abort_unless(in_array($j->status, ['READY', 'FAILED']), 422);
        $j->update(['status' => 'CANCELLED']);

        return back();
    }

    private function workbookResponse($book, string $name)
    {
        return response()->streamDownload(function () use ($book) {
            (new Xlsx($book))->save('php://output');
            $book->disconnectWorksheets();
        }, $name, ['Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
    }

    public function template(SpreadsheetService $s)
    {
        return $this->workbookResponse($s->template(), 'superlink-customer-template.xlsx');
    }

    public function errors(CustomerImportJob $job, SpreadsheetService $s)
    {
        $this->owner($job);

        return $this->workbookResponse($s->errors($job), 'customer-import-errors.xlsx');
    }

    public function exportPage(Request $r)
    {
        return Inertia::render('GIS/Export', ['excel' => str_starts_with($r->path(), 'customers'), 'jobs' => ExportJob::where('uploaded_by', auth()->id())->latest()->limit(30)->get(), 'filters' => $r->all()]);
    }

    public function customerExport(Request $r)
    {
        $options = $r->only(['search', 'status', 'pop_id', 'odc_id', 'odp_id', 'package_name', 'rt', 'rw', 'ids', 'missing_location']);
        $j = ExportJob::create(['filename' => 'superlink-customers.xlsx', 'path' => 'exports/'.Str::uuid().'.xlsx', 'uploaded_by' => auth()->id(), 'options' => $options]);
        Storage::makeDirectory('exports');
        GenerateCustomerExport::dispatch($j->id);

        return redirect('/customers/export');
    }

    public function download(ExportJob $job)
    {
        $this->owner($job);
        abort_unless($job->status === 'COMPLETED', 409);

        return Storage::download($job->path, $job->filename);
    }

    public function gisExport(Request $r, KmlExportService $s, KmzExportService $kmz)
    {
        $r->validate(['format' => 'required|in:kml,kmz']);
        $kml = $s->generate($s->query($r->all())->cursor());
        AuditService::record('GIS Export', 'GisObject', null, null, $r->except('_token'), 'WEB');
        if ($r->format === 'kml') {
            return response($kml, 200, ['Content-Type' => 'application/vnd.google-earth.kml+xml', 'Content-Disposition' => 'attachment; filename="superlink-network.kml"']);
        }$path = Storage::path('exports/'.Str::uuid().'.kmz');
        Storage::makeDirectory('exports');
        $kmz->write($path, $kml);

        return response()->download($path, 'superlink-network.kmz')->deleteFileAfterSend(true);
    }
}
