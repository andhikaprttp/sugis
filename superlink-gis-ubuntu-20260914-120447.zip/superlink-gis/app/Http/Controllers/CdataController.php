<?php

namespace App\Http\Controllers;

use App\Jobs\RunDeviceOperation;
use App\Jobs\SyncCdata;
use App\Models\Customer;
use App\Services\AuditService;
use App\Services\Cdata\CdataClient;
use App\Services\Cdata\CdataSync;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CdataController
{
    public function customers(Request $r)
    {
        $v = $r->validate(['search' => 'required|string|min:2|max:100']);

        return response()->json(['data' => Customer::where(fn ($q) => $q->where('name', 'ilike', '%'.$v['search'].'%')->orWhere('customer_id', 'ilike', '%'.$v['search'].'%')->orWhere('ont_serial_number', 'ilike', '%'.$v['search'].'%'))->limit(25)->get(['id', 'name', 'customer_id', 'ont_serial_number', 'pppoe_username'])]);
    }

    public function sync()
    {
        try {
            SyncCdata::dispatch();
        } catch (\Throwable $e) {
            throw ValidationException::withMessages(['cms' => 'Sinkronisasi gagal dimulai. Lihat pengaturan CMS dan worker.']);
        }

        return back()->with('success', 'Sinkronisasi CMS diminta. Refresh halaman untuk melihat hasilnya.');
    }

    public function discover(Request $r)
    {
        $v = $r->validate(['olt_id' => 'required|integer|exists:provisioning_olts,id', 'page' => 'nullable|integer|between:1,200']);
        $olt = DB::table('provisioning_olts')->find($v['olt_id']);
        try {
            $d = app(CdataClient::class)->module('onu_autofind_info', $olt->external_id, ['PageNumber' => $v['page'] ?? 1, 'PageSize' => 100]);
            $rows = collect($d['AutofindInfo'] ?? [])->map(fn ($o) => ['sn' => $o['SnVal'] ?? '', 'pon' => $o['PonId'] ?? '', 'model' => $o['ModelId'] ?? $o['EquipId'] ?? '']);

            return response()->json(['data' => $rows, 'has_more' => $rows->count() === 100]); // Exclude discovered passwords.
        } catch (\Throwable $e) {
            throw ValidationException::withMessages(['cms' => 'Autodiscovery gagal. Periksa CMS dan identitas OLT.']);
        }
    }

    public function operate(Request $r)
    {
        abort_unless($r->user()->can('customer.update'), 403);
        $v = $r->validate(['request_id' => 'required|uuid', 'customer_id' => 'required|uuid|exists:customers,id', 'action' => 'required|in:SUSPEND,RESUME,ACTIVATE', 'confirmed' => 'accepted', 'template_id' => 'required_if:action,ACTIVATE|nullable|integer|exists:provisioning_templates,id', 'pon' => 'required_if:action,ACTIVATE|nullable|regex:~^\d+/\d+/\d+$~', 'onu' => 'required_if:action,ACTIVATE|nullable|integer|between:0,1023', 'username' => 'required_if:action,ACTIVATE|nullable|string|max:128', 'password' => 'required_if:action,ACTIVATE|nullable|string|max:128']);
        if (! DB::table('provisioning_connections')->where('id', 1)->where('enabled', true)->where('allow_writes', true)->exists()) {
            throw ValidationException::withMessages(['cms' => 'Aktifkan izin perintah tulis CMS terlebih dahulu.']);
        }
        $created = DB::transaction(function () use ($v) {
            $c = Customer::whereKey($v['customer_id'])->lockForUpdate()->firstOrFail();
            if (DB::table('device_operations')->where('id', $v['request_id'])->exists()) {
                return false;
            }
            if (DB::table('device_operations')->where('customer_id', $c->id)->whereIn('status', ['QUEUED', 'RUNNING', 'UNKNOWN'])->exists()) {
                throw ValidationException::withMessages(['cms' => 'Ada operasi berjalan atau belum pasti. Rekonsiliasi melalui riwayat sebelum operasi baru.']);
            }
            $sn = CdataSync::sn($c->ont_serial_number);
            if (! $sn) {
                throw ValidationException::withMessages(['cms' => 'Isi serial ONT pada pelanggan dahulu.']);
            }
            if (Customer::whereRaw("upper(regexp_replace(ont_serial_number, '\\s+', '', 'g')) = ?", [$sn])->count() !== 1) {
                throw ValidationException::withMessages(['cms' => 'SN pelanggan duplikat. Perbaiki pemetaan.']);
            }
            $p = ['sn' => $sn];
            if ($v['action'] === 'ACTIVATE') {
                $t = DB::table('provisioning_templates')->find($v['template_id']);
                $olt = DB::table('provisioning_olts')->find($t->olt_id);
                $p += ['olt' => $olt->external_id, 'pon' => $v['pon'], 'onu' => $v['onu'], 'template' => (array) $t, 'username' => $v['username'], 'password' => $v['password']];
                if (! preg_match('/^(LAN[1-4]|SSID([4-9]|1[0-2]))(\s*,\s*(LAN[1-4]|SSID([4-9]|1[0-2])))*$/', $t->binding)) {
                    throw ValidationException::withMessages(['cms' => 'Binding template harus LAN1–LAN4 atau SSID4–SSID12 dipisah koma.']);
                }
            } else {
                $s = DB::table('ont_snapshots')->where('sn', $sn)->where('observed_at', '>', now()->subMinutes(5))->first();
                if (! $s || ! $s->olt_external_id || ! $s->pon_id || $s->onu_id === null) {
                    throw ValidationException::withMessages(['cms' => 'Sinkronkan pemetaan ONT yang lengkap dan terbaru dahulu.']);
                }
                $p += ['olt' => $s->olt_external_id, 'pon' => $s->pon_id, 'onu' => $s->onu_id];
            }
            DB::table('device_operations')->insert(['id' => $v['request_id'], 'customer_id' => $c->id, 'user_id' => auth()->id(), 'action' => $v['action'], 'payload' => Crypt::encryptString(json_encode($p, JSON_THROW_ON_ERROR)), 'created_at' => now(), 'updated_at' => now()]);
            AuditService::record('Request '.$v['action'], 'DeviceOperation', $v['request_id'], null, ['customer_id' => $c->id, 'sn' => $sn, 'olt' => $p['olt']]);

            return true;
        });
        if ($created) {
            try {
                RunDeviceOperation::dispatch($v['request_id']);
            } catch (\Throwable $e) {
                DB::table('device_operations')->where('id', $v['request_id'])->where('status', 'QUEUED')->update(['status' => 'FAILED', 'payload' => null, 'message' => 'Queue tidak tersedia.', 'updated_at' => now()]);
            }
        }

        return redirect('/operations/history')->with('success', 'Permintaan dicatat. Periksa hasil operasi; permintaan bukan bukti keberhasilan perangkat.');
    }

    public function reconcile(Request $r, string $id)
    {
        $r->validate(['confirmed' => 'accepted']);
        $op = DB::table('device_operations')->where('id', $id)->where('status', 'UNKNOWN')->first();
        abort_unless($op, 409);
        DB::table('device_operations')->where('id', $id)->where('status', 'UNKNOWN')->update(['status' => 'RECONCILED', 'message' => 'Operator menyatakan telah memeriksa perangkat melalui CMS.', 'updated_at' => now()]);
        AuditService::record('Manual reconciliation','DeviceOperation',$id,null,['actor' => auth()->id()]);

        return back();
    }
}
