<?php

namespace App\Http\Controllers;

use App\Models\BlastCampaign;
use App\Models\BlastDelivery;
use App\Models\BlastRecipient;
use App\Services\AuditService;
use App\Services\Blast\DokuCsv;
use App\Services\Blast\MessageBuilder;
use App\Services\Blast\ScheduleBuilder;
use App\Services\Blast\WhatsAppSender;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class BlastController
{
    public function index(WhatsAppSender $sender)
    {
        return Inertia::render('Blast/Index', ['campaigns' => BlastCampaign::withCount('recipients')->latest()->paginate(20), 'providerReady' => $sender->configured()]);
    }

    public function csv(Request $request, DokuCsv $parser)
    {
        $request->validate(['file' => 'required|file|max:2048']);

        return response()->json(['recipients' => $parser->parse($request->file('file')->getRealPath())]);
    }

    public function store(Request $request, ScheduleBuilder $builder, MessageBuilder $messages)
    {
        $v = $request->validate([
            'name' => 'required|string|max:255', 'template' => 'required|string|max:4000', 'schedule' => 'required|array',
            'recipients' => 'required|array|min:1|max:500', 'recipients.*.name' => 'required|string|max:255',
            'recipients.*.phone' => 'required|string|max:30', 'recipients.*.invoice' => 'nullable|string|max:255',
            'recipients.*.amount' => 'nullable|string|max:100', 'recipients.*.due_date' => 'nullable|string|max:100',
            'recipients.*.link' => 'nullable|url:http,https|max:2048', 'recipients.*.selected' => 'required|boolean',
            'recipients.*.custom_message' => 'nullable|string|max:4000',
        ]);
        $occurrences = $builder->build($v['schedule']);
        if (collect($occurrences)->contains(fn ($s) => CarbonImmutable::parse($s)->isPast())) {
            throw ValidationException::withMessages(['schedule' => 'Tanggal reminder baru harus berada di masa mendatang.']);
        }
        $rows = [];
        $seen = [];
        foreach ($v['recipients'] as $r) {
            $r = array_intersect_key($r, array_flip(['name', 'phone', 'invoice', 'amount', 'due_date', 'link', 'selected', 'custom_message']));
            $r['phone'] = $messages->phone($r['phone']);
            foreach (['invoice', 'amount', 'due_date'] as $field) {
                $r[$field] ??= '';
            }
            $key = $r['phone'].'|'.$r['invoice'];
            if (isset($seen[$key])) {
                throw ValidationException::withMessages(['recipients' => 'Nomor dan invoice ganda: '.$r['invoice'].'. Hapus baris duplikat.']);
            }
            $seen[$key] = true;
            $rows[] = $r;
        }
        $campaign = DB::transaction(function () use ($v, $rows, $occurrences) {
            $campaign = BlastCampaign::create(['name' => $v['name'], 'template' => $v['template'], 'schedule' => $v['schedule'], 'occurrences' => $occurrences, 'created_by' => auth()->id(), 'enabled' => false]);
            foreach ($rows as $row) {
                $campaign->recipients()->create($row);
            }
            AuditService::record('Create', 'BlastCampaign', $campaign->id, null, ['name' => $campaign->name, 'recipients' => count($rows), 'occurrences' => $occurrences]);

            return $campaign;
        });

        return redirect('/blast/'.$campaign->id)->with('success', 'Reminder disimpan sebagai draft. Periksa pesan sebelum mengaktifkan pengiriman otomatis.');
    }

    public function show(Request $request, BlastCampaign $campaign, MessageBuilder $messages, WhatsAppSender $sender)
    {
        $v = $request->validate(['search' => 'nullable|string|max:100']);

        return Inertia::render('Blast/Show', [
            'campaign' => $campaign, 'providerReady' => $sender->configured(),
            'recipients' => $campaign->recipients()->when(filled($v['search'] ?? null), fn ($q) => $q->where(fn ($q) => $q->where('name', 'ilike', '%'.$v['search'].'%')->orWhere('phone', 'ilike', '%'.$v['search'].'%')->orWhere('invoice', 'ilike', '%'.$v['search'].'%')))->orderBy('name')->paginate(30)->withQueryString()->through(fn ($r) => [...$r->toArray(), 'preview' => $messages->render($campaign->template, $r)]),
            'deliveries' => BlastDelivery::whereHas('recipient', fn ($q) => $q->where('campaign_id', $campaign->id))->latest()->limit(50)->get(['id', 'recipient_id', 'phone', 'slot', 'scheduled_at', 'manual', 'status', 'provider_id', 'error', 'updated_at']),
        ]);
    }

    public function schedule(Request $request, BlastCampaign $campaign, ScheduleBuilder $builder)
    {
        $v = $request->validate(['schedule' => 'required|array', 'template' => 'required|string|max:4000']);
        $slots = $builder->build($v['schedule']);
        DB::transaction(function () use ($campaign, $v, $slots) {
            $campaign = BlastCampaign::whereKey($campaign->id)->lockForUpdate()->firstOrFail();
            if ($campaign->enabled) {
                throw ValidationException::withMessages(['schedule' => 'Jeda pengiriman otomatis sebelum mengubah jadwal.']);
            }
            $old = $campaign->only('schedule', 'template');
            // Keep historical slots valid, but never manufacture new backdated sends.
            foreach (array_diff($slots, $campaign->occurrences) as $slot) {
                if (CarbonImmutable::parse($slot)->isPast()) {
                    throw ValidationException::withMessages(['schedule' => 'Tanggal tambahan harus di masa mendatang.']);
                }
            }
            $campaign->update(['schedule' => $v['schedule'], 'occurrences' => $slots, 'template' => $v['template']]);
            BlastDelivery::whereHas('recipient', fn ($q) => $q->where('campaign_id', $campaign->id))->where('manual', false)->whereIn('status', ['PENDING', 'QUEUED'])->whereNotIn('slot', $slots)->update(['status' => 'CANCELLED']);
            AuditService::record('Update schedule', 'BlastCampaign', $campaign->id, $old, $v);
        });

        return back()->with('success', 'Jadwal dan template diperbarui.');
    }

    public function toggle(Request $request, BlastCampaign $campaign, WhatsAppSender $sender)
    {
        $v = $request->validate(['enabled' => 'required|boolean']);
        if ($v['enabled'] && ! $sender->configured()) {
            throw ValidationException::withMessages(['enabled' => 'Tautan WhatsApp Web tidak bisa mengirim otomatis. Hubungkan API pengirim pada konfigurasi server dahulu.']);
        }
        DB::transaction(function () use ($campaign, $v) {
            $campaign = BlastCampaign::whereKey($campaign->id)->lockForUpdate()->firstOrFail();
            $campaign->update($v);
            AuditService::record($v['enabled'] ? 'Enable reminders' : 'Pause reminders', 'BlastCampaign', $campaign->id, null, $v);
        });

        return back()->with('success', $v['enabled'] ? 'Reminder otomatis diaktifkan.' : 'Reminder dijeda. Pesan yang sudah diproses provider tidak dapat ditarik kembali.');
    }

    public function recipient(Request $request, BlastCampaign $campaign, BlastRecipient $recipient, MessageBuilder $messages)
    {
        abort_unless($recipient->campaign_id === $campaign->id, 404);
        $v = $request->validate(['selected' => 'sometimes|boolean', 'paid' => 'sometimes|boolean', 'custom_message' => 'nullable|string|max:4000', 'phone' => 'sometimes|required|string|max:30']);
        if (isset($v['phone'])) {
            $v['phone'] = $messages->phone($v['phone']);
            if ($campaign->recipients()->where('id', '!=', $recipient->id)->where('phone', $v['phone'])->where('invoice', $recipient->invoice)->exists()) {
                throw ValidationException::withMessages(['phone' => 'Nomor dan invoice ini sudah ada.']);
            }
        }
        DB::transaction(function () use ($recipient, $v) {
            $old = $recipient->only('phone', 'selected', 'paid', 'custom_message');
            $recipient->update($v);
            AuditService::record('Update recipient', 'BlastRecipient', $recipient->id, $old, $v);
        });

        return back()->with('success', 'Penerima diperbarui. Pesan yang sudah dikirim tidak berubah.');
    }

    public function manual(Request $request, BlastCampaign $campaign, BlastRecipient $recipient, WhatsAppSender $sender, MessageBuilder $messages)
    {
        abort_unless($recipient->campaign_id === $campaign->id, 404);
        $v = $request->validate(['request_id' => 'required|uuid']);
        if (! $sender->configured() || ! $recipient->selected || $recipient->paid) {
            throw ValidationException::withMessages(['send' => 'API belum siap, penerima dihentikan, atau invoice sudah lunas.']);
        }
        DB::transaction(function () use ($recipient, $campaign, $v, $messages) {
            $created = DB::table('blast_deliveries')->insertOrIgnore(['id' => (string) Str::uuid(), 'recipient_id' => $recipient->id, 'slot' => 'manual:'.$v['request_id'], 'manual' => true, 'scheduled_at' => now()->toIso8601String(), 'status' => 'PENDING', 'phone' => $recipient->phone, 'message' => $messages->render($campaign->template, $recipient), 'created_at' => now(), 'updated_at' => now()]);
            if ($created) {
                AuditService::record('Request manual send', 'BlastRecipient', $recipient->id, null, ['request_id' => $v['request_id']]);
            }
        });

        return back()->with('success', 'Pesan masuk antrean. Scheduler akan memprosesnya tanpa membuka WhatsApp Web.');
    }
}
