<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class AuthController
{
    public function create()
    {
        return Inertia::render('Auth/Login');
    }

    public function store(Request $r)
    {
        $v = $r->validate(['email' => 'required|email', 'password' => 'required|string']);
        if (! Auth::attempt([...$v, 'active' => true])) {
            throw ValidationException::withMessages(['email' => 'Email atau password tidak sesuai']);
        }$r->session()->regenerate();

        return redirect()->intended('/dashboard');
    }

    public function destroy(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect('/login');
    }
}
