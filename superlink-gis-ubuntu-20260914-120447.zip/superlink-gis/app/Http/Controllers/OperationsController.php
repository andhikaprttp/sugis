<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Services\AuditService;
use App\Services\Monitoring\PppoeMonitor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class OperationsController
{
    public function index(Request $request, string $section)
    {
        abort_unless(in_array($section, ['monitoring', 'olts', 'templates', 'activation', 'actions', 'alarms', 'history', 'connection']), 404);
        if ($section === 'connection') {
            abort_unless($request->user()->can('settings.manage'), 403);
        }
        $filters = $request->validate(['cms_olt' => 'nullable|string|max:255', 'search' => 'nullable|string|max:255', 'state' => 'nullable|in:UNKNOWN,ONLINE,OFFLINE,DEACTIVATED,DYING_GASP']);
        $request->validate(['olt_id' => 'nullable|integer|min:1']);
        $customers = Customer::query()->leftJoin('ont_snapshots as ont', DB::raw("upper(regexp_replace(customers.ont_serial_number, '\\s+', '', 'g'))"), '=', 'ont.sn')->select('customers.id', 'customer_id', 'customers.name', 'status', 'ont_serial_number', 'pppoe_username', 'ont.olt_external_id', 'ont.pon_id', 'ont.onu_id', 'ont.ont_state', 'ont.admin_state', 'ont.offline_reason', 'ont.rx_power', 'ont.tx_power', 'ont.observed_at');
        $customers->leftJoin('cms_olt_snapshots as cms_olt', 'cms_olt.device_id', '=', 'ont.olt_device_id')->addSelect('cms_olt.name as olt_name', 'cms_olt.host as olt_host', 'cms_olt.model as olt_model', 'cms_olt.state as olt_state', 'ont.olt_device_id');
        if ($search = $filters['search'] ?? null) {
            $customers->where(function ($q) use ($search) {
                foreach (['customers.name', 'customer_id', 'ont_serial_number', 'pppoe_username', 'ont.description'] as $field) {
                    $q->orWhere($field, 'ilike', '%'.$search.'%');
                }
            });
        }
        if (in_array($section, ['monitoring', 'actions'])) {
            $customers->where('ont.olt_device_id', $filters['cms_olt'] ?? '');
        }
        $state = $filters['state'] ?? null;
        if ($state === 'UNKNOWN') {
            $customers->where(fn ($q) => $q->whereNull('ont.observed_at')->orWhere('ont.observed_at', '<', now()->subMinutes(5))->orWhere('ont.ont_state', 'UNKNOWN'));
        } elseif ($state) {
            $customers->where('ont.observed_at', '>=', now()->subMinutes(5));
            if (in_array($state, ['ONLINE', 'OFFLINE'])) {
                $customers->where('ont.ont_state', $state);
            } elseif ($state === 'DEACTIVATED') {
                $customers->where('ont.admin_state', $state);
            } else {
                $customers->where('ont.ont_state', 'OFFLINE')->whereRaw("lower(regexp_replace(ont.offline_reason, '[^a-zA-Z]', '', 'g')) like '%dyinggasp%'");
            }
        }

        $pppoeRows = in_array($section, ['monitoring', 'actions']) ? app(PppoeMonitor::class)->query()->get()->keyBy('id') : collect();

        return Inertia::render('Operations/Index', [
            'section' => $section,
            'customers' => in_array($section, ['monitoring', 'actions']) ? $customers->orderBy('customers.name')->paginate(25)->withQueryString()->through(function ($c) use ($pppoeRows) {
                $c->setAttribute('pppoe_state', $pppoeRows->get($c->id)?->pppoe_state ?? 'UNKNOWN');

                return $c;
            }) : null,
            'cmsOlts' => in_array($section, ['olts', 'monitoring', 'actions']) ? DB::table('cms_olt_snapshots')->orderBy('name')->paginate(30, ['*'], 'olt_page')->withQueryString() : null,
            'cmsOnus' => in_array($section, ['olts', 'monitoring']) && ($request->filled('cms_olt') || $request->filled('search')) ? DB::table('ont_snapshots as ont')
                ->leftJoin('cms_olt_snapshots as olt', 'olt.device_id', '=', 'ont.olt_device_id')
                ->when($request->filled('cms_olt'), fn ($q) => $q->where('ont.olt_device_id', $filters['cms_olt']))
                ->select('ont.*', 'olt.name as olt_name', 'olt.host as olt_host')
                ->addSelect(['gis_customer_id' => Customer::query()->select('id')->whereRaw("upper(regexp_replace(customers.ont_serial_number, '\\s+', '', 'g')) = ont.sn")->orderBy('id')->limit(1)])
                ->when($request->filled('search'), fn ($q) => $q->where(fn ($q) => $q->where('ont.sn', 'ilike', '%'.$filters['search'].'%')->orWhere('ont.description', 'ilike', '%'.$filters['search'].'%')))
                ->when(in_array($state, ['ONLINE', 'OFFLINE']), fn ($q) => $q->where('ont.ont_state', $state)->where('ont.observed_at', '>=', now()->subMinutes(5)))
                ->when($state === 'UNKNOWN', fn ($q) => $q->where(fn ($q) => $q->where('ont.ont_state', 'UNKNOWN')->orWhere('ont.observed_at', '<', now()->subMinutes(5))))
                ->when($state === 'DEACTIVATED', fn ($q) => $q->where('ont.admin_state', 'DEACTIVATED')->where('ont.observed_at', '>=', now()->subMinutes(5)))
                ->when($state === 'DYING_GASP', fn ($q) => $q->where('ont.ont_state', 'OFFLINE')->where('ont.observed_at', '>=', now()->subMinutes(5))->whereRaw("lower(regexp_replace(ont.offline_reason, '[^a-zA-Z]', '', 'g')) like '%dyinggasp%'"))
                ->orderBy('ont.sn')->paginate(30, ['*'], 'onu_page')->withQueryString() : null,
            'customerCount' => Customer::count(),
            'olts' => DB::table('provisioning_olts')
                ->when($section === 'olts' && $request->filled('olt_id'), fn ($q) => $q->where('id', $request->olt_id))
                ->when($section === 'olts' && $request->filled('search'), fn ($q) => $q->where(fn ($q) => $q->where('name', 'ilike', '%'.$filters['search'].'%')->orWhere('external_id', 'ilike', '%'.$filters['search'].'%')->orWhere('host', 'ilike', '%'.$filters['search'].'%')))
                ->orderBy('name')->get(),
            'templates' => DB::table('provisioning_templates')->orderBy('name')->get(),
            'connection' => $section === 'connection' ? (DB::table('provisioning_connections')->select('cms_url', 'pppoe_source', 'enabled', 'allow_writes', 'last_sync_at', 'last_error')->first() ?? ['cms_url' => 'http://10.1.1.21', 'pppoe_source' => 'UNCONFIGURED']) : null,
            'connector' => DB::table('provisioning_connections')->select('enabled', 'allow_writes', 'last_sync_at', 'last_error')->first(),
            'operations' => $section === 'history' ? DB::table('device_operations')->select('id', 'customer_id', 'action', 'status', 'stage', 'message', 'created_at')->orderByDesc('created_at')->paginate(30) : null,
            'events' => $section === 'alarms' ? DB::table('ont_events')->orderByDesc('observed_at')->paginate(30) : null,
            'filters' => $filters,
        ]);
    }

    public function save(Request $request, string $section)
    {
        abort_unless(in_array($section, ['olts', 'templates', 'connection']), 404);
        abort_unless($request->user()->can($section === 'connection' ? 'settings.manage' : 'network.update'), 403);
        $table = ['olts' => 'provisioning_olts', 'templates' => 'provisioning_templates', 'connection' => 'provisioning_connections'][$section];
        $rules = match ($section) {
            'olts' => ['name' => 'required|string|max:255', 'external_id' => ['required', 'string', 'max:255', Rule::unique($table)->ignore($request->input('id'))], 'host' => 'nullable|ip'],
            'templates' => ['olt_id' => 'required|integer|exists:provisioning_olts,id', 'name' => 'required|string|max:255', 'vlan' => 'required|integer|between:1,4094', 'line_profile' => 'required|string|max:255', 'service_profile' => 'required|string|max:255', 'wan_profile' => 'required|string|max:255', 'tr069_profile' => 'required|string|max:255', 'binding' => 'required|string|max:255'],
            'connection' => ['cms_url' => ['required', 'url:http,https', 'max:255', function ($attribute, $value, $fail) {
                $p = parse_url($value);
                if (($p['scheme'] ?? '') !== 'https' && ! config('cdata.allow_http')) {
                    $fail('Gunakan HTTPS untuk melindungi token CMS. HTTP memerlukan CDATA_ALLOW_HTTP pada konfigurasi server.');
                }
                if (isset($p['user']) || isset($p['pass']) || isset($p['query']) || isset($p['fragment'])) {
                    $fail('Alamat CMS tidak boleh berisi kredensial, query, atau fragment.');
                }
            }], 'pppoe_source' => 'required|in:UNCONFIGURED,MIKROTIK,RADIUS', 'cms_token' => 'nullable|string|max:4096', 'enabled' => 'sometimes|boolean', 'allow_writes' => 'sometimes|boolean'],
        };
        $values = $request->validate(['id' => 'nullable|integer|exists:'.$table.',id', ...$rules]);
        $id = $section === 'connection' ? 1 : ($values['id'] ?? null);
        unset($values['id']);
        if ($section === 'connection') {
            if (! empty($values['cms_token'])) {
                $values['cms_token'] = Crypt::encryptString($values['cms_token']);
            } else {
                unset($values['cms_token']);
            }
            if (! empty($values['enabled']) && ! isset($values['cms_token']) && ! DB::table($table)->where('id', 1)->value('cms_token')) {
                throw ValidationException::withMessages(['cms_token' => 'Token diperlukan untuk mengaktifkan konektor.']);
            }
        }
        DB::transaction(function () use ($id, $table, $values) {
            $old = $id ? DB::table($table)->find($id) : null;
            if ($id) {
                DB::table($table)->updateOrInsert(['id' => $id], [...$values, 'updated_at' => now(), ...($old ? [] : ['created_at' => now()])]);
            } else {
                $id = DB::table($table)->insertGetId([...$values, 'created_at' => now(), 'updated_at' => now()]);
            }
            $safeOld = $old ? (array) $old : null;
            $safeNew = $values;
            unset($safeOld['cms_token'],$safeNew['cms_token']);
            AuditService::record($old ? 'Update' : 'Create', $table, (string) $id, $safeOld, $safeNew);
        });

        return back()->with('success', 'Konfigurasi disimpan. Belum ada perintah yang dikirim ke CMS atau OLT.');
    }
}
