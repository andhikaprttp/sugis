<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Device;
use App\Services\AuditService;
use App\Services\DeviceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class DeviceController
{
    public function index(Request $request)
    {
        $request->validate(['device_id' => 'nullable|uuid']);
        $filters = $request->validate(['search' => 'nullable|string|max:255', 'status' => ['nullable', Rule::in(Device::STATUSES)], 'type' => ['nullable', Rule::in(Device::TYPES)], 'customer_id' => 'nullable|uuid', 'assign_to' => 'nullable|uuid|exists:customers,id']);
        $query = Device::with('customer:id,customer_id,name,deleted_at');
        if ($request->filled('device_id')) {
            $query->whereKey($request->device_id);
            $filters['device_id'] = $request->device_id;
        }
        if (($search = $filters['search'] ?? '') !== '') {
            $query->where(fn ($q) => $q->where('asset_tag', 'ilike', "%$search%")->orWhere('serial_number', 'ilike', "%$search%")->orWhere('model', 'ilike', "%$search%"));
        }
        foreach (['status', 'type', 'customer_id'] as $key) {
            if (! empty($filters[$key])) {
                $query->where($key, $filters[$key]);
            }
        }
        $summary = function () {
            $counts = Device::selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status');

            return collect(Device::STATUSES)->mapWithKeys(fn ($s) => [$s => (int) ($counts[$s] ?? 0)]);
        };
        $types = fn () => Device::selectRaw("type, count(*) as total, count(*) filter (where status = 'IN_STOCK') as stock")->groupBy('type')->orderBy('type')->get();
        $trend = function () {
            $monthly = DB::table('device_movements')->where('created_at', '>=', now()->startOfMonth()->subMonths(5))
                ->selectRaw("to_char(created_at, 'YYYY-MM') as month, action, count(*) as total")->groupByRaw("to_char(created_at, 'YYYY-MM'), action")->get();

            return collect(range(5, 0))->map(function ($offset) use ($monthly) {
                $month = now()->startOfMonth()->subMonths($offset)->format('Y-m');
                $rows = $monthly->where('month', $month)->pluck('total', 'action');

                return ['month' => $month, 'received' => (int) ($rows['RECEIVE'] ?? 0), 'assigned' => (int) ($rows['ASSIGN'] ?? 0), 'returned' => (int) ($rows['RETURN'] ?? 0)];
            });
        };
        $history = fn () => DB::table('device_movements as m')->join('devices as d', 'd.id', '=', 'm.device_id')
            ->leftJoin('customers as c', 'c.id', '=', 'm.customer_id')->leftJoin('users as u', 'u.id', '=', 'm.user_id')
            ->select('m.*', 'd.asset_tag', 'd.serial_number', 'c.name as customer_name', 'u.name as actor')
            ->when($filters['customer_id'] ?? null, fn ($q, $id) => $q->where('m.customer_id', $id))
            ->orderByDesc('m.id')->limit(30)->get();

        return Inertia::render('Devices/Index', [
            'devices' => $query->latest()->paginate(25)->withQueryString(), 'filters' => $filters,
            'summary' => $summary,
            'types' => $types, 'trend' => $trend, 'history' => $history,
            'selectedCustomer' => ! empty($filters['assign_to'] ?? $filters['customer_id'] ?? null) ? Customer::findOrFail($filters['assign_to'] ?? $filters['customer_id'], ['id', 'customer_id', 'name', 'ont_serial_number']) : null,
        ]);
    }

    public function customers(Request $request)
    {
        $v = $request->validate(['search' => 'required|string|min:2|max:100', 'device_id' => 'nullable|uuid|exists:devices,id']);
        $device = isset($v['device_id']) ? Device::findOrFail($v['device_id']) : null;

        return Customer::where(fn ($q) => $q->where('name', 'ilike', '%'.$v['search'].'%')->orWhere('customer_id', 'ilike', '%'.$v['search'].'%'))
            ->select('id', 'customer_id', 'name', 'ont_serial_number', 'address')
            ->withExists(['devices as has_ont' => fn ($q) => $q->where('type', 'ONT')])
            ->orderBy('name')->limit(20)->get()->map(function ($customer) use ($device) {
                $reason = $device?->type === 'ONT' && $customer->has_ont ? 'Sudah memiliki ONT inventori' : null;
                if ($device?->type === 'ONT' && $customer->ont_serial_number && strcasecmp($customer->ont_serial_number, $device->serial_number) !== 0) {
                    $reason ??= 'Serial ONT lama berbeda';
                }

                return [...$customer->toArray(), 'assignment_blocked' => $reason];
            });
    }

    public function store(Request $request, DeviceService $service)
    {
        $request->validate(['asset_tag' => 'required|string|max:100', 'serial_number' => 'required|string|max:255']);
        $request->merge(['serial_number' => strtoupper(trim((string) $request->input('serial_number'))), 'asset_tag' => strtoupper(trim((string) $request->input('asset_tag')))]);
        $data = $request->validate([
            'asset_tag' => 'required|string|max:100|unique:devices', 'serial_number' => 'required|string|max:255|unique:devices',
            'type' => ['required', Rule::in(Device::TYPES)], ...$this->metadataRules(), 'location' => 'required|string|max:255',
        ]);
        $service->create($data);

        return back()->with('success', 'Perangkat ditambahkan ke stok.');
    }

    public function update(Request $request, Device $device)
    {
        $data = $request->validate($this->metadataRules());
        DB::transaction(function () use ($device, $data) {
            $device = Device::whereKey($device->id)->lockForUpdate()->firstOrFail();
            abort_if($device->status === 'INSTALLED', 422, 'Kembalikan perangkat sebelum mengubah detailnya.');
            $old = $device->toArray();
            $device->update($data);
            AuditService::record('Update', 'Device', $device->id, $old, $device->toArray());
        });

        return back()->with('success', 'Detail perangkat diperbarui.');
    }

    public function transition(Request $request, Device $device, DeviceService $service)
    {
        $data = $request->validate([
            'action' => 'required|in:ASSIGN,RETURN,STATUS',
            'customer_id' => ['required_if:action,ASSIGN', 'nullable', 'uuid', Rule::exists('customers', 'id')->whereNull('deleted_at')],
            'status' => 'required_unless:action,ASSIGN|nullable|in:IN_STOCK,DAMAGED,RETIRED',
            'location' => 'required_unless:action,ASSIGN|nullable|string|max:255', 'notes' => 'nullable|string|max:3000',
        ]);
        if (in_array($data['action'], ['ASSIGN', 'RETURN'])) {
            abort_unless($request->user()->can('customer.update'), 403);
        }
        $service->transition($device, $data);

        return back()->with('success', 'Mutasi perangkat berhasil dicatat.');
    }

    private function metadataRules(): array
    {
        return ['vendor' => 'nullable|string|max:255', 'model' => 'nullable|string|max:255', 'purchased_at' => 'nullable|date_format:Y-m-d', 'notes' => 'nullable|string|max:3000'];
    }
}
