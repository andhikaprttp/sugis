<?php

namespace App\Models;

class BlastRecipient extends UuidModel
{
    protected function casts(): array
    {
        return ['selected' => 'boolean', 'paid' => 'boolean'];
    }

    public function campaign()
    {
        return $this->belongsTo(BlastCampaign::class, 'campaign_id');
    }
}
