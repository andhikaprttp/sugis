<?php

namespace App\Models;

abstract class NetworkAsset extends UuidModel
{
    public function object()
    {
        return $this->belongsTo(GisObject::class, 'id');
    }
}
