<?php

namespace App\Models;

class ServicePackage extends UuidModel
{
    protected function casts(): array
    {
        return ['active' => 'boolean', 'price' => 'decimal:2', 'speed_mbps' => 'integer'];
    }
}
