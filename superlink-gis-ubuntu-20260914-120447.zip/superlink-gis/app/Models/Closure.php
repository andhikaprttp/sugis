<?php

namespace App\Models;

class Closure extends NetworkAsset {}
