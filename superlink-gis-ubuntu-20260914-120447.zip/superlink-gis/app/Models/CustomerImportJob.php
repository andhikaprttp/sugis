<?php

namespace App\Models;

class CustomerImportJob extends ImportJob
{
    public function rows()
    {
        return $this->hasMany(CustomerImportRow::class, 'job_id')->orderBy('row_number');
    }
}
