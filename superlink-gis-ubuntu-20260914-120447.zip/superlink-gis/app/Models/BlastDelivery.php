<?php

namespace App\Models;

class BlastDelivery extends UuidModel
{
    protected function casts(): array
    {
        return ['scheduled_at' => 'immutable_datetime', 'manual' => 'boolean'];
    }

    public function recipient()
    {
        return $this->belongsTo(BlastRecipient::class, 'recipient_id');
    }
}
