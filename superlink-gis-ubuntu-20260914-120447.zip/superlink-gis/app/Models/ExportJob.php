<?php

namespace App\Models;

class ExportJob extends ImportJob {}
