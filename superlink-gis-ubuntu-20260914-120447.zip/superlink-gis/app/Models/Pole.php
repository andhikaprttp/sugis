<?php

namespace App\Models;

class Pole extends NetworkAsset {}
