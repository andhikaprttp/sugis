<?php

namespace App\Models;

class ImportObject extends UuidModel
{
    protected function casts(): array
    {
        return ['data' => 'array', 'existing' => 'array', 'errors' => 'array', 'warnings' => 'array'];
    }
}
