<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends UuidModel
{
    use SoftDeletes;

    public function devices()
    {
        return $this->hasMany(Device::class);
    }

    public function object()
    {
        return $this->belongsTo(GisObject::class, 'gis_object_id');
    }

    public function port()
    {
        return $this->hasOne(OdpPort::class);
    }

    public function pop()
    {
        return $this->belongsTo(Pop::class);
    }

    public function surveys()
    {
        return $this->hasMany(Survey::class);
    }

    public function topology(): array
    {
        $p = $this->port()->with('odp.object', 'odp.odc.object', 'odp.odc.pop.object')->first();

        return ['port' => $p?->port_number, 'port_id' => $p?->id, 'odp' => $p?->odp?->object?->code, 'odc' => $p?->odp?->odc?->object?->code, 'pop' => $p?->odp?->odc?->pop?->object?->code ?? $this->pop?->object?->code];
    }
}
