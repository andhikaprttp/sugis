<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class GisObject extends UuidModel
{
    use SoftDeletes;

    protected $hidden = ['geometry'];

    public function odp()
    {
        return $this->hasOne(Odp::class, 'id');
    }

    public function customer()
    {
        return $this->hasOne(Customer::class);
    }

    public function scopeWithGeometry($q)
    {
        return $q->select('gis_objects.*')->selectRaw('ST_AsGeoJSON(geometry)::json AS geojson');
    }

    protected function casts(): array
    {
        return ['geojson' => 'array'];
    }
}
