<?php

namespace App\Models;

class Odc extends NetworkAsset
{
    public function pop()
    {
        return $this->belongsTo(Pop::class);
    }

    public function odps()
    {
        return $this->hasMany(Odp::class);
    }
}
