<?php

namespace App\Models;

class FiberRoute extends NetworkAsset
{
    public function segments()
    {
        return $this->hasMany(FiberSegment::class, 'route_id')->orderBy('sequence');
    }
}
