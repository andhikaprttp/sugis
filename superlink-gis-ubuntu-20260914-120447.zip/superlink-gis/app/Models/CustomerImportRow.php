<?php

namespace App\Models;

class CustomerImportRow extends ImportObject {}
