<?php

namespace App\Models;

class Device extends UuidModel
{
    public const TYPES = ['ONT', 'ROUTER', 'STB', 'OTHER'];
    public const STATUSES = ['IN_STOCK', 'INSTALLED', 'DAMAGED', 'RETIRED'];

    public function customer()
    {
        return $this->belongsTo(Customer::class)->withTrashed();
    }
}
