<?php

namespace App\Models;

class ServiceArea extends UuidModel
{
    public function objects()
    {
        return $this->hasMany(GisObject::class);
    }

    public function imports()
    {
        return $this->hasMany(ImportJob::class);
    }
}
