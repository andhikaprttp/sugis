<?php

namespace App\Models;

class Survey extends UuidModel
{
    protected $hidden = ['route'];

    protected function casts(): array
    {
        return ['route_nodes' => 'array'];
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function odp()
    {
        return $this->belongsTo(Odp::class);
    }

    public function surveyor()
    {
        return $this->belongsTo(User::class, 'surveyor_id');
    }

    public function reservation()
    {
        return $this->hasOne(OdpPort::class, 'reserved_for');
    }
}
