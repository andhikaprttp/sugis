<?php

namespace App\Models;

class BlastCampaign extends UuidModel
{
    protected function casts(): array
    {
        return ['schedule' => 'array', 'occurrences' => 'array', 'enabled' => 'boolean'];
    }

    public function recipients()
    {
        return $this->hasMany(BlastRecipient::class, 'campaign_id');
    }
}
