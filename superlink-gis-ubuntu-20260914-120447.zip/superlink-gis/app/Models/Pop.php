<?php

namespace App\Models;

class Pop extends NetworkAsset
{
    public function odcs()
    {
        return $this->hasMany(Odc::class);
    }
}
