<?php

namespace App\Models;

class FiberSegment extends UuidModel
{
    protected $hidden = ['geometry'];

    public function startNode()
    {
        return $this->belongsTo(GisObject::class, 'start_node_id');
    }

    public function endNode()
    {
        return $this->belongsTo(GisObject::class, 'end_node_id');
    }
}
