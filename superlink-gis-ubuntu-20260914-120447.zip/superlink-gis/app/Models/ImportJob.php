<?php

namespace App\Models;

class ImportJob extends UuidModel
{
    protected $attributes = ['mode' => 'INSERT_ONLY', 'status' => 'UPLOADED'];

    protected function casts(): array
    {
        return ['options' => 'array', 'counts' => 'array'];
    }

    public function rows()
    {
        return $this->hasMany(ImportObject::class, 'job_id')->orderBy('row_number');
    }

    public function serviceArea()
    {
        return $this->belongsTo(ServiceArea::class);
    }
}
