<?php

namespace App\Models;

class OdpPort extends UuidModel
{
    public function odp()
    {
        return $this->belongsTo(Odp::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function survey()
    {
        return $this->belongsTo(Survey::class, 'reserved_for');
    }
}
