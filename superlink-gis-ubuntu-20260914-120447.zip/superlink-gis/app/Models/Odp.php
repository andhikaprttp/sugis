<?php

namespace App\Models;

class Odp extends NetworkAsset
{
    public function odc()
    {
        return $this->belongsTo(Odc::class);
    }

    public function ports()
    {
        return $this->hasMany(OdpPort::class);
    }

    public function customers()
    {
        return $this->hasManyThrough(Customer::class, OdpPort::class, 'odp_id', 'id', 'id', 'customer_id');
    }

    public function availability(?array $counts = null): array
    {
        $counts ??= $this->ports()->selectRaw('status,count(*) as total')->groupBy('status')->pluck('total', 'status')->all();

        return ['capacity' => (int) $this->capacity, 'available' => (int) ($counts['AVAILABLE'] ?? 0), 'occupied' => (int) ($counts['OCCUPIED'] ?? 0), 'reserved' => (int) ($counts['RESERVED'] ?? 0), 'damaged' => (int) ($counts['DAMAGED'] ?? 0), 'disabled' => (int) ($counts['DISABLED'] ?? 0), 'utilization' => $this->capacity ? round(100 * ($counts['OCCUPIED'] ?? 0) / $this->capacity, 1) : 0];
    }
}
