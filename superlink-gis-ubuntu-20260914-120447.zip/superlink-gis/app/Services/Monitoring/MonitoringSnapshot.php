<?php

namespace App\Services\Monitoring;

use App\Models\Customer;
use App\Services\Cdata\CdataSync;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class MonitoringSnapshot
{
    public function fresh(?string $time): bool
    {
        return $time && Carbon::parse($time)->gte(now()->subMinutes(5));
    }

    public function read(): array
    {
        // Read a consistent generation while collectors atomically replace snapshots.
        return DB::transaction(function () {
            if (DB::transactionLevel() === 1) {
                DB::statement('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
            }

            return $this->load();
        });
    }

    private function load(): array
    {
        $cms = DB::table('provisioning_connections')->first();
        $poll = DB::table('pppoe_poll_state')->first();
        $cmsOk = $cms?->enabled && ! $cms?->last_error && $this->fresh($cms?->last_sync_at);
        $pppEnabled = app(PppoeMonitor::class)->configured();
        $pppOk = $pppEnabled && ! $poll?->error && $this->fresh($poll?->last_success_at);
        $olts = DB::table('cms_olt_snapshots')->get()->keyBy('device_id');
        $onts = DB::table('ont_snapshots')->get()->keyBy('sn');
        $ppps = app(PppoeMonitor::class)->query()->get()->keyBy('id');
        $rows = [];
        foreach ($olts as $o) {
            $rows['olt:'.$o->device_id] = ['key' => 'olt:'.$o->device_id, 'type' => 'OLT', 'name' => $o->name, 'olt' => $o->name, 'olt_id' => $o->device_id,
                'state' => $cmsOk && $this->fresh($o->observed_at) ? $o->state : 'UNKNOWN',
                'sn' => $o->sn, 'ip' => $o->host, 'model' => $o->model, 'online_count' => $o->online_count, 'onu_count' => $o->onu_count, 'observed_at' => $o->observed_at];
        }
        foreach ($onts as $o) {
            $rows['onu:'.$o->sn] = ['key' => 'onu:'.$o->sn, 'type' => 'ONU', 'name' => $o->description ?: $o->sn, 'sn' => $o->sn,
                'state' => $cmsOk && $this->fresh($o->observed_at) ? $o->ont_state : 'UNKNOWN',
                'olt' => $olts->get($o->olt_device_id)?->name ?? $o->olt_external_id, 'olt_id' => $o->olt_device_id,
                'pon' => $o->pon_id, 'onu' => $o->onu_id, 'rx' => $o->rx_power, 'tx' => $o->tx_power, 'observed_at' => $o->observed_at];
        }
        foreach (Customer::with('pop.object', 'port.odp.object', 'port.odp.odc.pop.object')->get() as $c) {
            $sn = CdataSync::sn($c->ont_serial_number);
            $o = $rows['onu:'.$sn] ?? [];
            $p = $ppps->get($c->id);
            $r = [...$o, 'key' => 'customer:'.$c->id, 'type' => 'CUSTOMER', 'name' => $c->name, 'customer_code' => $c->customer_id,
                'state' => $o['state'] ?? 'UNKNOWN', 'username' => $c->pppoe_username, 'package' => $c->package_name,
                'pop' => $c->pop?->object?->code ?? $c->port?->odp?->odc?->pop?->object?->code, 'pop_id' => $c->pop_id,
                'odp' => $c->port?->odp?->object?->code,
                'pppoe' => $pppOk ? match ($p?->pppoe_state) {
                    'UP' => 'ONLINE', 'DOWN' => 'OFFLINE', default => 'UNKNOWN'
                } : 'UNKNOWN',
                'ip' => $p?->ip, 'uptime' => $p?->uptime, 'pppoe_observed_at' => $p?->observed_at];
            $rows[$r['key']] = $r;
        }

        return ['rows' => $rows, 'sources' => ['CMS' => $cms?->enabled ? (bool) $cmsOk : null, 'PPPoE' => $pppEnabled ? (bool) $pppOk : null]];
    }
}
