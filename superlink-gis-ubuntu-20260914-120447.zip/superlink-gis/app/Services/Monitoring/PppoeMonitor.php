<?php

namespace App\Services\Monitoring;

use App\Models\Customer;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class PppoeMonitor
{
    public function configured(): bool
    {
        return config('monitoring.driver') === 'mikrotik' && config('monitoring.url') && config('monitoring.username') && config('monitoring.password');
    }

    private function read(string $path, string $fields): array
    {
        $url = rtrim(config('monitoring.url'), '/');
        $parts = parse_url($url);
        if (! $parts || empty($parts['host']) || ! in_array($parts['scheme'] ?? '', config('monitoring.allow_http') ? ['http', 'https'] : ['https']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) || ! in_array($parts['path'] ?? '', ['', '/'])) {
            throw new RuntimeException('MIKROTIK_URL harus base URL HTTPS tanpa path/kredensial.');
        }
        try {
            $r = Http::withBasicAuth(config('monitoring.username'), config('monitoring.password'))->acceptJson()->connectTimeout(5)->timeout(30)->withOptions(['allow_redirects' => false])->get($url.'/rest/'.$path, ['.proplist' => $fields]);
        } catch (\Throwable $e) {
            throw new RuntimeException('Router tidak merespons. Periksa jaringan dan sertifikat TLS.');
        }
        if (! $r->successful()) {
            throw new RuntimeException('Router menolak pembacaan sesi (HTTP '.$r->status().').');
        }
        $data = $r->json();
        if (! is_array($data) || ! array_is_list($data) || count($data) > 50000) {
            throw new RuntimeException('Respons RouterOS tidak berupa daftar yang didukung.');
        }
        foreach ($data as $row) {
            if (! is_array($row) || ! is_string($row['name'] ?? null) || ! is_string($row['service'] ?? null)) {
                throw new RuntimeException('Data sesi router tidak lengkap.');
            }
        }

        return $data;
    }

    public function sync(): void
    {
        if (! $this->configured()) {
            throw new RuntimeException('Konektor PPPoE belum dikonfigurasi.');
        }
        $lock = Cache::lock('pppoe-poll', 110);
        if (! $lock->get()) {
            throw new RuntimeException('Polling PPPoE masih berjalan.');
        }
        try {
            // Read local identities first; RADIUS-only absent sessions cannot be assumed DOWN.
            $identities = $this->read('ppp/secret', 'name,service');
            $sessions = $this->read('ppp/active', 'name,service,address,uptime');
            $known = [];
            $active = [];
            foreach ($identities as $r) {
                if (in_array($r['service'], ['pppoe', 'any'], true)) {
                    $known[$r['name']] = true;
                }
            }
            foreach ($sessions as $r) {
                if ($r['service'] === 'pppoe') {
                    $active[$r['name']] = $r;
                }
            }
            $customers = Customer::get(['id', 'pppoe_username']);
            $duplicates = $customers->filter(fn ($c) => ! empty($c->pppoe_username))->countBy('pppoe_username');
            $rows = [];
            $counts = ['UP' => 0, 'DOWN' => 0, 'UNKNOWN' => 0];
            $now = now();
            foreach ($customers as $c) {
                $username = $c->pppoe_username ?? '';
                $state = 'UNKNOWN';
                if ($username !== '' && ($duplicates[$username] ?? 0) === 1) {
                    $state = isset($active[$username]) ? 'UP' : (isset($known[$username]) ? 'DOWN' : 'UNKNOWN');
                }
                $counts[$state]++;
                $r = $state === 'UP' ? $active[$username] : [];
                $rows[] = ['customer_id' => $c->id, 'username' => $username, 'state' => $state, 'ip' => isset($r['address']) ? substr($r['address'], 0, 255) : null, 'uptime' => isset($r['uptime']) ? substr($r['uptime'], 0, 255) : null, 'observed_at' => $now];
            }
            DB::transaction(function () use ($rows, $counts, $now) {
                DB::table('pppoe_snapshots')->delete();
                foreach (array_chunk($rows, 500) as $chunk) {
                    DB::table('pppoe_snapshots')->insert($chunk);
                }
                DB::table('pppoe_history')->insert(['up' => $counts['UP'], 'down' => $counts['DOWN'], 'unknown' => $counts['UNKNOWN'], 'observed_at' => $now]);
                DB::table('pppoe_history')->where('observed_at', '<', now()->subDays(7))->delete();
                DB::table('pppoe_poll_state')->updateOrInsert(['id' => 1], ['last_success_at' => $now, 'last_attempt_at' => $now, 'error' => null]);
            });
        } catch (\Throwable $e) {
            $message = $e instanceof RuntimeException && ! ($e instanceof QueryException) ? $e->getMessage() : 'Polling gagal menyimpan hasil.';
            DB::table('pppoe_poll_state')->updateOrInsert(['id' => 1], ['last_attempt_at' => now(), 'error' => substr($message, 0, 255)]);
            throw new RuntimeException($message);
        } finally {
            $lock->release();
        }
    }

    public function query()
    {
        $q = Customer::query()->leftJoin('pppoe_snapshots as ppp', function ($j) {
            $j->on('customers.id', '=', 'ppp.customer_id')->on('customers.pppoe_username', '=', 'ppp.username');
        });
        // Changing/clearing the username invalidates the old measurement immediately.
        $effective = "CASE WHEN ppp.observed_at >= ? AND (SELECT count(*) FROM customers c2 WHERE c2.deleted_at IS NULL AND c2.pppoe_username=customers.pppoe_username)=1 THEN ppp.state ELSE 'UNKNOWN' END";
        if (! $this->configured()) {
            return $q->select('customers.id', 'customers.name', 'customers.customer_id', 'customers.pppoe_username', 'ppp.ip', 'ppp.uptime', 'ppp.observed_at')->selectRaw("'UNKNOWN' as pppoe_state");
        }

        return $q->select('customers.id', 'customers.name', 'customers.customer_id', 'customers.pppoe_username', 'ppp.ip', 'ppp.uptime', 'ppp.observed_at')->selectRaw($effective.' as pppoe_state', [now()->subMinutes(5)]);
    }

    public function summary(): array
    {
        $rows = $this->query()->get();
        $counts = ['UP' => 0, 'DOWN' => 0, 'UNKNOWN' => 0];
        foreach ($rows as $r) {
            $counts[$r->pppoe_state]++;
        }

        return ['configured' => $this->configured(), 'counts' => $counts, 'poll' => DB::table('pppoe_poll_state')->find(1), 'recent' => $rows->sortBy(fn ($r) => ['DOWN' => 0, 'UNKNOWN' => 1, 'UP' => 2][$r->pppoe_state])->take(12)->values(),
            'history' => DB::table('pppoe_history')->where('observed_at', '>=', now()->subDay())->orderByDesc('observed_at')->limit(60)->get()->reverse()->values()];
    }
}
