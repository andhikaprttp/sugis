<?php

namespace App\Services\Monitoring;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class IncidentMonitor
{
    public function tick(): void
    {
        $lock = Cache::lock('monitoring-incidents', 120);
        if (! $lock->get()) {
            return;
        }
        try {
            $snapshot = app(MonitoringSnapshot::class)->read();
            $this->evaluate($snapshot);
        } finally {
            $lock->release();
        }
    }

    public function evaluate(array $snapshot): void
    {
        $previousEligibility = DB::table('monitoring_incidents')->whereNull('resolved_at')->pluck('alert_eligible', 'id');
        DB::table('monitoring_incidents')->whereNull('resolved_at')->update(['alert_eligible' => false]);
        $rows = $snapshot['rows'];
        $conditions = [];
        foreach ($snapshot['sources'] as $source => $healthy) {
            $conditions['source:'.$source] = ['SOURCE UNAVAILABLE', ['name' => $source, 'diagnosis' => 'Status pelanggan UNKNOWN; periksa sumber monitoring.'], $healthy === null ? null : ! $healthy];
        }
        $groups = collect($rows)->filter(fn ($r) => $r['type'] === 'ONU' && ! empty($r['olt_id']) && isset($r['pon']))->groupBy(fn ($r) => $r['olt_id'].'/'.$r['pon']);
        // The existing installation has a single RouterOS source; correlate its lost sessions.
        $pppCustomers = collect($rows)->where('type', 'CUSTOMER');
        $pppLost = $pppCustomers->filter(fn ($r) => $r['pppoe'] === 'OFFLINE' && $r['state'] === 'ONLINE');
        $nasOutage = $pppLost->count() >= config('telegram.mass_threshold');
        $conditions['nas:primary'] = ['NAS OUTAGE', ['name' => 'Sumber PPPoE utama', 'affected' => $pppLost->count(), 'diagnosis' => 'Banyak PPPoE offline sementara ONU online; periksa MikroTik / PPPoE service / BRAS.'], ($snapshot['sources']['PPPoE'] ?? null) !== true || $pppCustomers->contains('pppoe', 'UNKNOWN') ? null : $nasOutage];
        $mass = [];
        foreach ($groups as $key => $members) {
            $offline = $members->where('state', 'OFFLINE');
            $parent = $rows['olt:'.$members->first()['olt_id']]['state'] ?? 'UNKNOWN';
            $bad = $offline->count() >= config('telegram.mass_threshold');
            $mass[$key] = $bad;
            $conditions['pon:'.$key] = ['PON OUTAGE', [...$members->first(), 'name' => 'PON '.$key, 'affected' => $offline->count(), 'diagnosis' => 'Kemungkinan PON / ODP / splitter / feeder.'], $parent !== 'ONLINE' || $members->contains('state', 'UNKNOWN') ? null : $bad];
        }
        foreach ($rows as $key => $r) {
            $parent = isset($r['olt_id']) ? ($rows['olt:'.$r['olt_id']]['state'] ?? 'UNKNOWN') : 'ONLINE';
            $suppressed = $r['type'] !== 'OLT' && ($parent !== 'ONLINE' || ($mass[($r['olt_id'] ?? '').'/'.($r['pon'] ?? '')] ?? false));
            if ($r['type'] !== 'CUSTOMER') {
                $conditions[$key] = [$r['type'].' OFFLINE', [...$r, 'diagnosis' => $r['type'] === 'OLT' ? 'Periksa daya / uplink OLT.' : 'Kemungkinan fiber / daya / ONU.'], $suppressed || $r['state'] === 'UNKNOWN' ? null : $r['state'] === 'OFFLINE'];
                if ($r['type'] === 'ONU') {
                    $conditions['optical:'.$key] = ['OPTICAL WARNING', [...$r, 'diagnosis' => 'Periksa redaman jalur / konektor / patchcord.'], $suppressed || $r['state'] !== 'ONLINE' || ! is_numeric($r['rx']) ? null : (float) $r['rx'] < config('telegram.rx_warning')];
                }
            } else {
                $conditions[$key] = ['PELANGGAN OFFLINE', [...$r, 'diagnosis' => $r['state'] === 'ONLINE' ? 'Kemungkinan PPPoE / WAN / router pelanggan.' : 'Periksa status ONU dan jalur pelanggan.'], $nasOutage || $suppressed || $r['state'] === 'OFFLINE' || $r['pppoe'] === 'UNKNOWN' ? null : $r['pppoe'] === 'OFFLINE'];
            }
        }
        foreach ($conditions as $key => [$kind, $context, $bad]) {
            $fingerprint = hash('sha256', $key);
            $q = DB::table('monitoring_incidents')->where('fingerprint', $fingerprint)->whereNull('resolved_at');
            $incident = $q->first();
            if ($bad === null) {
                // Unknown breaks the continuous debounce window, but never signals recovery.
                if ($incident && ! $incident->confirmed_at) {
                    $q->update(['started_at' => now()]);
                }

                continue;
            }
            if ($bad) {
                if ($incident && ! $incident->confirmed_at && ! ($previousEligibility[$incident->id] ?? false)) {
                    $q->update(['started_at' => now()]);
                    $incident->started_at = now()->toDateTimeString();
                }
                if (! $incident) {
                    DB::table('monitoring_incidents')->insert(['fingerprint' => $fingerprint, 'kind' => $kind, 'severity' => $kind === 'OPTICAL WARNING' ? 'WARNING' : 'CRITICAL', 'context' => json_encode($context), 'started_at' => now(), 'status' => 'OPEN']);
                    $incident = $q->first();
                }
                $q->update(['context' => json_encode($context), 'alert_eligible' => true]);
                if (Carbon::parse($incident->started_at)->lte(now()->subSeconds(config('telegram.debounce')))) {
                    $q->whereNull('confirmed_at')->update(['confirmed_at' => now()]);
                }
            } elseif ($incident) {
                $q->update(['status' => 'RESOLVED', 'resolved_at' => now(), 'context' => json_encode($context)]);
            }
        }
    }
}
