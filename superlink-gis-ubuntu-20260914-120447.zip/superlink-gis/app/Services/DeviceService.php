<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Device;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DeviceService
{
    public function create(array $data): Device
    {
        return DB::transaction(function () use ($data) {
            $device = Device::create([...$data, 'status' => 'IN_STOCK']);
            $this->record($device, 'RECEIVE', null, null, $data['notes'] ?? null);
            return $device;
        });
    }

    public function transition(Device $device, array $data): void
    {
        DB::transaction(function () use ($device, $data) {
            // Lock the customer before the device, matching customer updates/deletion.
            $customerId = $data['action'] === 'ASSIGN' ? $data['customer_id'] : $device->customer_id;
            $customer = $customerId ? Customer::withTrashed()->whereKey($customerId)->lockForUpdate()->firstOrFail() : null;
            $device = Device::whereKey($device->id)->lockForUpdate()->firstOrFail();
            $old = $device->toArray();
            $action = $data['action'];
            if ($action === 'ASSIGN') {
                $this->ensure($device->status === 'IN_STOCK', 'Hanya perangkat dalam stok yang dapat dipasang.');
                $this->ensure($customer && ! $customer->trashed(), 'Pelanggan tidak tersedia.');
                if ($device->type === 'ONT') {
                    $this->ensure(! Device::where('customer_id', $customer->id)->where('type', 'ONT')->exists(), 'Pelanggan sudah memiliki ONT. Kembalikan perangkat lama terlebih dahulu.');
                    $this->ensure(! $customer->ont_serial_number || strcasecmp($customer->ont_serial_number, $device->serial_number) === 0, 'Serial ONT pelanggan berbeda. Cocokkan data ONT lama terlebih dahulu.');
                    $this->ensure(! Customer::withTrashed()->where('id', '!=', $customer->id)->whereRaw('upper(ont_serial_number) = ?', [$device->serial_number])->exists(), 'Serial ONT digunakan pelanggan lain.');
                    $before = $customer->toArray();
                    $customer->update(['ont_serial_number' => $device->serial_number, 'ont_model' => $device->model, 'ont_vendor' => $device->vendor]);
                    AuditService::record('Update', 'Customer', $customer->id, $before, $customer->toArray());
                }
                $device->fill(['status' => 'INSTALLED', 'customer_id' => $customer->id, 'location' => null]);
            } elseif ($action === 'RETURN') {
                $this->ensure($device->status === 'INSTALLED' && $customer && $device->customer_id === $customer->id, 'Penempatan telah berubah. Muat ulang halaman.');
                if ($device->type === 'ONT') {
                    $before = $customer->toArray();
                    $customer->update(['ont_serial_number' => null, 'ont_model' => null, 'ont_vendor' => null]);
                    AuditService::record('Update', 'Customer', $customer->id, $before, $customer->toArray());
                }
                $device->fill(['status' => $data['status'], 'customer_id' => null, 'location' => $data['location']]);
            } else {
                $this->ensure($device->status !== 'INSTALLED', 'Kembalikan perangkat dari pelanggan terlebih dahulu.');
                $this->ensure($device->status !== $data['status'], 'Status perangkat tidak berubah.');
                $device->fill(['status' => $data['status'], 'location' => $data['location']]);
            }
            $device->save();
            $this->record($device, $action, $old, $customer?->id, $data['notes'] ?? null);
        }, 3);
    }

    private function ensure(bool $condition, string $message): void
    {
        if (! $condition) {
            throw ValidationException::withMessages(['device' => $message]);
        }
    }

    private function record(Device $device, string $action, ?array $old, ?string $customerId, ?string $notes): void
    {
        DB::table('device_movements')->insert(['device_id' => $device->id, 'action' => $action, 'from_status' => $old['status'] ?? null, 'to_status' => $device->status, 'customer_id' => $customerId, 'user_id' => auth()->id(), 'notes' => $notes, 'created_at' => now()]);
        AuditService::record($action, 'Device', $device->id, $old, $device->toArray());
    }
}
