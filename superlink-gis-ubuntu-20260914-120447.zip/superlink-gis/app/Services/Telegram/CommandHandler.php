<?php

namespace App\Services\Telegram;

use App\Services\Monitoring\MonitoringSnapshot;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;

class CommandHandler
{
    public function handle(array $update): void
    {
        $callback = $update['callback_query'] ?? null;
        $message = $callback['message'] ?? $update['message'] ?? [];
        $user = (string) ($callback['from']['id'] ?? $message['from']['id'] ?? '');
        $chat = (string) ($message['chat']['id'] ?? '');
        if (! app(Authorization::class)->allowed($user, $chat)) {
            Log::notice('Telegram access denied', ['actor_hash' => hash('sha256', $user.':'.$chat)]);

            return;
        }
        $limit = 'telegram-command:'.$user;
        if (RateLimiter::tooManyAttempts($limit, 20)) {
            return;
        }
        RateLimiter::hit($limit, 60);
        if ($callback) {
            try {
                app(Transport::class)->call('answerCallbackQuery', ['callback_query_id' => $callback['id']]);
            } catch (\RuntimeException) {
                // Expired callback acknowledgements must not block the update queue.
                Log::notice('Telegram callback acknowledgement unavailable');
            }
            $data = $callback['data'] ?? '';
            if (preg_match('/^(ack|incident):(\d+)$/', $data, $matches)) {
                if ($matches[1] === 'ack') {
                    DB::table('monitoring_incidents')->where('id', $matches[2])->where('status', 'OPEN')->whereNotNull('confirmed_at')->whereNull('resolved_at')
                        ->update(['status' => 'ACKNOWLEDGED', 'acknowledged_by' => $user, 'acknowledged_at' => now()]);
                }
                $incident = DB::table('monitoring_incidents')->whereNotNull('confirmed_at')->find($matches[2]);
                $buttons = [];
                if ($incident) {
                    $context = json_decode($incident->context, true);
                    if (isset($context['key'])) {
                        $buttons[] = [['text' => 'Status perangkat sekarang', 'callback_data' => 'detail:'.substr(hash('sha256', $context['key']), 0, 40)]];
                    }
                    if ($incident->status === 'OPEN') {
                        $buttons[] = [['text' => 'Acknowledge', 'callback_data' => 'ack:'.$incident->id]];
                    }
                }
                $this->send($chat, $incident ? app(Formatter::class)->incident($incident, (bool) $incident->resolved_at) : 'Incident tidak ditemukan.', $buttons);

                return;
            }
        }
        $snapshot = app(MonitoringSnapshot::class)->read();
        $rows = collect($snapshot['rows']);
        if ($callback) {
            $r = $rows->first(fn ($r) => 'detail:'.substr(hash('sha256', $r['key']), 0, 40) === ($callback['data'] ?? ''));
            $this->send($chat, $r ? app(Formatter::class)->detail($r) : 'Data sudah berubah. Ulangi pencarian.');

            return;
        }
        $text = mb_substr(trim($message['text'] ?? ''), 0, 500);
        if (! preg_match('/^\/(\w+)(?:@\w+)?(?:\s+(.*))?$/us', $text, $parts)) {
            $this->send($chat, 'Gunakan /help untuk daftar command.');

            return;
        }
        $command = strtolower($parts[1]);
        $query = mb_strtolower(trim($parts[2] ?? ''));
        if (in_array($command, ['start', 'help'])) {
            $this->send($chat, "<b>📡 SUPERLINK MONITORING</b>\n\n/status — ringkasan jaringan\n/customer nama atau ID\n/pppoe username\n/onu deskripsi atau serial\n/olt nama OLT\n/pon nama-OLT 0/1/2\n/offline\n/warning\n/alarm\n/incidents\n\nData berasal dari snapshot monitoring. Waktu dalam WIB. Bot hanya membaca data dan acknowledge incident.");

            return;
        }
        if ($command === 'alarm') {
            $this->send($chat, 'Arsip alarm aktif CDATA belum tersedia di database existing. Riwayat ont_events adalah perubahan status polling, bukan alarm aktif. Gunakan /incidents untuk gangguan terdeteksi.');

            return;
        }
        if ($command === 'incidents') {
            $incidents = DB::table('monitoring_incidents')->whereNotNull('confirmed_at')->whereNull('resolved_at')->orderByDesc('id')->limit(10)->get();
            $buttons = $incidents->map(fn ($i) => [['text' => 'INC-'.$i->id.' '.$i->kind.' · '.$i->status, 'callback_data' => 'incident:'.$i->id]])->all();
            $this->send($chat, '🚨 INCIDENT AKTIF — maksimal 10 terbaru'.($incidents->isEmpty() ? "\nTidak ada incident aktif." : ''), $buttons);

            return;
        }
        if ($command === 'status') {
            $customers = $rows->where('type', 'CUSTOMER');
            $olts = $rows->where('type', 'OLT');
            $f = app(Formatter::class);
            $summary = $f->fields('📊 STATUS JARINGAN', ['Pelanggan GIS' => $customers->count(), 'PPPoE online' => $customers->where('pppoe', 'ONLINE')->count(), 'PPPoE offline' => $customers->where('pppoe', 'OFFLINE')->count(), 'PPPoE unknown' => $customers->where('pppoe', 'UNKNOWN')->count(), 'OLT online' => $olts->where('state', 'ONLINE')->count(), 'OLT offline' => $olts->where('state', 'OFFLINE')->count(), 'OLT unknown' => $olts->where('state', 'UNKNOWN')->count()]);
            foreach ($customers->groupBy(fn ($r) => $r['pop'] ?: 'POP belum dipetakan')->take(10) as $pop => $members) {
                $summary .= "\n\n".$f->fields($pop, ['Pelanggan' => $members->count(), 'PPPoE offline' => $members->where('pppoe', 'OFFLINE')->count(), 'PPPoE unknown' => $members->where('pppoe', 'UNKNOWN')->count()]);
            }
            $this->send($chat, $summary);

            return;
        }
        $types = ['customer' => 'CUSTOMER', 'pppoe' => 'CUSTOMER', 'onu' => 'ONU', 'olt' => 'OLT', 'pon' => 'ONU'];
        if (isset($types[$command])) {
            if ($query === '') {
                $this->send($chat, 'Masukkan pencarian, contoh /'.$command.' '.($command === 'pon' ? 'OLT-CINANGKA-01 0/1/2' : 'Budi'));

                return;
            }
            $rows = $rows->where('type', $types[$command]);
            if ($command === 'pon') {
                $args = preg_split('/\s+/', $query);
                $pon = array_pop($args);
                $olt = implode(' ', $args);
                $rows = $rows->filter(fn ($r) => $olt !== '' && mb_strtolower($r['pon'] ?? '') === $pon && str_contains(mb_strtolower($r['olt'] ?? ''), $olt));
            } else {
                $rows = $rows->filter(fn ($r) => str_contains(mb_strtolower(implode(' ', array_intersect_key($r, array_flip($command === 'pppoe' ? ['username'] : ['name', 'sn', 'customer_code', 'username', 'olt'])))), $query));
            }
        } elseif ($command === 'offline') {
            $rows = $rows->filter(fn ($r) => $r['state'] === 'OFFLINE' || ($r['pppoe'] ?? '') === 'OFFLINE');
        } elseif ($command === 'warning') {
            $rows = $rows->filter(fn ($r) => $r['type'] === 'ONU' && $r['state'] === 'ONLINE' && is_numeric($r['rx']) && (float) $r['rx'] < config('telegram.rx_warning'));
        } else {
            $this->send($chat, 'Command tidak dikenal. Gunakan /help.');

            return;
        }
        if ($rows->count() === 1) {
            $this->send($chat, app(Formatter::class)->detail($rows->first()));
        } else {
            $buttons = $rows->take(10)->map(fn ($r) => [['text' => mb_substr($r['name'].' · '.$r['state'], 0, 60), 'callback_data' => 'detail:'.substr(hash('sha256', $r['key']), 0, 40)]])->values()->all();
            $this->send($chat, $rows->isEmpty() ? 'Tidak ada hasil yang sesuai.' : '🔎 Ditemukan '.$rows->count().' hasil. Menampilkan maksimal 10; persempit pencarian untuk hasil lainnya.', $buttons);
        }
    }

    private function send(string $chat, string $text, array $buttons = []): void
    {
        app(Transport::class)->send($chat, $text, $buttons);
    }
}
