<?php

namespace App\Services\Telegram;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class AlertSender
{
    public function tick(): void
    {
        $chat = config('telegram.chat_id');
        if (! config('telegram.enabled') || ! $chat || ! in_array($chat, config('telegram.allowed_chats'), true)) {
            return;
        }
        $lock = Cache::lock('telegram-alerts', 120);
        if (! $lock->get()) {
            return;
        }
        try {
            $rows = DB::table('monitoring_incidents')->whereNotNull('confirmed_at')->where(fn ($q) => $q->where(fn ($q) => $q->whereNull('notified_at')->whereNull('resolved_at')->where('alert_eligible', true))->orWhere(fn ($q) => $q->whereNotNull('notified_at')->whereNotNull('resolved_at')->whereNull('recovery_at')))->orderBy('id')->limit(3)->get();
            foreach ($rows as $r) {
                $recovery = (bool) $r->resolved_at;
                // Claim before network IO: ambiguous network failures cannot duplicate a recovery.
                DB::table('monitoring_incidents')->where('id', $r->id)->update([$recovery ? 'recovery_at' : 'notified_at' => now(), 'delivery_status' => 'ATTEMPTED']);
                try {
                    app(Transport::class)->send($chat, app(Formatter::class)->incident($r, $recovery), [[['text' => 'Detail', 'callback_data' => 'incident:'.$r->id]], ...($recovery ? [] : [[['text' => 'Acknowledge', 'callback_data' => 'ack:'.$r->id]]])]);
                    DB::table('monitoring_incidents')->where('id', $r->id)->update(['delivery_status' => 'SENT']);
                } catch (\RuntimeException $e) {
                    DB::table('monitoring_incidents')->where('id', $r->id)->update(['delivery_status' => 'UNKNOWN']);
                    throw $e;
                }
            }
        } finally {
            $lock->release();
        }
    }
}
