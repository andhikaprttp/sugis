<?php

namespace App\Services\Telegram;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class Poller
{
    public function tick(): void
    {
        $lock = Cache::lock('telegram-poller', 300);
        if (! $lock->get()) {
            return;
        }
        try {
            DB::table('telegram_state')->insertOrIgnore(['id' => 1, 'update_offset' => 0]);
            $offset = DB::table('telegram_state')->where('id', 1)->value('update_offset');
            $updates = app(Transport::class)->call('getUpdates', ['offset' => (int) $offset, 'timeout' => 0, 'limit' => 3, 'allowed_updates' => ['message', 'callback_query']]);
            foreach ($updates as $update) {
                app(CommandHandler::class)->handle($update);
                DB::table('telegram_state')->where('id', 1)->update(['update_offset' => $update['update_id'] + 1]);
            }
        } finally {
            $lock->release();
        }
    }
}
