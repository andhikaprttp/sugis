<?php

namespace App\Services\Telegram;

use Carbon\Carbon;

class Formatter
{
    public function escape(mixed $value): string
    {
        return htmlspecialchars(mb_substr((string) $value, 0, 300), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public function time(?string $value): string
    {
        return $value ? Carbon::parse($value)->timezone('Asia/Jakarta')->format('d M Y H:i:s').' WIB' : 'Belum tersedia';
    }

    public function fields(string $title, array $fields): string
    {
        $lines = ['<b>'.$this->escape(mb_substr($title, 0, 100)).'</b>'];
        foreach ($fields as $label => $value) {
            if ($value !== null && $value !== '') {
                $lines[] = $this->escape($label).' : '.$this->escape($value);
            }
        }

        return implode("\n", $lines);
    }

    public function detail(array $r): string
    {
        $text = $this->fields($r['type'] === 'OLT' ? '🏢 STATUS OLT' : '👤 INFORMASI PELANGGAN / ONT', [
            'Nama' => $r['name'], 'Customer ID' => $r['customer_code'] ?? null, 'Paket' => $r['package'] ?? null,
            'POP' => $r['pop'] ?? null, 'ODP' => $r['odp'] ?? null,
        ]);
        if (isset($r['pppoe'])) {
            $text .= "\n\n".$this->fields('🌐 PPPoE', ['Username' => $r['username'] ?? null, 'Status' => $this->status($r['pppoe']), 'IP terakhir' => $r['ip'] ?? null, 'Uptime teramati' => $r['uptime'] ?? null, 'Pengamatan PPPoE' => $this->time($r['pppoe_observed_at'] ?? null)]);
        }

        return $text."\n\n".$this->fields('📡 '.($r['type'] === 'CUSTOMER' ? 'ONU / ONT' : $r['type']), ['Status' => $this->status($r['state']), 'SN' => $r['sn'] ?? null, 'Model' => $r['model'] ?? null, 'IP OLT' => $r['type'] === 'OLT' ? ($r['ip'] ?? null) : null, 'OLT' => $r['olt'] ?? null, 'PON' => $r['pon'] ?? null, 'ONU ID' => $r['onu'] ?? null, 'RX dBm' => $r['rx'] ?? null, 'TX dBm' => $r['tx'] ?? null, 'ONU online' => $r['online_count'] ?? null, 'ONU total' => $r['onu_count'] ?? null, 'Pengamatan' => $this->time($r['observed_at'] ?? null)]);
    }

    public function status(string $state): string
    {
        return match ($state) {
            'ONLINE' => '🟢 ONLINE', 'OFFLINE' => '🔴 OFFLINE', 'WARNING' => '🟡 WARNING', default => '⚪ UNKNOWN'
        };
    }

    public function incident(object $incident, bool $recovery = false): string
    {
        $r = json_decode($incident->context, true);
        $title = $recovery ? '🟢 PULIH / KEMBALI ONLINE' : ($incident->severity === 'WARNING' ? '🟡 PERINGATAN' : '🔴 GANGGUAN');

        return $this->fields($title.' — '.$incident->kind, [
            'Incident' => 'INC-'.$incident->id, 'Status' => $incident->status,
            'Nama' => $r['name'], 'PPPoE' => $r['username'] ?? null, 'SN' => $r['sn'] ?? null,
            'Customer ID' => $r['customer_code'] ?? null, 'POP' => $r['pop'] ?? null, 'ODP' => $r['odp'] ?? null,
            'Status ONU teramati' => isset($r['state']) && ($r['type'] ?? '') !== 'OLT' ? $this->status($r['state']) : null,
            'Status PPPoE teramati' => isset($r['pppoe']) ? $this->status($r['pppoe']) : null,
            'OLT' => $r['olt'] ?? null, 'PON' => $r['pon'] ?? null,
            'Terdampak' => $r['affected'] ?? null, 'RX dBm' => $r['rx'] ?? null,
            'Kemungkinan' => $recovery ? null : ($r['diagnosis'] ?? null),
            'Mulai terdeteksi' => $this->time($incident->started_at),
            'Pulih' => $recovery ? $this->time($incident->resolved_at) : null,
            'Durasi' => $recovery ? Carbon::parse($incident->started_at)->diff(Carbon::parse($incident->resolved_at))->format('%ad %hh %im %ss') : null,
        ]);
    }
}
