<?php

namespace App\Services\Telegram;

class Authorization
{
    public function allowed(string $user, string $chat): bool
    {
        return in_array($user, config('telegram.allowed_users'), true)
            && in_array($chat, config('telegram.allowed_chats'), true);
    }
}
