<?php

namespace App\Services\Telegram;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class Transport
{
    public function call(string $method, array $payload = []): mixed
    {
        if (! config('telegram.enabled') || ! config('telegram.token')) {
            throw new RuntimeException('Telegram belum dikonfigurasi.');
        }
        try {
            $response = Http::connectTimeout(5)->timeout(20)->withOptions(['allow_redirects' => false])
                ->post('https://api.telegram.org/bot'.config('telegram.token').'/'.$method, $payload);
        } catch (\Throwable) {
            // Never retain the original exception: its URL contains the bot token.
            throw new RuntimeException('Koneksi Telegram gagal; pengiriman belum terkonfirmasi.');
        }
        if (! $response->successful() || $response->json('ok') !== true) {
            throw new RuntimeException('Telegram menolak permintaan (HTTP '.$response->status().').');
        }

        return $response->json('result');
    }

    public function send(string $chat, string $text, array $buttons = []): void
    {
        $this->call('sendMessage', ['chat_id' => $chat, 'text' => $text, 'parse_mode' => 'HTML',
            ...($buttons ? ['reply_markup' => ['inline_keyboard' => $buttons]] : [])]);
    }
}
