<?php

namespace App\Services\Survey;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Models\Setting;
use App\Models\Survey;
use App\Services\AuditService;
use App\Services\Gis\GeometryService;
use App\Services\Network\PortService;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SurveyService
{
    public static function estimate(float $distance, float $allowance): float
    {
        if ($distance < 0 || $allowance < 0 || $allowance > 100) {
            throw new \InvalidArgumentException('Invalid estimate');
        }

return round($distance * (1 + $allowance / 100), 2);
    }

    public function nearest(float $lng, float $lat): array
    {
        if (abs($lng) > 180 || abs($lat) > 90) {
            throw ValidationException::withMessages(['coordinates' => 'Koordinat di luar rentang']);
        }

        return DB::select(<<<'SQL'
SELECT g.id,g.code,g.name,ST_Distance(g.geometry::geography,p.g::geography) AS distance,o.capacity,
(SELECT count(*) FROM odp_ports WHERE odp_id=o.id AND status='AVAILABLE') AS available,
dc.code AS odc,pg.code AS pop,ST_AsGeoJSON(g.geometry)::json AS geometry
FROM odps o JOIN gis_objects g ON g.id=o.id
LEFT JOIN odcs d ON d.id=o.odc_id LEFT JOIN gis_objects dc ON dc.id=d.id
LEFT JOIN gis_objects pg ON pg.id=d.pop_id
CROSS JOIN (SELECT ST_SetSRID(ST_MakePoint(?,?),4326) AS g) p
WHERE g.deleted_at IS NULL AND g.status='ACTIVE' AND ST_DWithin(g.geometry::geography,p.g::geography,?)
AND EXISTS(SELECT 1 FROM odp_ports WHERE odp_id=o.id AND status='AVAILABLE') ORDER BY distance LIMIT 20
SQL, [$lng, $lat, Setting::findOrFail(1)->search_radius_m]);
    }

    public function create(array $data): Survey
    {
        return DB::transaction(function () use ($data) {
            $customer = Customer::findOrFail($data['customer_id']);
            $s = Survey::create(['customer_id' => $customer->id, 'surveyor_id' => auth()->id(), 'notes' => $data['notes'] ?? null, 'allowance' => Setting::findOrFail(1)->cable_allowance_percent]);
            AuditService::record('Create', 'Survey', $s->id, null, $s->toArray(), 'SURVEY');

            return $s;
        });
    }

    public function route(Survey $survey, array $nodes): Survey
    {
        return DB::transaction(function () use ($survey, $nodes) {
            $s = Survey::whereKey($survey->id)->lockForUpdate()->firstOrFail();
            if (in_array($s->status, ['APPROVED', 'INSTALLATION', 'INSTALLED', 'CANCELLED'])) {
                throw ValidationException::withMessages(['status' => 'Route tidak dapat diubah setelah approval']);
            }
            if (count($nodes) < 2 || count($nodes) > 200) {
                throw ValidationException::withMessages(['nodes' => 'Pilih 2 hingga 200 node']);
            }
            $objects = GisObject::withGeometry()->whereIn('id', $nodes)->whereIn('object_type', GeometryService::NODES)->get()->keyBy('id');
            if ($objects->count() !== count(array_unique($nodes)) || ($objects[$nodes[0]]->object_type ?? null) !== 'ODP' || end($nodes) !== $s->customer->gis_object_id) {
                throw ValidationException::withMessages(['nodes' => 'Route harus mulai ODP dan berakhir di customer survey']);
            }
            $coords = [];
            foreach ($nodes as $i => $id) {
                $g = $objects[$id]->geojson;
                if (! $g) {
                    throw ValidationException::withMessages(['nodes' => 'Node belum memiliki lokasi']);
                }if ($i > 0 && $i < count($nodes) - 1 && ! in_array($objects[$id]->object_type, ['POLE', 'CLOSURE'])) {
                    throw ValidationException::withMessages(['nodes' => 'Node perantara harus tiang/closure']);
                }$coords[] = $g['coordinates'];
            }
            $geo = ['type' => 'LineString', 'coordinates' => $coords];
            app(GeometryService::class)->validate($geo, 'FIBER_ROUTE');
            $distance = DB::selectOne('SELECT ST_Length(ST_SetSRID(ST_GeomFromGeoJSON(?),4326)::geography) d', [json_encode($geo)])->d;
            $straight = DB::selectOne('SELECT ST_Distance(a.geometry::geography,b.geometry::geography) d FROM gis_objects a,gis_objects b WHERE a.id=? AND b.id=?', [$nodes[0], end($nodes)])->d;
            $allowance = Setting::findOrFail(1)->cable_allowance_percent;
            $old = $s->toArray();
            $s->update(['odp_id' => $nodes[0], 'route_nodes' => $nodes, 'straight_distance' => $straight, 'route_distance' => $distance, 'allowance' => $allowance, 'estimated_cable' => self::estimate($distance, $allowance), 'status' => 'SURVEY']);
            app(GeometryService::class)->save('surveys', $s->id, $geo, 'route');
            AuditService::record('Route', 'Survey', $s->id, $old, $s->toArray(), 'SURVEY');

            return $s;
        });
    }

    public function transition(Survey $survey, string $status, ?int $assigned = null): Survey
    {
        return DB::transaction(function () use ($survey, $status, $assigned) {
            $s = Survey::whereKey($survey->id)->lockForUpdate()->firstOrFail();
            $allowed = ['DRAFT' => ['SURVEY', 'CANCELLED'], 'SURVEY' => ['FEASIBLE', 'NOT_FEASIBLE', 'WAITING_APPROVAL', 'CANCELLED'], 'FEASIBLE' => ['WAITING_APPROVAL', 'CANCELLED'], 'NOT_FEASIBLE' => ['SURVEY', 'CANCELLED'], 'WAITING_APPROVAL' => ['APPROVED', 'NOT_FEASIBLE', 'CANCELLED'], 'APPROVED' => ['INSTALLATION', 'CANCELLED'], 'INSTALLATION' => ['INSTALLED', 'CANCELLED']];
            if (! in_array($status, $allowed[$s->status] ?? [])) {
                throw ValidationException::withMessages(['status' => 'Transisi status tidak valid']);
            }
            if (in_array($status, ['FEASIBLE', 'WAITING_APPROVAL', 'APPROVED']) && (! $s->odp_id || ! $s->route_distance)) {
                throw ValidationException::withMessages(['status' => 'Lengkapi route sebelum approval']);
            }
            if (in_array($status, ['APPROVED', 'INSTALLATION']) && ! OdpPort::where('odp_id', $s->odp_id)->where(fn ($q) => $q->where('status', 'AVAILABLE')->orWhere('reserved_for', $s->id))->exists()) {
                throw ValidationException::withMessages(['status' => 'Tidak ada port tersedia']);
            }
            $old = $s->toArray();
            if ($status === 'INSTALLED') {
                $port = OdpPort::where('reserved_for', $s->id)->first();
                if (! $port) {
                    throw ValidationException::withMessages(['status' => 'Reservasi port diperlukan']);
                }app(PortService::class)->assign($port, $s->customer, $s, 'SURVEY');
                $s->customer->update(['status' => 'ACTIVE', 'installation_date' => today(), 'activation_date' => today()]);
                $s->customer->object->update(['object_type' => 'CUSTOMER', 'status' => 'ACTIVE']);
            }
            if ($status === 'CANCELLED') {
                foreach (OdpPort::where('reserved_for', $s->id)->get() as $p) {
                    app(PortService::class)->release($p);
                }
            }
            $s->update(['status' => $status, 'assigned_to' => $assigned ?? $s->assigned_to]);
            AuditService::record($status === 'APPROVED' ? 'Survey Approval' : 'Update','Survey',$s->id,$old,$s->toArray(),'SURVEY');

            return $s;
        });
    }
}
