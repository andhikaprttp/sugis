<?php

namespace App\Services\Gis;

use DOMDocument;
use DOMXPath;
use InvalidArgumentException;

class KmlParserService
{
    public function parse(string $xml): array
    {
        if (strlen($xml) > 512 * 1024 * 1024 || preg_match('/<!DOCTYPE|<!ENTITY/i', $xml)) {
            throw new InvalidArgumentException('KML terlalu besar atau mengandung DTD/entity terlarang');
        }
        $previous = libxml_use_internal_errors(true);
        $doc = new DOMDocument;
        try {
            if (! $doc->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS)) {
                throw new InvalidArgumentException('XML KML rusak');
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
        if ($doc->documentElement->localName !== 'kml') {
            throw new InvalidArgumentException('Root XML harus kml');
        }$x = new DOMXPath($doc);
        $rows = [];
        $counts = ['Point' => 0, 'LineString' => 0, 'Polygon' => 0, 'Folders' => $x->query('//*[local-name()="Folder"]')->length];
        foreach ($x->query('//*[local-name()="Placemark"]') as $p) {
            $name = trim($x->evaluate('string(./*[local-name()="name"])', $p)) ?: 'Unnamed';
            $description = strip_tags($x->evaluate('string(./*[local-name()="description"])', $p));
            $folders = [];
            for ($a = $p->parentNode; $a; $a = $a->parentNode) {
                if ($a->localName === 'Folder') {
                    array_unshift($folders, trim($x->evaluate('string(./*[local-name()="name"])', $a)));
                }
            }
            $geometries = $x->query('.//*[local-name()="Point" or local-name()="LineString" or local-name()="Polygon"]', $p);
            if (! $geometries->length) {
                throw new InvalidArgumentException('Placemark tanpa geometry yang didukung: '.$name);
            }
            foreach ($geometries as $g) {
                $type = $g->localName;
                if ($type === 'Polygon') {
                    $coords = [];
                    foreach ($x->query('./*[local-name()="outerBoundaryIs"]/*[local-name()="LinearRing"]/*[local-name()="coordinates"] | ./*[local-name()="innerBoundaryIs"]/*[local-name()="LinearRing"]/*[local-name()="coordinates"]', $g) as $ring) {
                        $coords[] = $this->coordinates($ring->textContent);
                    }if (! $coords) {
                        throw new InvalidArgumentException('Polygon tanpa ring');
                    }
                } else {
                    $coords = $this->coordinates($x->evaluate('string(./*[local-name()="coordinates"])', $g));
                    if ($type === 'Point') {
                        if (count($coords) !== 1) {
                            throw new InvalidArgumentException('Point harus satu koordinat');
                        }$coords = $coords[0];
                    }
                }
                $rows[] = ['name' => mb_substr($name, 0, 255), 'original_name' => mb_substr($name, 0, 255), 'description' => mb_substr($description, 0, 10000), 'geometry' => ['type' => $type, 'coordinates' => $coords], 'object_type' => 'UNCLASSIFIED', 'detected_type' => 'UNCLASSIFIED', 'folders' => $folders];
                $counts[$type]++;
                if (count($rows) > 20000) {
                    throw new InvalidArgumentException('Maksimum 20000 objek per file');
                }
            }
        }

        return ['objects' => $rows, 'counts' => $counts];
    }

    private function coordinates(string $s): array
    {
        $out = [];
        foreach (preg_split('/\s+/', trim($s), -1, PREG_SPLIT_NO_EMPTY) as $tuple) {
            $v = explode(',', $tuple);
            if (count($v) < 2 || ! is_numeric($v[0]) || ! is_numeric($v[1]) || ! is_finite((float) $v[0]) || ! is_finite((float) $v[1]) || abs((float) $v[0]) > 180 || abs((float) $v[1]) > 90) {
                throw new InvalidArgumentException('Koordinat KML tidak valid');
            }$out[] = [(float) $v[0], (float) $v[1]];
        }if (! $out) {
            throw new InvalidArgumentException('Koordinat KML kosong');
        }

        return $out;
    }
}
