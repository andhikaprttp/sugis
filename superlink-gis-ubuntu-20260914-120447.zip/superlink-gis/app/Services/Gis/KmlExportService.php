<?php

namespace App\Services\Gis;

use App\Models\GisObject;
use App\Models\Odp;
use Illuminate\Support\Facades\DB;

class KmlExportService
{
    public function generate(iterable $objects): string
    {
        $xml = new \XMLWriter;
        $xml->openMemory();
        $xml->startDocument('1.0', 'UTF-8');
        $xml->startElementNS(null, 'kml', 'http://www.opengis.net/kml/2.2');
        $xml->startElement('Document');
        $xml->writeElement('name', 'Superlink FTTH Network');
        foreach ($objects as $o) {
            $geo = $o->geojson;
            if (! $geo) {
                continue;
            }$xml->startElement('Placemark');
            $xml->writeElement('name', $o->code ?: $o->name);
            $desc = $o->description ?? '';
            if ($o->object_type === 'ODP') {
                $odp = Odp::with('odc.object', 'odc.pop.object')->find($o->id);
                $a = $odp->availability();
                $desc = "Capacity: {$a['capacity']} | Used: {$a['occupied']} | Available: {$a['available']} | ODC: ".($odp->odc?->object?->code ?? '').' | POP: '.($odp->odc?->pop?->object?->code ?? '');
            }$xml->writeElement('description', $desc.' | Status: '.$o->status);
            $xml->startElement($geo['type']);
            $c = $geo['coordinates'];
            if ($geo['type'] === 'Polygon') {
                foreach ($c as $i => $ring) {
                    $xml->startElement($i ? 'innerBoundaryIs' : 'outerBoundaryIs');
                    $xml->startElement('LinearRing');
                    $xml->writeElement('coordinates', $this->coordinates($ring));
                    $xml->endElement();
                    $xml->endElement();
                }
            } else {
                $xml->writeElement('coordinates', $this->coordinates($geo['type'] === 'Point' ? [$c] : $c));
            }$xml->endElement();
            $xml->endElement();
        }
        $xml->endElement();
        $xml->endElement();
        $xml->endDocument();

        return $xml->outputMemory();
    }

    private function coordinates(array $c): string
    {
        return implode(' ', array_map(fn ($p) => $p[0].','.$p[1].',0', $c));
    }

    public function query(array $f = [])
    {
        $q = GisObject::withGeometry();
        foreach (['object_type', 'area_id'] as $k) {
            if (! empty($f[$k])) {
                $q->where($k, $f[$k]);
            }
        }if (! empty($f['ids'])) {
            $q->whereIn('id', $f['ids']);
        }if (! empty($f['pop_id'])) {
            $pop = $f['pop_id'];
            $q->where(function ($q) use ($pop) {
                $q->where('id', $pop)->orWhere('pop_id', $pop)->orWhereIn('id', DB::table('odcs')->where('pop_id', $pop)->select('id'))->orWhereIn('id', DB::table('odps')->whereIn('odc_id', DB::table('odcs')->where('pop_id', $pop)->select('id'))->select('id'));
            });
        }if (! empty($f['odc_id'])) {
            $q->where(fn ($q) => $q->where('id', $f['odc_id'])->orWhereIn('id', DB::table('odps')->where('odc_id', $f['odc_id'])->select('id')));
        }if (! empty($f['odp_id'])) {
            $q->where('id',$f['odp_id']);
        }

return $q;
    }
}
