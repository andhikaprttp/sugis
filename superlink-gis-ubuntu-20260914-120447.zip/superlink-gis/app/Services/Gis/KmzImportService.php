<?php

namespace App\Services\Gis;

use InvalidArgumentException;
use ZipArchive;

class KmzImportService
{
    public function inspectZip(string $path): ZipArchive
    {
        $zip = new ZipArchive;
        if ($zip->open($path) !== true) {
            throw new InvalidArgumentException('ZIP/KMZ rusak');
        }$size = 0;
        if ($zip->numFiles > 5000) {
            $zip->close();
            throw new InvalidArgumentException('Terlalu banyak entry ZIP');
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $s = $zip->statIndex($i);
            $name = str_replace('\\', '/', $s['name']);
            $size += $s['size'];
            if (str_starts_with($name, '/') || preg_match('~(^|/)\.\.(/|$)|^[A-Za-z]:|\x00~', $name) || $size > 512 * 1024 * 1024 || ($s['size'] > 1024 * 1024 && $s['size'] / max(1, $s['comp_size']) > 200)) {
                $zip->close();
                throw new InvalidArgumentException('ZIP tidak aman: traversal, rasio kompresi, atau ukuran ekstraksi');
            }
        }

        return $zip;
    }

    public function parse(string $path, string $filename): array
    {
        if (filesize($path) > 256 * 1024 * 1024) {
            throw new InvalidArgumentException('Maksimum upload 256 MB');
        }$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext === 'kml') {
            return app(KmlParserService::class)->parse(file_get_contents($path));
        }if ($ext !== 'kmz') {
            throw new InvalidArgumentException('Gunakan .kml atau .kmz');
        }
        $zip = $this->inspectZip($path);
        $all = ['objects' => [], 'counts' => ['Point' => 0, 'LineString' => 0, 'Polygon' => 0, 'Folders' => 0]];
        $found = false;
        try {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                if (strtolower(pathinfo($zip->getNameIndex($i), PATHINFO_EXTENSION)) === 'kml') {
                    $found = true;
                    $parsed = app(KmlParserService::class)->parse($zip->getFromIndex($i));
                    $all['objects'] = array_merge($all['objects'], $parsed['objects']);
                    foreach ($parsed['counts'] as $k => $v) {
                        $all['counts'][$k] += $v;
                    }if (count($all['objects']) > 20000) {
                        throw new InvalidArgumentException('Maksimum 20000 objek');
                    }
                }
            }
        } finally {
            $zip->close();
        }if (! $found) {
            throw new InvalidArgumentException('KMZ tidak berisi KML');
        }

        return $all;
    }
}
