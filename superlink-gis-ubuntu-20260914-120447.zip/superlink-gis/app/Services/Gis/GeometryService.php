<?php

namespace App\Services\Gis;

use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class GeometryService
{
    const TYPES = ['UNCLASSIFIED', 'POP', 'ODC', 'ODP', 'POLE', 'CLOSURE', 'CUSTOMER', 'PROSPECT', 'FIBER_ROUTE', 'AREA', 'OTHER'];

    const NODES = ['POP', 'ODC', 'ODP', 'POLE', 'CLOSURE', 'CUSTOMER', 'PROSPECT'];

    public function validate(?array $g, string $type = 'OTHER'): ?array
    {
        if (! $g) {
            if (in_array($type, ['CUSTOMER', 'PROSPECT'])) {
                return null;
            }$this->fail('Geometri wajib diisi');
        }
        if (! in_array($g['type'] ?? '', ['Point', 'LineString', 'Polygon']) || ! isset($g['coordinates'])) {
            $this->fail('Geometry harus Point, LineString atau Polygon');
        }
        $walk = function ($coords) use (&$walk) {
            if (! is_array($coords) || ! count($coords)) {
                $this->fail('Koordinat kosong');
            }if (is_numeric($coords[0])) {
                if (count($coords) < 2 || ! is_numeric($coords[1]) || ! is_finite((float) $coords[0]) || ! is_finite((float) $coords[1]) || abs($coords[0]) > 180 || abs($coords[1]) > 90) {
                    $this->fail('Longitude/latitude di luar rentang');
                }
            } else {
                foreach ($coords as $c) {
                    $walk($c);
                }
            }
        };
        $walk($g['coordinates']);
        if (in_array($type, self::NODES) && $g['type'] !== 'Point') {
            $this->fail('Objek membutuhkan Point');
        }
        if ($type === 'FIBER_ROUTE' && $g['type'] !== 'LineString') {
            $this->fail('Route membutuhkan LineString');
        }
        if ($type === 'AREA' && $g['type'] !== 'Polygon') {
            $this->fail('Area membutuhkan Polygon');
        }
        try {
            // A malformed imported shape must not abort the surrounding staging transaction.
            $r = DB::transaction(fn () => DB::selectOne('SELECT ST_IsValid(g) AND NOT ST_IsEmpty(g) AS valid FROM (SELECT ST_SetSRID(ST_GeomFromGeoJSON(?),4326) g) q', [json_encode($g, JSON_THROW_ON_ERROR)]));
        } catch (\Throwable $e) {
            $this->fail('Geometri tidak valid');
        }
        if (! $r->valid) {
            $this->fail('Geometri tidak valid');
        }

        return $g;
    }

    private function fail(string $message): never
    {
        throw ValidationException::withMessages(['geometry' => $message]);
    }

    public function save(string $table, string $id, ?array $g, string $column = 'geometry'): void
    {
        if (! in_array($table, ['gis_objects', 'surveys', 'fiber_segments']) || ! in_array($column, ['geometry', 'route'])) {
            throw new \InvalidArgumentException;
        }
        DB::update("UPDATE {$table} SET {$column} = ".($g ? 'ST_SetSRID(ST_GeomFromGeoJSON(?),4326)' : 'NULL').' WHERE id=?', $g ? [json_encode($g), $id] : [$id]);
    }
}
