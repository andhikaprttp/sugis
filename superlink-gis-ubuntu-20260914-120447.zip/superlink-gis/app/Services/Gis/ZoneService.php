<?php

namespace App\Services\Gis;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ZoneService
{
    public const FIELDS = ['zone_level', 'rt', 'rw', 'village', 'district', 'city', 'color'];

    public function metadata(array $data, ?string $id): array
    {
        $existing = $id ? (array) DB::table('coverage_areas')->where('id', $id)->first() : [];
        $values = array_merge(['color' => '#14b8a6', 'zone_level' => null], $existing, array_intersect_key($data, array_flip(self::FIELDS)));
        foreach (['rt', 'rw'] as $field) {
            if (isset($values[$field])) {
                $values[$field] = trim((string) $values[$field]) ?: null;
            }
        }
        if ($values['zone_level'] === 'RW') {
            $values['rt'] = null;
        }
        Validator::make($values, [
            'zone_level' => ['nullable', Rule::in(['RT', 'RW'])],
            'rw' => [Rule::requiredIf(in_array($values['zone_level'], ['RT', 'RW'])), 'nullable', 'regex:/^\d{1,3}$/'],
            'rt' => [Rule::requiredIf($values['zone_level'] === 'RT'), 'nullable', 'regex:/^\d{1,3}$/'],
            'village' => ['nullable', 'string', 'max:255'],
            'district' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'color' => ['required', 'regex:/^#[a-fA-F0-9]{6}$/'],
        ])->validate();
        foreach (['rt', 'rw'] as $field) {
            if (! empty($values[$field])) {
                $values[$field] = str_pad((string) (int) $values[$field], 3, '0', STR_PAD_LEFT);
            }
        }

        return array_intersect_key($values, array_flip(self::FIELDS));
    }

    public function statistics(array $filters): array
    {
        // Customer addresses are authoritative for administrative counts, even without coordinates.
        $q = DB::table('customers as c')->join('gis_objects as g', 'g.id', '=', 'c.gis_object_id')
            ->whereNull('c.deleted_at')->whereNull('g.deleted_at');
        foreach (['city', 'district', 'village'] as $field) {
            if (! empty($filters[$field])) {
                $q->where('c.'.$field, 'ilike', '%'.$filters[$field].'%');
            }
        }
        $normalize = fn ($column) => "CASE WHEN trim(coalesce($column,'')) ~ '^\\d{1,3}$' THEN lpad((trim($column)::integer)::text,3,'0') ELSE nullif(trim($column),'') END";
        $rw = $normalize('c.rw');
        $rt = $normalize('c.rt');
        foreach (['rw' => $rw, 'rt' => $rt] as $field => $sql) {
            if (! empty($filters[$field])) {
                $q->whereRaw("($sql)=?", [str_pad((string) (int) $filters[$field], 3, '0', STR_PAD_LEFT)]);
            }
        }
        $level = ($filters['level'] ?? 'RT') === 'RW' ? 'RW' : 'RT';
        $group = "coalesce(c.city,''), coalesce(c.district,''), coalesce(c.village,''), ($rw)".($level === 'RT' ? ", ($rt)" : '');
        $rows = $q->selectRaw("coalesce(c.city,'') city,coalesce(c.district,'') district,coalesce(c.village,'') village, ($rw) rw,".($level === 'RT' ? "($rt)" : 'NULL')." rt, count(*) total, count(*) FILTER(WHERE c.status='ACTIVE') active, count(*) FILTER(WHERE c.status='SUSPENDED') suspended, count(*) FILTER(WHERE c.status IN ('PROSPECT','SURVEY','WAITING_INSTALLATION')) pending, count(*) FILTER(WHERE c.status IN ('INACTIVE','TERMINATED')) inactive, count(*) FILTER(WHERE g.geometry IS NULL) missing_location")
            ->groupByRaw($group)->orderBy('city')->orderBy('district')->orderBy('village')->orderBy('rw')->when($level === 'RT', fn ($q) => $q->orderBy('rt'))->get();
        $zones = DB::table('coverage_areas as z')->join('gis_objects as g', 'g.id', '=', 'z.id')->whereNull('g.deleted_at')->whereNotNull('z.zone_level')
            ->select('z.*', 'g.name', 'g.code')->selectRaw('(SELECT count(*) FROM customers c JOIN gis_objects p ON p.id=c.gis_object_id WHERE c.deleted_at IS NULL AND p.deleted_at IS NULL AND ST_Covers(g.geometry,p.geometry)) AS spatial_customers')
            ->orderBy('z.rw')->orderBy('z.rt')->get();

        return ['level' => $level, 'rows' => $rows, 'zones' => $zones];
    }
}
