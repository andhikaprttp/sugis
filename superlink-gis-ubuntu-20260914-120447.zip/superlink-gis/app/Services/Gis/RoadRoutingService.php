<?php

namespace App\Services\Gis;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class RoadRoutingService
{
    private function base(): string
    {
        $url = rtrim((string) config('routing.url'), '/');
        $parts = parse_url($url);
        if (! $url || ! $parts || ! in_array($parts['scheme'] ?? '', ['http', 'https'], true) || empty($parts['host']) || isset($parts['user'], $parts['pass']) || isset($parts['query']) || isset($parts['fragment']) || ! in_array($parts['path'] ?? '', ['', '/'], true)) {
            throw new RuntimeException('Layanan routing jalan belum dikonfigurasi.');
        }

        return $url;
    }

    private function profile(): string
    {
        $profile = (string) config('routing.profile');
        if (! in_array($profile, ['driving', 'cycling', 'walking'], true)) {
            throw new RuntimeException('Profil routing tidak didukung.');
        }

        return $profile;
    }

    private function coordinates(array $points): string
    {
        return collect($points)->map(fn ($p) => sprintf('%.6F,%.6F', $p[1], $p[0]))->implode(';');
    }

    public function distances(array $origin, array $destinations): array
    {
        if (! $destinations) {
            return [];
        }
        $points = [$origin, ...$destinations];
        $targets = implode(';', range(1, count($destinations)));
        $data = $this->request('/table/v1/'.$this->profile().'/'.$this->coordinates($points), ['sources' => '0', 'destinations' => $targets, 'annotations' => 'distance']);
        $row = $data['distances'][0] ?? null;
        if (! is_array($row) || count($row) !== count($destinations)) {
            throw new RuntimeException('Layanan routing tidak mengembalikan daftar jarak lengkap.');
        }

        return array_map(fn ($value) => is_numeric($value) && $value >= 0 ? (float) $value : null, $row);
    }

    public function route(array $start, array $end): array
    {
        $data = $this->request('/route/v1/'.$this->profile().'/'.$this->coordinates([$start, $end]), ['overview' => 'full', 'geometries' => 'geojson', 'steps' => 'false']);
        $route = $data['routes'][0] ?? null;
        $coordinates = $route['geometry']['coordinates'] ?? null;
        if (! is_array($coordinates) || count($coordinates) < 2 || count($coordinates) > 10000 || ! is_numeric($route['distance'] ?? null)) {
            throw new RuntimeException('Jalur jalan tidak ditemukan.');
        }
        $points = [];
        foreach ($coordinates as $coordinate) {
            if (! is_array($coordinate) || count($coordinate) < 2 || ! is_numeric($coordinate[0]) || ! is_numeric($coordinate[1])) {
                throw new RuntimeException('Geometri jalur jalan tidak valid.');
            }
            $points[] = [(float) $coordinate[1], (float) $coordinate[0]];
        }
        if (count($points) > 50) {
            $last = count($points) - 1;
            $points = collect(range(0, 49))->map(fn ($index) => $points[(int) round($last * $index / 49)])->all();
        }

        return ['points' => $points, 'distance' => (float) $route['distance']];
    }

    private function request(string $path, array $query): array
    {
        try {
            $response = Http::acceptJson()->connectTimeout(5)->timeout(20)->withOptions(['allow_redirects' => false])->get($this->base().$path, $query);
        } catch (\Throwable $e) {
            throw new RuntimeException('Layanan routing jalan tidak dapat dijangkau.');
        }
        $data = $response->json();
        if (! $response->successful() || ! is_array($data) || ($data['code'] ?? '') !== 'Ok') {
            throw new RuntimeException('Layanan routing jalan tidak menemukan rute.');
        }

        return $data;
    }
}
