<?php

namespace App\Services\Gis;

class KmzExportService
{
    public function write(string $path, string $kml): void
    {
        $z = new \ZipArchive;
        if ($z->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Gagal membuat KMZ');
        }$z->addFromString('doc.kml', $kml);
        $z->close();
    }
}
