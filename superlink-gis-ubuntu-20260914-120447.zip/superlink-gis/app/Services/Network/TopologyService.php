<?php

namespace App\Services\Network;

use App\Models\GisObject;
use App\Services\Gis\GeometryService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class TopologyService
{
    /** An unclassified line can acquire explicit unknown endpoints without assuming they are poles. */
    public function attachEndpoints(GisObject $route, array $geometry, string $source, ?int $actor): void
    {
        $coordinates = $geometry['coordinates'];
        $nodes = [];
        foreach ([$coordinates[0], end($coordinates)] as $i => $p) {
            $node = GisObject::create(['name' => $route->name.' endpoint '.($i + 1), 'object_type' => 'UNCLASSIFIED', 'source' => $source, 'source_filename' => $route->source_filename, 'notes' => 'Unclassified route endpoint; review and classify the physical asset.', 'created_by' => $actor ?? auth()->id(), 'updated_by' => $actor ?? auth()->id()]);
            app(GeometryService::class)->save('gis_objects', $node->id, ['type' => 'Point', 'coordinates' => $p]);
            $nodes[] = $node->id;
        }
        DB::insert('INSERT INTO fiber_segments(id,route_id,sequence,start_node_id,end_node_id,geometry,cable_type,fiber_count,status,created_at,updated_at) VALUES(?,?,?,?,?,ST_SetSRID(ST_GeomFromGeoJSON(?),4326),?,?,?,now(),now())', [(string) Str::uuid(), $route->id, 1, $nodes[0], $nodes[1], json_encode($geometry), 'DROP', 1, 'ACTIVE']);
    }

    public function editRoute(GisObject $route, array $geometry): void
    {
        $segments = DB::table('fiber_segments')->where('route_id', $route->id)->orderBy('sequence')->lockForUpdate()->get();
        if (! $segments->count()) {
            return;
        }
        $line = json_encode($geometry);
        $previous = -1;
        foreach ($segments as $i => $segment) {
            $p = DB::selectOne('SELECT ST_LineLocatePoint(l.g,a.geometry) a,ST_LineLocatePoint(l.g,b.geometry) b,ST_Distance(ST_ClosestPoint(l.g,a.geometry)::geography,a.geometry::geography) da,ST_Distance(ST_ClosestPoint(l.g,b.geometry)::geography,b.geometry::geography) db FROM gis_objects a,gis_objects b,(SELECT ST_SetSRID(ST_GeomFromGeoJSON(?),4326) g) l WHERE a.id=? AND b.id=?', [$line, $segment->start_node_id, $segment->end_node_id]);
            if ($p->da > 1 || $p->db > 1 || $p->a >= $p->b || $p->a < $previous - 0.000001 || ($i === 0 && $p->a > 0.000001) || ($i === $segments->count() - 1 && $p->b < 0.999999)) {
                throw ValidationException::withMessages(['geometry' => 'Jalur harus tetap melalui node topology secara berurutan. Pindahkan node atau pilih ulang node untuk mengubah endpoint.']);
            }
            DB::update('UPDATE fiber_segments SET geometry=ST_LineSubstring(ST_SetSRID(ST_GeomFromGeoJSON(?),4326),?,?),updated_at=now() WHERE id=?', [$line, $p->a, $p->b, $segment->id]);
            $previous = $p->b;
        }
    }

    public function moveNode(string $id): void
    {
        $segments = DB::table('fiber_segments')->where('start_node_id', $id)->orWhere('end_node_id', $id)->lockForUpdate()->get();
        $routes = [];
        foreach ($segments as $segment) {
            DB::update('UPDATE fiber_segments SET geometry=ST_SetPoint(geometry,CASE WHEN start_node_id=? THEN 0 ELSE ST_NPoints(geometry)-1 END,(SELECT geometry FROM gis_objects WHERE id=?)),updated_at=now() WHERE id=?', [$id, $id, $segment->id]);
            $routes[$segment->route_id] = true;
        }
        foreach (array_keys($routes) as $routeId) {
            DB::update('UPDATE gis_objects SET geometry=(SELECT ST_MakeLine(geometry ORDER BY sequence) FROM fiber_segments WHERE route_id=?),updated_at=now() WHERE id=?', [$routeId, $routeId]);
        }
    }
}
