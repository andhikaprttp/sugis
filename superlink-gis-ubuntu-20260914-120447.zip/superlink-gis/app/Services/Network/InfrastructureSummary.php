<?php

namespace App\Services\Network;

use App\Models\GisObject;

class InfrastructureSummary
{
    public function poleCount(): int
    {
        // A pole, ODP and ODC at the same XY position represent one physical pole.
        // Missing locations cannot be matched reliably, so count those separately.
        return (int) GisObject::whereIn('object_type', ['POLE', 'ODP', 'ODC'])
            ->selectRaw("COUNT(DISTINCT CASE WHEN geometry IS NULL THEN 'id:' || id::text ELSE 'xy:' || encode(ST_AsEWKB(ST_Force2D(geometry)), 'hex') END) AS total")
            ->value('total');
    }
}
