<?php

namespace App\Services\Network;

use App\Models\GisObject;
use App\Models\OdpPort;
use App\Services\AuditService;
use App\Services\Gis\GeometryService;
use App\Services\Gis\ZoneService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class NetworkService
{
    const TABLES = ['POP' => 'pops', 'ODC' => 'odcs', 'ODP' => 'odps', 'POLE' => 'poles', 'CLOSURE' => 'closures', 'FIBER_ROUTE' => 'fiber_routes', 'AREA' => 'coverage_areas'];

    public function __construct(private GeometryService $geometry) {}

    public function save(array $data, ?GisObject $object = null, string $source = 'WEB', ?int $actor = null): GisObject
    {
        return DB::transaction(function () use ($data, $object, $source, $actor) {
            if ($object) {
                $object = GisObject::whereKey($object->id)->lockForUpdate()->firstOrFail();
            }
            $old = $object?->toArray();
            $type = $data['object_type'] ?? $object?->object_type ?? 'UNCLASSIFIED';
            Validator::make($data, ['service_area_id' => 'nullable|uuid|exists:service_areas,id'])->validate();
            Validator::make($data, ['name' => [Rule::requiredIf(! $object), 'string', 'max:255'], 'code' => ['nullable', 'string', 'max:255', Rule::unique('gis_objects')->ignore($object?->id)], 'object_type' => [Rule::in(GeometryService::TYPES)], 'capacity' => ['nullable', 'integer', 'min:0', 'max:1024'], 'description' => ['nullable', 'string', 'max:10000'], 'notes' => ['nullable', 'string', 'max:10000'], 'status' => ['sometimes', Rule::in(['ACTIVE', 'INACTIVE', 'DAMAGED', 'PLANNED'])], 'area_id' => ['nullable', 'uuid'], 'pop_id' => ['nullable', 'uuid'], 'odc_id' => ['nullable', 'uuid'], 'installation_date' => ['nullable', 'date_format:Y-m-d'], 'height' => ['nullable', 'numeric', 'gt:0'], 'ownership' => ['nullable', 'string', 'max:255'], 'splitter_type' => ['nullable', 'string', 'max:255']])->validate();
            if (in_array($type, ['CUSTOMER', 'PROSPECT']) && ! $object?->customer()->exists()) {
                throw ValidationException::withMessages(['object_type' => 'Gunakan modul Customers untuk identitas pelanggan/prospect']);
            }
            if ($object && $object->object_type !== $type) {
                if ($object->object_type !== 'UNCLASSIFIED') {
                    $this->assertNoDependencies($object);
                }if ($object->customer()->exists()) {
                    throw ValidationException::withMessages(['object_type' => 'Customer harus tetap CUSTOMER/PROSPECT']);
                }if (isset(self::TABLES[$object->object_type])) {
                    if ($object->object_type === 'ODP') {
                        OdpPort::where('odp_id', $object->id)->delete();
                    }if ($object->object_type === 'FIBER_ROUTE') {
                        DB::table('fiber_segments')->where('route_id', $object->id)->delete();
                    }DB::table(self::TABLES[$object->object_type])->where('id', $object->id)->delete();
                }
            }
            $geo = array_key_exists('geometry', $data) ? $data['geometry'] : ($object ? GisObject::withGeometry()->find($object->id)->geojson : null);
            $this->geometry->validate($geo, $type);
            if ($type === 'AREA') {
                $data = [...$data, ...app(ZoneService::class)->metadata($data, $object?->id)];
            }
            foreach (['area_id' => 'AREA', 'pop_id' => 'POP', 'odc_id' => 'ODC'] as $field => $expected) {
                if (! empty($data[$field]) && ! GisObject::whereKey($data[$field])->where('object_type', $expected)->exists()) {
                    throw ValidationException::withMessages([$field => 'Parent tidak ditemukan/tipe salah']);
                }
            }
            $object ??= new GisObject;
            $object->fill(array_intersect_key($data, array_flip(['name', 'code', 'description', 'notes', 'status', 'area_id', 'service_area_id', 'pop_id', 'source_filename', 'original_name'])));
            $object->object_type = $type;
            $object->updated_by = $actor ?? auth()->id();
            if (! $object->exists) {
                $object->source = $source;
                $object->created_by = $actor ?? auth()->id();
            }$object->save();
            $this->geometry->save('gis_objects', $object->id, $geo);
            if (isset(self::TABLES[$type])) {
                $table = self::TABLES[$type];
                $existing = DB::table($table)->where('id', $object->id)->first();
                $meta = ['updated_at' => now()];
                if (! $existing) {
                    $meta['created_at'] = now();
                }
                $fields = match ($type) {
                    'ODP' => ['odc_id', 'splitter_type', 'installation_date'],'ODC' => ['pop_id', 'capacity'],'POLE' => ['ownership', 'height'],'FIBER_ROUTE' => ['cable_type', 'fiber_count'],'AREA' => ZoneService::FIELDS,default => []
                };
                foreach ($fields as $f) {
                    if (array_key_exists($f, $data)) {
                        $meta[$f] = $data[$f];
                    }
                }
                if ($type === 'ODP') {
                    $capacity = (int) ($data['capacity'] ?? $existing?->capacity ?? 8);
                    if ($existing && $capacity < $existing->capacity) {
                        $ports = OdpPort::where('odp_id', $object->id)->where('port_number', '>', $capacity)->lockForUpdate()->get();
                        if ($ports->contains(fn ($p) => $p->status !== 'AVAILABLE')) {
                            throw ValidationException::withMessages(['capacity' => 'Port yang akan dihapus tidak semuanya AVAILABLE']);
                        }OdpPort::whereIn('id', $ports->pluck('id'))->delete();
                    }$meta['capacity'] = $capacity;
                }
                DB::table($table)->updateOrInsert(['id' => $object->id], $meta);
                if ($type === 'ODP') {
                    for ($i = 1; $i <= $capacity; $i++) {
                        OdpPort::firstOrCreate(['odp_id' => $object->id, 'port_number' => $i], ['status' => 'AVAILABLE']);
                    }
                }
            }
            if ($type === 'FIBER_ROUTE') {
                if (isset($data['nodes'])) {
                    $this->segments($object, $data['nodes'], $data);
                } elseif (! DB::table('fiber_segments')->where('route_id', $object->id)->exists()) {
                    app(TopologyService::class)->attachEndpoints($object, $geo, $source, $actor);
                } elseif (array_key_exists('geometry', $data)) {
                    app(TopologyService::class)->editRoute($object, $geo);
                }
            }
            if ($geo && $geo['type'] === 'Point') {
                app(TopologyService::class)->moveNode($object->id);
            }
            AuditService::record($old ? ($old['object_type'] !== $type ? 'Classification' : 'Update') : 'Create', 'GisObject', $object->id, $old, $object->toArray(), $source, $actor);

            return GisObject::withGeometry()->findOrFail($object->id);
        });
    }

    public function assertNoDependencies(GisObject $o): void
    {
        $checks = [['gis_objects', 'area_id'], ['gis_objects', 'pop_id'], ['odcs', 'pop_id'], ['odps', 'odc_id'], ['customers', 'pop_id'], ['surveys', 'odp_id'], ['fiber_segments', 'start_node_id'], ['fiber_segments', 'end_node_id']];
        foreach ($checks as [$table,$field]) {
            $q = DB::table($table)->where($field, $o->id);
            if ($table === 'gis_objects') {
                $q->whereNull('deleted_at');
            }if ($q->exists()) {
                throw ValidationException::withMessages(['object' => 'Objek masih memiliki dependency: '.$table]);
            }
        }
        if (OdpPort::where('odp_id', $o->id)->where('status', '!=', 'AVAILABLE')->exists()) {
            throw ValidationException::withMessages(['object' => 'ODP masih memiliki port aktif/reservasi/rusak']);
        }
    }

    public function delete(GisObject $object): void
    {
        DB::transaction(function () use ($object) {
            $object = GisObject::whereKey($object->id)->lockForUpdate()->firstOrFail();
            if ($object->customer()->exists()) {
                throw ValidationException::withMessages(['object' => 'Hapus melalui modul Customers']);
            }$this->assertNoDependencies($object);
            $old = $object->toArray();
            $object->delete();
            AuditService::record('Delete', 'GisObject', $object->id, $old, null);
        });
    }

    public function segments(GisObject $route, array $nodes, array $data = []): void
    {
        if (count($nodes) < 2) {
            throw ValidationException::withMessages(['nodes' => 'Pilih minimal dua node']);
        }
        $objects = GisObject::withGeometry()->whereIn('id', $nodes)->whereIn('object_type', GeometryService::NODES)->get()->keyBy('id');
        if ($objects->count() !== count(array_unique($nodes))) {
            throw ValidationException::withMessages(['nodes' => 'Node tidak ditemukan']);
        }
        DB::table('fiber_segments')->where('route_id', $route->id)->delete();
        $line = [];
        foreach ($nodes as $i => $id) {
            $point = $objects[$id]->geojson['coordinates'] ?? null;
            if (! $point) {
                throw ValidationException::withMessages(['nodes' => 'Node belum memiliki lokasi']);
            }$line[] = $point;
            if (! $i) {
                continue;
            }if ($nodes[$i - 1] === $id) {
                throw ValidationException::withMessages(['nodes' => 'Node berurutan harus berbeda']);
            }DB::insert('INSERT INTO fiber_segments(id,route_id,sequence,start_node_id,end_node_id,geometry,cable_type,fiber_count,status,created_at,updated_at) VALUES(?,?,?,?,?,ST_SetSRID(ST_GeomFromGeoJSON(?),4326),?,?,?,now(),now())', [(string) Str::uuid(), $route->id, $i, $nodes[$i - 1], $id, json_encode(['type' => 'LineString', 'coordinates' => [$line[$i - 1], $point]]), $data['cable_type'] ?? 'DROP', $data['fiber_count'] ?? 1, 'ACTIVE']);
        }
        $this->geometry->save('gis_objects', $route->id, ['type' => 'LineString', 'coordinates' => $line]);
    }
}
