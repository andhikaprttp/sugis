<?php

namespace App\Services\Network;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Models\Survey;
use App\Services\AuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PortService
{
    private function fail(string $m): never
    {
        throw ValidationException::withMessages(['port' => $m]);
    }

    public function reserve(OdpPort $port, Survey $survey): OdpPort
    {
        return DB::transaction(function () use ($port, $survey) {
            $survey = Survey::whereKey($survey->id)->lockForUpdate()->firstOrFail();
            GisObject::whereKey($port->odp_id)->lockForUpdate()->firstOrFail();
            $port = OdpPort::whereKey($port->id)->lockForUpdate()->firstOrFail();
            if ($survey->status !== 'APPROVED' || $survey->odp_id !== $port->odp_id) {
                $this->fail('Survey harus APPROVED dan memilih ODP yang sama');
            }
            if (! GisObject::whereKey($port->odp_id)->where('status', 'ACTIVE')->exists()) {
                $this->fail('ODP tidak aktif');
            }
            if ($port->status !== 'AVAILABLE') {
                $this->fail('Port tidak tersedia');
            }
            if (OdpPort::where('reserved_for', $survey->id)->exists()) {
                $this->fail('Survey sudah memiliki reservasi');
            }
            $old = $port->toArray();
            $port->update(['status' => 'RESERVED', 'reserved_for' => $survey->id, 'reserved_at' => now()]);
            AuditService::record('Port Reservation', 'OdpPort', $port->id, $old, $port->toArray(), 'SURVEY');

            return $port;
        });
    }

    public function assign(OdpPort $target, Customer $customer, ?Survey $survey = null, string $source = 'WEB', ?int $actor = null): OdpPort
    {
        return DB::transaction(function () use ($target, $customer, $survey, $source, $actor) {
            $customer = Customer::whereKey($customer->id)->lockForUpdate()->firstOrFail();
            GisObject::whereKey($target->odp_id)->lockForUpdate()->firstOrFail();
            $ids = OdpPort::where('customer_id', $customer->id)->pluck('id')->push($target->id)->unique()->sort()->values();
            $locked = OdpPort::whereIn('id', $ids)->orderBy('id')->lockForUpdate()->get()->keyBy('id');
            $target = $locked[$target->id];
            if (! GisObject::whereKey($target->odp_id)->where('status', 'ACTIVE')->exists()) {
                $this->fail('ODP tidak aktif');
            }
            if ($target->customer_id === $customer->id) {
                return $target;
            }
            if ($target->status === 'RESERVED') {
                if (! $survey || $target->reserved_for !== $survey->id || $survey->customer_id !== $customer->id || ! in_array($survey->status, ['APPROVED', 'INSTALLATION'])) {
                    $this->fail('Reservasi milik survey lain');
                }
            } elseif ($target->status !== 'AVAILABLE') {
                $this->fail('Port sudah dipakai atau tidak tersedia');
            }
            foreach ($locked as $oldPort) {
                if ($oldPort->customer_id === $customer->id) {
                    $before = $oldPort->toArray();
                    $oldPort->update(['status' => 'AVAILABLE', 'customer_id' => null, 'installed_at' => null]);
                    AuditService::record('Port Release', 'OdpPort', $oldPort->id, $before, $oldPort->toArray(), $source, $actor);
                }
            }
            $old = $target->toArray();
            $target->update(['status' => 'OCCUPIED', 'customer_id' => $customer->id, 'reserved_for' => null, 'reserved_at' => null, 'installed_at' => now()]);
            AuditService::record('Port Assignment', 'OdpPort', $target->id, $old, $target->toArray(), $source, $actor);

            return $target;
        });
    }

    public function release(OdpPort $port): void
    {
        DB::transaction(function () use ($port) {
            $p = OdpPort::whereKey($port->id)->lockForUpdate()->firstOrFail();
            if ($p->status === 'OCCUPIED') {
                $this->fail('Gunakan Change Port atau deactivate customer untuk port terisi');
            }$old = $p->toArray();
            $p->update(['status' => 'AVAILABLE', 'reserved_for' => null, 'reserved_at' => null]);
            AuditService::record('Port Release', 'OdpPort', $p->id, $old, $p->toArray());
        });
    }

    public function status(OdpPort $port, string $status, ?string $notes): void
    {
        DB::transaction(function () use ($port, $status, $notes) {
            $p = OdpPort::whereKey($port->id)->lockForUpdate()->firstOrFail();
            if (in_array($p->status, ['OCCUPIED', 'RESERVED']) || ! in_array($status, ['AVAILABLE', 'DAMAGED', 'DISABLED'])) {
                $this->fail('Release/assignment harus melalui workflow terkait');
            }$old = $p->toArray();
            $p->update(['status' => $status, 'notes' => $notes]);
            AuditService::record('Update','OdpPort',$p->id,$old,$p->toArray());
        });
    }
}
