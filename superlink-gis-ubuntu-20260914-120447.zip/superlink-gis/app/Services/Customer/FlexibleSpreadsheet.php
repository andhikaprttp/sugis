<?php

namespace App\Services\Customer;

use PhpOffice\PhpSpreadsheet\Spreadsheet;

class FlexibleSpreadsheet
{
    public const TEMPLATE = ['No', 'Username', 'Password PPPOE', 'IP Address', 'Profile', 'Client', 'SN', 'TIPE ONT', 'TANGGAL AKTIVASI', 'NOMOR HP', 'RT/RW', 'KODE ODP/ODC', 'PORT ODP/ODC', 'PASSWORD APP', 'ALAMAT'];

    private function key(string $value): string
    {
        return preg_replace('/[^a-z0-9]/', '', strtolower(trim($value)));
    }

    public function header(Spreadsheet $book): array
    {
        $aliases = ['client' => 'name', 'nama' => 'name', 'namapelanggan' => 'name', 'idpelanggan' => 'customer_id', 'username' => 'pppoe_username', 'sn' => 'ont_serial_number', 'serialont' => 'ont_serial_number', 'tipeont' => 'ont_model', 'profile' => 'package_name', 'paket' => 'package_name', 'nomorhp' => 'phone', 'nohp' => 'phone', 'telepon' => 'phone', 'alamat' => 'address', 'tanggalaktivasi' => 'activation_date', 'tanggalpemasangan' => 'installation_date', 'rtrw' => '_rtrw', 'kodeodpodc' => '_network', 'portodpodc' => '_network_port', 'ipaddress' => '_ip'];
        foreach (SpreadsheetService::HEADERS as $header => $field) {
            $aliases[$this->key($header)] = $field;
            $aliases[$this->key($field)] = $field;
        }
        $found = [];
        foreach ($book->getWorksheetIterator() as $sheet) {
            for ($row = 1; $row <= min(50, $sheet->getHighestDataRow()); $row++) {
                $map = [];
                $values = $sheet->rangeToArray('A'.$row.':'.$sheet->getHighestDataColumn().$row, null, false, false)[0];
                foreach ($values as $i => $value) {
                    $field = $aliases[$this->key((string) $value)] ?? null;
                    if ($field) {
                        $map[$i] = $field;
                    }
                }
                if (in_array('name', $map) && array_intersect(['customer_id', 'pppoe_username', 'ont_serial_number'], $map)) {
                    if (count($map) !== count(array_unique($map))) {
                        throw new \InvalidArgumentException('Ada dua kolom untuk field yang sama. Hapus atau ubah header duplikat.');
                    }
                    $found[] = [$sheet, $row, $map];
                    break;
                }
            }
        }
        if (count($found) !== 1) {
            throw new \InvalidArgumentException(count($found) ? 'Lebih dari satu sheet pelanggan ditemukan. Upload satu tabel pelanggan per file.' : 'Header tidak ditemukan dalam 50 baris pertama. Gunakan Client/Nama/Name dan Customer ID, Username, atau SN.');
        }

        return $found[0];
    }

    public function row(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_string($value) && trim($value) === '-') {
                $data[$key] = null;
            }
        }
        $warnings = [];
        if (empty($data['customer_id'])) {
            $data['customer_id'] = trim((string) ($data['pppoe_username'] ?? '')) ?: (! empty($data['ont_serial_number']) ? 'ONT-'.strtoupper(preg_replace('/\s+/', '', $data['ont_serial_number'])) : '');
            $warnings['customer_id'] = 'Customer ID diambil dari Username, atau ONT-serial jika Username kosong. Periksa sebelum impor.';
        }
        if (! empty($data['ont_serial_number'])) {
            $data['ont_serial_number'] = strtoupper(preg_replace('/\s+/', '', $data['ont_serial_number']));
        }
        if (! empty($data['_rtrw']) && preg_match('/^(?:RT\s*)?(\d{1,3})\s*\/\s*(?:RW\s*)?(\d{1,3})$/i', trim($data['_rtrw']), $m)) {
            $data['rt'] = $m[1];
            $data['rw'] = $m[2];
            unset($data['_rtrw']);
        }
        foreach (['_rtrw' => 'RT/RW sumber', '_network' => 'Kode ODP/ODC sumber', '_network_port' => 'Port ODP/ODC sumber', '_ip' => 'IP sumber'] as $field => $label) {
            if (! empty($data[$field])) {
                $data['notes'] = trim(($data['notes'] ?? '')."\n".$label.': '.$data[$field]);
                $warnings[$field] = $label.' disimpan sebagai catatan; tidak membuat assignment jaringan otomatis.';
            }
            unset($data[$field]);
        }
        $months = ['januari','februari','maret','april','mei','juni','juli','agustus','september','oktober','november','desember'];
        foreach (['activation_date', 'installation_date'] as $field) {
            $value = $data[$field] ?? null;
            if (is_string($value) && preg_match('/^(\d{1,2})\s+([a-z]+)\s+(\d{4})$/i', trim($value), $m)) {
                $month = array_search(strtolower($m[2]), $months, true);
                if ($month !== false && checkdate($month + 1, (int) $m[1], (int) $m[3])) {
                    $data[$field] = sprintf('%04d-%02d-%02d', $m[3], $month + 1, $m[1]);
                }
            }
        }
        return [$data, $warnings];
    }
}
