<?php

namespace App\Services\Customer;

use App\Models\Customer;
use App\Models\CustomerImportJob;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Services\AuditService;
use App\Services\Gis\KmzImportService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class SpreadsheetService
{
    const HEADERS = ['Customer ID' => 'customer_id', 'Name' => 'name', 'Phone' => 'phone', 'Address' => 'address', 'RT' => 'rt', 'RW' => 'rw', 'Kelurahan' => 'village', 'Kecamatan' => 'district', 'City' => 'city', 'Province' => 'province', 'Latitude' => 'latitude', 'Longitude' => 'longitude', 'Package' => 'package_name', 'Status' => 'status', 'POP Code' => 'pop_code', 'ODC Code' => 'odc_code', 'ODP Code' => 'odp_code', 'ODP Port' => 'port_number', 'ONT Serial Number' => 'ont_serial_number', 'ONT Model' => 'ont_model', 'Installation Date' => 'installation_date', 'Activation Date' => 'activation_date', 'PPPoE Username' => 'pppoe_username', 'Notes' => 'notes'];

    public function normalize(array $data): array
    {
        foreach ($data as $k => $v) {
            if (in_array($k, array_values(self::HEADERS)) && ! in_array($k, ['latitude', 'longitude', 'port_number', 'installation_date', 'activation_date']) && is_numeric($v)) {
                $v = (string) $v;
                $data[$k] = $v;
            }
            if (is_string($v)) {
                $data[$k] = trim($v);
            }
        }
        if (! empty($data['phone'])) {
            $p = preg_replace('/[\s().-]/', '', $data['phone']);
            if (preg_match('/^08\d+$/', $p)) {
                $p = '+62'.substr($p, 1);
            }$data['phone'] = $p;
        }
        foreach (['installation_date', 'activation_date'] as $f) {
            if (! empty($data[$f]) && is_numeric($data[$f])) {
                $data[$f] = Date::excelToDateTimeObject((float) $data[$f])->format('Y-m-d');
            }
        }
        $data['status'] = strtoupper(($data['status'] ?? null) ?: 'PROSPECT');

        return $data;
    }

    public function validateRow(array $data, ?Customer $existing = null): array
    {
        $hasCoordinates = array_key_exists('latitude', $data) || array_key_exists('longitude', $data) || array_key_exists('geometry', $data);
        if ($existing) {
            $data = array_merge($existing->only(CustomerService::FIELDS), $data);
        }
        $data = $this->normalize($data);
        $errors = [];
        $warnings = [];
        foreach ($data as $k => $v) {
            if (is_string($v) && str_starts_with($v, '=')) {
                $errors[$k] = 'Formula tidak diizinkan';
            }
        }
        $validator = Validator::make($data, app(CustomerService::class)->rules($existing));
        if ($validator->fails()) {
            foreach ($validator->errors()->messages() as $k => $v) {
                $errors[$k] = implode('; ', $v);
            }
        }
        if (! empty($data['phone']) && ! preg_match('/^\+?\d{8,16}$/', $data['phone'])) {
            $warnings['phone'] = 'Format telepon tidak umum; nilai tetap dipertahankan';
        }
        $lat = $data['latitude'] ?? null;
        $lng = $data['longitude'] ?? null;
        if ($lat !== null && $lat !== '' || $lng !== null && $lng !== '') {
            if (! is_numeric($lat) || ! is_numeric($lng) || abs((float) $lat) > 90 || abs((float) $lng) > 180) {
                $errors['coordinates'] = 'Latitude/longitude harus berpasangan dan dalam rentang';
            } else {
                $data['geometry'] = ['type' => 'Point', 'coordinates' => [(float) $lng, (float) $lat]];
            }
        } else {
            if (! $existing || $hasCoordinates) {
                $data['geometry'] = $data['geometry'] ?? null;
            }
            $warnings['coordinates'] = 'LOCATION_MISSING';
        }
        $parents = [];
        foreach (['pop_code' => 'POP', 'odc_code' => 'ODC', 'odp_code' => 'ODP'] as $key => $type) {
            if (! empty($data[$key])) {
                $parents[$type] = GisObject::where('code', $data[$key])->where('object_type', $type)->first();
                if (! $parents[$type]) {
                    $errors[$key] = 'Kode '.$type.' tidak ditemukan';
                }
            }
        }
        if (isset($parents['POP'])) {
            $data['pop_id'] = $parents['POP']->id;
        }
        if (isset($parents['ODC'],$parents['POP']) && DB::table('odcs')->where('id', $parents['ODC']->id)->value('pop_id') !== $parents['POP']->id) {
            $errors['odc_code'] = 'ODC tidak berada pada POP ini';
        }
        if (isset($parents['ODP'],$parents['ODC']) && DB::table('odps')->where('id', $parents['ODP']->id)->value('odc_id') !== $parents['ODC']->id) {
            $errors['odp_code'] = 'ODP tidak berada pada ODC ini';
        }
        if (isset($data['port_number']) && $data['port_number'] !== '' && (! ctype_digit((string) $data['port_number']) || (int) $data['port_number'] < 1 || (int) $data['port_number'] > 1024)) {
            $errors['port_number'] = 'Nomor port harus bilangan bulat 1–1024 sesuai kapasitas ODP.';
        } elseif (! empty($data['port_number'])) {
            $port = isset($parents['ODP']) ? OdpPort::where('odp_id', $parents['ODP']->id)->where('port_number', $data['port_number'])->first() : null;
            if (! $port) {
                $errors['port_number'] = 'ODP/nomor port tidak ditemukan';
            } elseif ($port->status !== 'AVAILABLE' && $port->customer_id !== $existing?->id) {
                $errors['port_number'] = 'Port tidak tersedia atau RESERVED/OCCUPIED pelanggan lain';
            } else {
                $data['port_id'] = $port->id;
            }
        } elseif (isset($parents['ODP'])) {
            $warnings['port_number'] = 'Tanpa port, topology ODP tidak diassign';
        }

        return ['data' => $data, 'errors' => $errors, 'warnings' => $warnings];
    }

    public function parse(CustomerImportJob $job): void
    {
        $path = Storage::path($job->path);
        $z = app(KmzImportService::class)->inspectZip($path);
        $z->close();
        $reader = IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(false);
        $book = $reader->load($path);
        [$sheet, $headerRow, $map] = app(FlexibleSpreadsheet::class)->header($book);
        if ($sheet->getHighestDataRow() - $headerRow > 20000) {
            throw new \InvalidArgumentException('Maksimum 20000 pelanggan per file');
        }
        $seen = [];
        $seenPorts = [];
        $counts = ['valid' => 0, 'invalid' => 0, 'duplicate' => 0, 'warning' => 0];
        DB::transaction(function () use ($job, $sheet, $headerRow, $map, &$seen, &$seenPorts, &$counts) {
            $job->rows()->delete();
            for ($n = $headerRow + 1; $n <= $sheet->getHighestDataRow(); $n++) {
                $values = $sheet->rangeToArray('A'.$n.':'.$sheet->getHighestDataColumn().$n, null, false, false)[0];
                $data = [];
                foreach ($map as $i => $field) {
                    $data[$field] = $values[$i] ?? null;
                }if (! array_filter($data, fn ($v) => $v !== null && $v !== '')) {
                    continue;
                }
                [$data, $sourceWarnings] = app(FlexibleSpreadsheet::class)->row($data);
                $key = trim((string) ($data['customer_id'] ?? ''));
                $existing = Customer::withTrashed()->where('customer_id', $key)->first();
                $result = $this->validateRow($data, $existing);
                $result['warnings'] = array_merge($result['warnings'], $sourceWarnings);
                $duplicate = isset($seen[$key]) || ($existing && $job->mode === 'INSERT_ONLY');
                $seen[$key] = true;
                if ($existing?->trashed()) {
                    $result['errors']['customer_id'] = 'Customer terhapus; restore terlebih dahulu';
                }$port = $result['data']['port_id'] ?? null;
                if ($port && isset($seenPorts[$port])) {
                    $result['errors']['port_number'] = 'Port digunakan dua row pada file ini';
                }if ($port) {
                    $seenPorts[$port] = true;
                }$validation = $duplicate ? 'DUPLICATE' : ($result['errors'] ? 'INVALID' : ($result['warnings'] ? 'WARNING' : 'VALID'));
                $counts[$duplicate ? 'duplicate' : ($result['errors'] ? 'invalid' : 'valid')]++;
                if ($result['warnings']) {
                    $counts['warning']++;
                }
                $job->rows()->create(['row_number' => $n, 'data' => $result['data'], 'existing' => $existing ? [...$existing->toArray(), 'topology' => $existing->topology()] : null, 'errors' => $result['errors'], 'warnings' => $result['warnings'], 'validation' => $validation]);
            }
            $job->update(['status' => 'READY', 'total_rows' => array_sum([$counts['valid'], $counts['invalid'], $counts['duplicate']]), 'valid_rows' => $counts['valid'], 'invalid_rows' => $counts['invalid'], 'duplicate_rows' => $counts['duplicate'], 'counts' => $counts]);
        });
        $book->disconnectWorksheets();
    }

    public function commit(CustomerImportJob $job, array $ids): array
    {
        return DB::transaction(function () use ($job, $ids) {
            $job = CustomerImportJob::whereKey($job->id)->lockForUpdate()->firstOrFail();
            if ($job->status !== 'READY') {
                throw ValidationException::withMessages(['job' => 'Job bukan READY atau sudah diproses']);
            }$rows = $job->rows()->whereIn('id', $ids)->get();
            if ($rows->count() !== count(array_unique($ids)) || ! count($ids)) {
                throw ValidationException::withMessages(['rows' => 'Pilih baris dari job ini']);
            }$inserted = 0;
            $updated = 0;
            $job->update(['status' => 'IMPORTING']);
            foreach ($rows as $row) {
                if (! in_array($row->validation, ['VALID', 'WARNING'])) {
                    throw ValidationException::withMessages(['rows' => 'Baris invalid/duplicate tidak dapat diimport']);
                }$existing = Customer::where('customer_id', $row->data['customer_id'])->lockForUpdate()->first();
                if ($existing && $job->mode === 'INSERT_ONLY') {
                    throw ValidationException::withMessages(['rows' => 'Customer baru saja dibuat oleh pengguna lain; re-upload']);
                }if ($row->existing && (! $existing || $existing->updated_at->toISOString() !== Carbon::parse($row->existing['updated_at'])->toISOString() || $existing->topology() !== $row->existing['topology'])) {
                    throw ValidationException::withMessages(['rows' => 'Data berubah setelah preview; re-upload untuk review ulang']);
                }$result = $this->validateRow($row->data, $existing);
                if ($result['errors']) {
                    throw ValidationException::withMessages(['rows' => 'Konflik setelah preview: '.json_encode($result['errors'])]);
                }app(CustomerService::class)->save([...$result['data'], 'source_filename' => $job->filename], $existing, 'EXCEL_IMPORT', auth()->id());
                $existing ? $updated++ : $inserted++;
            }
            $job->update(['status' => 'COMPLETED', 'inserted_rows' => $inserted, 'updated_rows' => $updated, 'skipped_rows' => $job->total_rows - $inserted - $updated]);
            AuditService::record('Customer Import', 'CustomerImportJob', $job->id, null, ['inserted' => $inserted, 'updated' => $updated], 'EXCEL_IMPORT');

            return compact('inserted', 'updated');
        });
    }

    public function workbook(array $sheets): Spreadsheet
    {
        $book = new Spreadsheet;
        $book->removeSheetByIndex(0);
        foreach ($sheets as $name => $rows) {
            $sheet = $book->createSheet();
            $sheet->setTitle($name);
            foreach ($rows as $r => $row) {
                foreach (array_values($row) as $col => $value) {
                    $cell = Coordinate::stringFromColumnIndex($col + 1).($r + 1);
                    if (is_numeric($value) && ! is_string($value)) {
                        $sheet->setCellValue($cell, $value);
                    } else {
                        $sheet->setCellValueExplicit($cell, (string) ($value ?? ''), DataType::TYPE_STRING);
                    }
                }
            }$last = $sheet->getHighestDataColumn();
            $sheet->getStyle('A1:'.$last.'1')->getFont()->setBold(true);
            $sheet->freezePane('A2');
            $sheet->setAutoFilter('A1:'.$last.max(1, count($rows)));
            for ($i = 1; $i <= Coordinate::columnIndexFromString($last); $i++) {
                $sheet->getColumnDimensionByColumn($i)->setWidth(22);
            }
        }$book->setActiveSheetIndex(0);

        return $book;
    }

    public function template(): Spreadsheet
    {
        return $this->workbook(['Customers' => [FlexibleSpreadsheet::TEMPLATE], 'README' => [
            ['Kolom', 'Petunjuk'],
            ['Format', 'Sesuai tabel Cinangka. Urutan kolom bebas; header dicari pada 50 baris pertama. Satu sheet pelanggan per file.'],
            ['Identitas', 'Client/Nama wajib. Customer ID opsional: memakai Username, lalu ONT-serial. Jangan memakai nomor urut sebagai ID.'],
            ['Tanggal', 'Tanggal Excel, YYYY-MM-DD, atau 26 Juni 2026.'],
            ['RT/RW', 'Contoh RT03 / RW03 atau 03/03.'],
            ['Status', 'Kolom Status opsional. Default PROSPECT; isi ACTIVE untuk pelanggan aktif.'],
            ['Telepon', 'Simpan sebagai teks untuk mempertahankan angka nol awal.'],
            ['Kode/Port ODP/ODC', 'Disimpan sebagai catatan. Untuk assignment tervalidasi gunakan kolom ODP Code dan ODP Port.'],
            ['Password PPPOE / PASSWORD APP', 'Tidak diimpor atau disalin ke catatan. Kolom ini boleh dihapus atau dikosongkan.'],
            ['UPSERT', 'Kolom yang tidak tersedia dipertahankan. Kolom yang tersedia tetapi kosong dapat menghapus nilai lama; periksa preview.'],
            ['Header lama', 'Header bahasa Inggris dari template lama tetap diterima.'],
        ]]);
    }

    public function errors(CustomerImportJob $job): Spreadsheet
    {
        $rows = [['Original Row', 'Customer ID', 'Name', 'Field', 'Input Value', 'Error', 'Recommendation']];
        foreach ($job->rows as $row) {
            foreach ([...$row->errors, ...($row->validation === 'DUPLICATE' ? ['customer_id' => 'Duplicate customer'] : [])] as $field => $error) {
                $rows[] = [$row->row_number, $row->data['customer_id'] ?? '', $row->data['name'] ?? '', $field, $row->data[$field] ?? '', is_array($error) ? implode('; ', $error) : $error, 'Correct input and re-upload'];
            }
        }

        return $this->workbook(['Errors' => $rows]);
    }

    public function export(array $filters, string $actor): Spreadsheet
    {
        $rows = [array_keys(self::HEADERS)];
        $summary = ['Total Customers' => 0];
        $topology = [];
        foreach (app(CustomerService::class)->query($filters)->cursor() as $c) {
            $g = GisObject::withGeometry()->find($c->gis_object_id)?->geojson;
            $t = $c->topology();
            $data = [...$c->toArray(), 'latitude' => $g['coordinates'][1] ?? null, 'longitude' => $g['coordinates'][0] ?? null, 'pop_code' => $t['pop'], 'odc_code' => $t['odc'], 'odp_code' => $t['odp'], 'port_number' => $t['port'], 'notes' => $c->object?->notes];
            $row = [];
            foreach (self::HEADERS as $key) {
                $row[] = $data[$key] ?? null;
            }$rows[] = $row;
            $summary['Total Customers']++;
            $summary[$c->status] = ($summary[$c->status] ?? 0) + 1;
            foreach (['pop', 'odc', 'odp'] as $kind) {
                $key = strtoupper($kind).': '.($t[$kind] ?? 'Unassigned');
                $topology[$key] = ($topology[$key] ?? 0) + 1;
            }
        }$stats = [['Metric', 'Count']];
        foreach ([...$summary, ...$topology] as $k => $v) {
            $stats[] = [$k, $v];
        }

        return $this->workbook(['Customers' => $rows, 'Summary' => $stats, 'Metadata' => [['Field', 'Value'], ['Export Date', now()->toIso8601String()], ['Exported By', $actor], ['Applied Filters', json_encode($filters)]]]);
    }
}
