<?php

namespace App\Services\Customer;

use App\Models\Customer;
use App\Models\GisObject;
use App\Models\OdpPort;
use App\Services\AuditService;
use App\Services\Gis\GeometryService;
use App\Services\Network\PortService;
use App\Services\Network\TopologyService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class CustomerService
{
    const STATUSES = ['PROSPECT', 'SURVEY', 'WAITING_INSTALLATION', 'ACTIVE', 'SUSPENDED', 'INACTIVE', 'TERMINATED'];

    const FIELDS = ['customer_id', 'name', 'phone', 'secondary_phone', 'email', 'address', 'rt', 'rw', 'village', 'district', 'city', 'province', 'package_name', 'package_speed', 'status', 'pop_id', 'ont_serial_number', 'ont_model', 'ont_vendor', 'pppoe_username', 'installation_date', 'activation_date'];

    public function rules(?Customer $customer = null): array
    {
        $r = [];
        foreach (self::FIELDS as $f) {
            $r[$f] = ['nullable', 'string', 'max:255'];
        }
        $r['customer_id'] = ['required', 'string', 'max:255', Rule::unique('customers')->ignore($customer?->id)];
        $r['name'] = ['required', 'string', 'max:255'];
        $r['ont_serial_number'] = ['nullable', 'string', 'max:255', Rule::unique('customers')->ignore($customer?->id)];
        $r['status'] = ['required', Rule::in(self::STATUSES)];
        $r['email'] = ['nullable', 'email'];
        $r['package_speed'] = ['nullable', 'integer', 'min:1'];
        $r['pop_id'] = ['nullable', 'uuid', Rule::exists('pops', 'id')];
        foreach (['installation_date', 'activation_date'] as $f) {
            $r[$f] = ['nullable', 'date_format:Y-m-d'];
        }$r['notes'] = ['nullable', 'string', 'max:10000'];
        $r['port_id'] = ['nullable', 'uuid', Rule::exists('odp_ports', 'id')];
        $r['package_id'] = ['sometimes', 'nullable', 'uuid', Rule::exists('service_packages', 'id')];

        return $r;
    }

    public function save(array $data, ?Customer $customer = null, string $source = 'WEB', ?int $actor = null): Customer
    {
        return DB::transaction(function () use ($data, $customer, $source, $actor) {
            if ($customer) {
                $customer = Customer::whereKey($customer->id)->lockForUpdate()->firstOrFail();
            }
            $data = array_merge($customer?->only(self::FIELDS) ?? ['status' => 'PROSPECT'], $data);
            $data['customer_id'] = trim($data['customer_id'] ?? '');
            $data['name'] = trim($data['name'] ?? '');
            foreach ($data as $key => $v) {
                if ($v === '') {
                    $data[$key] = null;
                }
            }
            Validator::make($data, $this->rules($customer))->validate();
            $package = null;
            if (array_key_exists('package_id', $data)) {
                if ($data['package_id']) {
                    $package = \App\Models\ServicePackage::whereKey($data['package_id'])->lockForUpdate()->firstOrFail();
                    if (! $package->active) {
                        throw ValidationException::withMessages(['package_id' => 'Paket sudah tidak aktif. Pilih paket lain.']);
                    }
                }
                $data['package_name'] = $package?->name;
                $data['package_speed'] = $package?->speed_mbps;
            } elseif ($customer?->package_id && (($data['package_name'] ?? null) !== $customer->package_name || (string) ($data['package_speed'] ?? '') !== (string) $customer->package_speed)) {
                throw ValidationException::withMessages(['package_id' => 'Ubah paket melalui pilihan paket pada detail pelanggan.']);
            }
            $managedOnt = $customer?->devices()->where('type', 'ONT')->first();
            if ($managedOnt) {
                foreach (['ont_serial_number' => 'serial_number', 'ont_model' => 'model', 'ont_vendor' => 'vendor'] as $field => $attribute) {
                    if (($data[$field] ?? null) !== $managedOnt->$attribute) {
                        throw ValidationException::withMessages([$field => 'ONT dikelola melalui menu Perangkat & Stok. Kembalikan perangkat sebelum menggantinya.']);
                    }
                }
            } elseif (! empty($data['ont_serial_number']) && \App\Models\Device::whereRaw('upper(serial_number) = ?', [strtoupper($data['ont_serial_number'])])->where('type', 'ONT')->exists()) {
                throw ValidationException::withMessages(['ont_serial_number' => 'Serial terdaftar dalam inventori. Pasang ONT melalui menu Perangkat & Stok.']);
            }
            $old = $customer?->toArray();
            $geo = array_key_exists('geometry', $data) ? $data['geometry'] : ($customer ? GisObject::withGeometry()->find($customer->gis_object_id)->geojson : null);
            app(GeometryService::class)->validate($geo, 'CUSTOMER');
            $object = $customer?->object ?? new GisObject;
            $object->fill(['name' => $data['name'], 'object_type' => $data['status'] === 'PROSPECT' ? 'PROSPECT' : 'CUSTOMER', 'status' => in_array($data['status'], ['TERMINATED', 'INACTIVE']) ? 'INACTIVE' : 'ACTIVE', 'notes' => $data['notes'] ?? $object->notes, 'updated_by' => $actor ?? auth()->id()]);
            if (! $object->exists) {
                $object->fill(['source' => $source, 'source_filename' => $data['source_filename'] ?? null, 'created_by' => $actor ?? auth()->id()]);
            }$object->save();
            app(GeometryService::class)->save('gis_objects', $object->id, $geo);
            app(TopologyService::class)->moveNode($object->id);
            $customer ??= new Customer;
            $customer->fill(array_intersect_key($data, array_flip(self::FIELDS)));
            if (array_key_exists('package_id', $data)) {
                $customer->package_id = $package?->id;
                $customer->package_price = $package?->price;
            }
            $customer->gis_object_id = $object->id;
            $customer->save();
            if (! empty($data['port_id'])) {
                app(PortService::class)->assign(OdpPort::findOrFail($data['port_id']), $customer, null, $source, $actor);
            }
            AuditService::record($old ? 'Update' : 'Create', 'Customer', $customer->id, $old, $customer->toArray(), $source, $actor);

            return $customer->fresh();
        });
    }

    public function query(array $filters = [])
    {
        $q = Customer::query()->with(['object', 'port.odp.object', 'port.odp.odc.object', 'port.odp.odc.pop.object', 'pop.object']);
        if (! empty($filters['deleted'])) {
            $q->onlyTrashed();
        }
        if (! empty($filters['search'])) {
            $s = '%'.$filters['search'].'%';
            $q->where(function ($q) use ($s) {
                foreach (['customer_id', 'name', 'phone', 'address', 'ont_serial_number', 'pppoe_username'] as $f) {
                    $q->orWhere($f, 'ilike', $s);
                }$q->orWhereHas('port.odp.object', fn ($x) => $x->where('code', 'ilike', $s))->orWhereHas('port.odp.odc.object', fn ($x) => $x->where('code', 'ilike', $s));
            });
        }
        foreach (['status', 'package_name', 'rt', 'rw'] as $f) {
            if (! empty($filters[$f])) {
                $q->where($f, $filters[$f]);
            }
        }
        foreach (['odp_id' => 'port', 'odc_id' => 'port.odp'] as $f => $rel) {
            if (! empty($filters[$f])) {
                $q->whereHas($rel, fn ($x) => $x->where($f, $filters[$f]));
            }
        }
        if (! empty($filters['pop_id'])) {
            $q->where(fn ($x) => $x->where('pop_id', $filters['pop_id'])->orWhereHas('port.odp.odc', fn ($n) => $n->where('pop_id', $filters['pop_id'])));
        }
        if (! empty($filters['missing_location'])) {
            $q->whereHas('object', fn ($x) => $x->whereNull('geometry'));
        }
        if (! empty($filters['ids'])) {
            $q->whereIn('id', $filters['ids']);
        }
        $sort = in_array($filters['sort'] ?? '', self::FIELDS) ? $filters['sort'] : 'customer_id';

        return $q->orderBy($sort, ($filters['direction'] ?? 'asc') === 'desc' ? 'desc' : 'asc');
    }

    public function delete(Customer $c): void
    {
        DB::transaction(function () use ($c) {
            $c = Customer::whereKey($c->id)->lockForUpdate()->firstOrFail();
            if ($c->devices()->exists()) {
                throw ValidationException::withMessages(['customer' => 'Kembalikan perangkat pelanggan ke stok sebelum menghapus pelanggan.']);
            }
            if ($c->port()->exists() || $c->surveys()->whereNotIn('status', ['CANCELLED', 'INSTALLED'])->exists() || DB::table('fiber_segments')->where('start_node_id', $c->gis_object_id)->orWhere('end_node_id', $c->gis_object_id)->exists()) {
                throw ValidationException::withMessages(['customer' => 'Customer masih terhubung port, survey, atau route']);
            }$old = $c->toArray();
            $c->delete();
            $c->object->delete();
            AuditService::record('Delete', 'Customer', $c->id, $old, null);
        });
    }

    public function deactivate(Customer $c): void
    {
        DB::transaction(function () use ($c) {
            $c = Customer::whereKey($c->id)->lockForUpdate()->firstOrFail();
            $old = $c->toArray();
            foreach ($c->port()->lockForUpdate()->get() as $p) {
                $before = $p->toArray();
                $p->update(['status' => 'AVAILABLE', 'customer_id' => null, 'installed_at' => null]);
                AuditService::record('Port Release', 'OdpPort', $p->id, $before, $p->toArray());
            }$c->update(['status' => 'INACTIVE']);
            $c->object->update(['status' => 'INACTIVE']);
            AuditService::record('Deactivate','Customer',$c->id,$old,$c->toArray());
        });
    }
}
