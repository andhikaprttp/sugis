<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class AuditService
{
    public static function record(string $action, string $model, ?string $id, $old, $new, string $source = 'WEB', ?int $actor = null): void
    {
        DB::table('audit_logs')->insert(['user_id' => $actor ?? auth()->id(), 'action' => $action, 'model' => $model, 'model_id' => $id, 'old_values' => $old === null ? null : json_encode($old, JSON_THROW_ON_ERROR), 'new_values' => $new === null ? null : json_encode($new, JSON_THROW_ON_ERROR), 'source' => $source, 'created_at' => now()]);
    }
}
