<?php

namespace App\Services\Blast;

use Illuminate\Validation\ValidationException;

class DokuCsv
{
    public function parse(string $path): array
    {
        $file = fopen($path, 'r');
        try {
            $header = fgetcsv($file, 0, ',', '"', '');
            if (! $header) {
                throw ValidationException::withMessages(['file' => 'CSV kosong.']);
            }
            $header = array_map(fn ($h) => strtolower(preg_replace('/[^a-zA-Z]/', '', $h)), $header);
            $required = ['customername', 'customerphone', 'invoicenumber', 'totalamount', 'expireddate', 'paymentlink'];
            if (array_diff($required, $header)) {
                throw ValidationException::withMessages(['file' => 'Header CSV DOKU harus memuat Customer Name, Customer Phone, Invoice Number, Total Amount, Expired Date, Payment Link.']);
            }
            $rows = [];
            while (($values = fgetcsv($file, 0, ',', '"', '')) !== false) {
                if ($values === [null]) {
                    continue;
                }
                if (count($values) !== count($header) || count($rows) >= 500) {
                    throw ValidationException::withMessages(['file' => 'CSV tidak sesuai atau melebihi 500 penerima.']);
                }
                $r = array_combine($header, $values);
                if (! is_numeric($r['totalamount']) || (float) $r['totalamount'] < 0) {
                    throw ValidationException::withMessages(['file' => 'Total Amount harus angka non-negatif tanpa pemisah ribuan.']);
                }
                $rows[] = ['name' => $r['customername'], 'phone' => app(MessageBuilder::class)->phone($r['customerphone']), 'invoice' => $r['invoicenumber'], 'amount' => 'Rp '.number_format((float) $r['totalamount'], 0, ',', '.'), 'due_date' => explode(',', $r['expireddate'])[0], 'link' => $r['paymentlink'], 'selected' => true, 'custom_message' => null];
            }

            return $rows;
        } finally {
            fclose($file);
        }
    }
}
