<?php

namespace App\Services\Blast;

use App\Models\BlastRecipient;
use Illuminate\Validation\ValidationException;

class MessageBuilder
{
    public function phone(string $input): string
    {
        // Reject lists/letters instead of concatenating multiple recipients.
        if (! preg_match('/^\+?[0-9\s().-]+$/D', trim($input))) {
            throw ValidationException::withMessages(['phone' => 'Nomor WhatsApp tidak valid.']);
        }
        $phone = preg_replace('/\D/', '', $input);
        if (str_starts_with($phone, '0')) {
            $phone = '62'.substr($phone, 1);
        } elseif (str_starts_with($phone, '8')) {
            $phone = '62'.$phone;
        }
        if (! preg_match('/^[1-9][0-9]{7,14}$/D', $phone)) {
            throw ValidationException::withMessages(['phone' => 'Nomor harus 8–15 digit dengan kode negara.']);
        }

        return $phone;
    }

    public function render(string $template, BlastRecipient $recipient): string
    {
        return strtr($recipient->custom_message ?: $template, [
            '{NAME}' => $recipient->name, '{INVOICE}' => $recipient->invoice,
            '{AMOUNT}' => $recipient->amount, '{DUE_DATE}' => $recipient->due_date,
            '{LINK}' => $recipient->link ?? '',
        ]);
    }
}
