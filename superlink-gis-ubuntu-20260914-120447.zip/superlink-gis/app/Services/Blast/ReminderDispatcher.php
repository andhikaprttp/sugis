<?php

namespace App\Services\Blast;

use App\Jobs\SendBlastDelivery;
use App\Models\BlastCampaign;
use App\Models\BlastDelivery;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ReminderDispatcher
{
    public function tick(): void
    {
        DB::table('blast_deliveries')->whereIn('status', ['QUEUED', 'SENDING'])->where('updated_at', '<', now()->subMinutes(20))
            ->update(['status' => 'UNKNOWN', 'error' => 'Pekerjaan terhenti. Periksa provider sebelum mengirim ulang.', 'updated_at' => now()]);
        foreach (BlastCampaign::where('enabled', true)->cursor() as $campaign) {
            foreach ($campaign->occurrences as $slot) {
                $due = CarbonImmutable::parse($slot);
                if ($due->isFuture()) {
                    continue;
                }
                $status = $due->lt(now()->subMinutes(config('blast.late_minutes'))) ? 'EXPIRED' : 'PENDING';
                foreach ($campaign->recipients()->where('selected', true)->where('paid', false)->cursor() as $recipient) {
                    DB::table('blast_deliveries')->insertOrIgnore([
                        'id' => (string) Str::uuid(), 'recipient_id' => $recipient->id, 'slot' => $slot,
                        'scheduled_at' => $due->toIso8601String(), 'manual' => false, 'status' => $status,
                        'phone' => $recipient->phone, 'message' => app(MessageBuilder::class)->render($campaign->template, $recipient),
                        'created_at' => now(), 'updated_at' => now(),
                    ]);
                }
            }
        }
        BlastCampaign::where('enabled', true)->get()->each(function ($campaign) {
            if (CarbonImmutable::parse(max($campaign->occurrences))->lt(now()->subMinutes(config('blast.late_minutes')))) {
                $campaign->update(['enabled' => false]);
            }
        });
        if (! app(WhatsAppSender::class)->configured()) {
            return;
        }
        $pending = BlastDelivery::where('status', 'PENDING')->where('scheduled_at', '<=', now()->toIso8601String())->orderBy('scheduled_at')->limit(config('blast.batch_size'))->get();
        foreach ($pending as $delivery) {
            if (! BlastDelivery::whereKey($delivery->id)->where('status', 'PENDING')->update(['status' => 'QUEUED', 'updated_at' => now()])) {
                continue;
            }
            try {
                SendBlastDelivery::dispatch($delivery->id);
            } catch (\Throwable $e) {
                BlastDelivery::whereKey($delivery->id)->where('status', 'QUEUED')->update(['status' => 'UNKNOWN', 'error' => 'Antrean tidak dapat dipastikan. Periksa worker sebelum mengirim ulang.']);
            }
        }
    }
}
