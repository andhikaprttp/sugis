<?php

namespace App\Services\Blast;

use Illuminate\Support\Facades\Http;

class WhatsAppSender
{
    public function configured(): bool
    {
        return config('blast.driver') === 'fonnte' && filled(config('blast.token'));
    }

    public function send(string $phone, string $message): array
    {
        if (! $this->configured()) {
            return ['status' => 'BLOCKED', 'error' => 'API pengirim belum dikonfigurasi.'];
        }
        try {
            $response = Http::asForm()->withHeaders(['Authorization' => config('blast.token')])
                ->connectTimeout(5)->timeout(25)->withOptions(['allow_redirects' => false])
                ->post('https://api.fonnte.com/send', ['target' => $phone, 'message' => $message, 'countryCode' => '0', 'connectOnly' => 'true']);
        } catch (\Throwable $e) {
            return ['status' => 'UNKNOWN', 'error' => 'Hasil pengiriman tidak diketahui. Periksa provider sebelum mengirim ulang.'];
        }
        $data = $response->json();
        if ($response->successful() && is_array($data) && ($data['status'] ?? null) === true) {
            $id = is_array($data['id'] ?? null) ? ($data['id'][0] ?? null) : ($data['id'] ?? null);

            return ['status' => 'ACCEPTED', 'provider_id' => is_scalar($id) ? substr((string) $id, 0, 255) : null, 'error' => null];
        }
        if ($response->successful() && is_array($data) && ($data['status'] ?? null) === false) {
            return ['status' => 'FAILED', 'error' => 'Provider menolak pesan. Periksa token, koneksi perangkat, dan kuota di provider.'];
        }

        return ['status' => 'UNKNOWN', 'error' => 'Respons provider tidak dapat memastikan hasil. HTTP '.$response->status().'.'];
    }
}
