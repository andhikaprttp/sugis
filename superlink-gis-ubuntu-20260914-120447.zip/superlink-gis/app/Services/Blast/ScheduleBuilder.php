<?php

namespace App\Services\Blast;

use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class ScheduleBuilder
{
    public function build(array $data): array
    {
        $v = Validator::make($data, [
            'month' => 'required|date_format:Y-m', 'time' => 'required|date_format:H:i',
            'mode' => 'required|in:dates,interval', 'count' => 'required|integer|between:1,31',
            'days' => 'required_if:mode,dates|array|max:31', 'days.*' => 'integer|between:1,31|distinct',
            'start_day' => 'required_if:mode,interval|integer|between:1,31',
            'interval_days' => 'required_if:mode,interval|integer|between:1,31',
        ])->validate();
        $month = CarbonImmutable::createFromFormat('!Y-m', $v['month'], 'Asia/Jakarta');
        $days = $v['mode'] === 'dates' ? $v['days'] : array_map(fn ($i) => (int) $v['start_day'] + $i * (int) $v['interval_days'], range(0, $v['count'] - 1));
        if (count($days) !== (int) $v['count'] || max($days) > $month->daysInMonth) {
            throw ValidationException::withMessages(['schedule' => 'Jumlah tanggal harus sama dengan jumlah reminder dan seluruhnya berada pada bulan yang dipilih.']);
        }
        sort($days);

        return array_map(fn ($day) => $month->setDay($day)->setTimeFromTimeString($v['time'])->toIso8601String(), $days);
    }
}
