<?php

namespace App\Services\Cdata;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CdataSync
{
    public static function sn(?string $sn): string
    {
        return strtoupper(preg_replace('/\s+/', '', $sn ?? ''));
    }

    public function run(): void
    {
        $lock = Cache::lock('cdata-sync', 900);
        if (! $lock->get()) {
            throw new RuntimeException('Sinkronisasi masih berjalan.');
        }
        try {
            $client = app(CdataClient::class);
            $olts = $client->pages(true);
            $onus = $client->pages(false);
            $map = [];
            $rows = [];
            foreach ($olts as $o) {
                if (! empty($o['externalId']) && ! empty($o['deviceId'])) {
                    $map[$o['deviceId']] = $o['externalId'];
                }
            }
            foreach ($onus as $o) {
                $sn = self::sn($o['sn'] ?? null);
                if (! $sn) {
                    continue;
                }
                if (isset($rows[$sn])) {
                    throw new RuntimeException('CMS berisi SN duplikat; pemetaan harus diperiksa.');
                }
                $raw = $o['omciRunningState'] ?? $o['runningState'] ?? null;
                $admin = $o['deactive'] ?? null;
                $description = $o['deviceDesc'] ?? $o['deviceName'] ?? null;
                $rows[$sn] = ['sn' => $sn, 'olt_device_id' => $o['oltId'] ?? null, 'olt_external_id' => $map[$o['oltId'] ?? ''] ?? null, 'pon_id' => $o['ponId'] ?? null, 'onu_id' => $o['onuId'] ?? null,
                    'description' => is_string($description) ? mb_substr($description, 0, 2000) : null,
                    'ont_state' => in_array($raw, ['online', 'offline'], true) ? strtoupper($raw) : 'UNKNOWN',
                    'admin_state' => in_array($admin, [true, 1, '1'], true) ? 'DEACTIVATED' : (in_array($admin, [false, 0, '0'], true) ? 'ACTIVE' : 'UNKNOWN'),
                    'offline_reason' => is_string($o['offlineReason'] ?? null) ? mb_substr($o['offlineReason'], 0, 255) : null,
                    'rx_power' => isset($o['rxPower']) ? mb_substr((string) $o['rxPower'], 0, 50) : null, 'tx_power' => isset($o['txPower']) ? mb_substr((string) $o['txPower'], 0, 50) : null, 'observed_at' => now()];
            }
            DB::transaction(function () use ($olts, $rows) {
                DB::table('cms_olt_snapshots')->delete();
                $counts = [];
                foreach ($rows as $row) {
                    $id = $row['olt_device_id'] ?? '';
                    $counts[$id]['total'] = ($counts[$id]['total'] ?? 0) + 1;
                    $counts[$id]['online'] = ($counts[$id]['online'] ?? 0) + ($row['ont_state'] === 'ONLINE' ? 1 : 0);
                }
                foreach ($olts as $o) {
                    if (! empty($o['deviceId'])) {
                        DB::table('cms_olt_snapshots')->insert([
                            'device_id' => $o['deviceId'], 'external_id' => $o['externalId'] ?? null,
                            'name' => ($o['deviceName'] ?? null) ?: ($o['deviceDesc'] ?? $o['deviceId']),
                            'host' => $o['ip'] ?? null, 'model' => $o['model'] ?? null, 'sn' => $o['sn'] ?? null,
                            'state' => in_array($o['runningState'] ?? null, ['online', 'offline'], true) ? strtoupper($o['runningState']) : 'UNKNOWN',
                            'onu_count' => $counts[$o['deviceId']]['total'] ?? 0,
                            'online_count' => $counts[$o['deviceId']]['online'] ?? 0, 'observed_at' => now(),
                        ]);
                    }
                    if (empty($o['externalId'])) {
                        continue;
                    } // Do not invent an external ID or change it on the CMS.
                    DB::table('provisioning_olts')->updateOrInsert(['external_id' => $o['externalId']], ['name' => mb_substr($o['deviceName'] ?? $o['deviceDesc'] ?? $o['externalId'], 0, 255), 'host' => $o['ip'] ?? null, 'updated_at' => now(), 'created_at' => now()]);
                }
                foreach ($rows as $row) {
                    $old = DB::table('ont_snapshots')->where('sn', $row['sn'])->first();
                    if (! $old || $old->ont_state !== $row['ont_state'] || $old->offline_reason !== $row['offline_reason']) {
                        DB::table('ont_events')->insert(['sn' => $row['sn'], 'olt_external_id' => $row['olt_external_id'], 'state' => $row['ont_state'], 'reason' => $row['offline_reason'], 'observed_at' => now()]);
                    }
                }
                DB::table('ont_snapshots')->delete();
                foreach (array_chunk(array_values($rows), 500) as $chunk) {
                    DB::table('ont_snapshots')->insert($chunk);
                }
                DB::table('provisioning_connections')->where('id', 1)->update(['last_sync_at' => now(), 'last_error' => null]);
                DB::table('ont_events')->where('observed_at', '<', now()->subDays(90))->delete();
            });
        } catch (\Throwable $e) {
            DB::table('provisioning_connections')->where('id', 1)->update(['last_error' => mb_substr($e instanceof RuntimeException ? $e->getMessage() : 'Sinkronisasi gagal. Periksa konfigurasi CMS.', 0, 255)]);
            throw new RuntimeException('Sinkronisasi gagal. Lihat status pada Koneksi CMS.');
        } finally {
            $lock->release();
        }
    }
}
