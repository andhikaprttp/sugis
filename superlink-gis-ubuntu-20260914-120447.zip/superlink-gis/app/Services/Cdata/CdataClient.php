<?php

namespace App\Services\Cdata;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class CdataClient
{
    public function request(string $method, string $path, array $query = [], ?array $body = null): array
    {
        $c = DB::table('provisioning_connections')->find(1);
        if (! $c || ! $c->enabled || ! $c->cms_token) {
            throw new RuntimeException('Aktifkan konektor dan simpan token CMS terlebih dahulu.');
        }
        $parts = parse_url($c->cms_url);
        if (! $parts || empty($parts['host']) || ! in_array($parts['scheme'] ?? '', config('cdata.allow_http') ? ['http', 'https'] : ['https'], true)
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new RuntimeException('CMS membutuhkan URL HTTPS tanpa kredensial, query, atau fragment. HTTP hanya diizinkan melalui CDATA_ALLOW_HTTP.');
        }
        try {
            $token = Crypt::decryptString($c->cms_token);
            $url = rtrim($c->cms_url, '/').$path;
            $options = ['query' => $query];
            if ($body !== null) {
                $options['json'] = $body;
            }
            // Never follow redirects with a token and never automatically retry device writes.
            $response = Http::withHeaders(['X-Token' => $token])->acceptJson()->connectTimeout(5)->timeout(30)
                ->withOptions(['allow_redirects' => false])->send($method, $url, $options);
        } catch (\Throwable $e) {
            throw new RuntimeException('CMS tidak merespons atau kredensial tidak dapat dibaca. Periksa jaringan, sertifikat, dan APP_KEY.');
        }
        if (! $response->successful()) {
            throw new RuntimeException('CMS mengembalikan HTTP '.$response->status().'.');
        }
        $data = $response->json();
        if (! is_array($data) || ! array_key_exists('code', $data)) {
            throw new RuntimeException('Format respons CMS tidak sesuai dokumentasi.');
        }
        // Some firmware adds another code/data envelope. Check every layer, not just HTTP 200.
        for ($i = 0; $i < 5 && array_key_exists('code', $data); $i++) {
            if (! in_array($data['code'], [0, '0'], true)) {
                throw new RuntimeException('CMS/OLT menolak permintaan (kode '.(is_scalar($data['code']) ? substr((string) $data['code'], 0, 20) : '?').').');
            }
            $data = $data['data'] ?? [];
            if (! is_array($data)) {
                throw new RuntimeException('Data CMS tidak valid.');
            }
        }
        if (array_key_exists('code', $data)) {
            throw new RuntimeException('Envelope CMS tidak dikenali.');
        }
        if ((int) ($data['FailNum'] ?? 0) > 0 || ! empty($data['FailList'])) {
            throw new RuntimeException('OLT melaporkan kegagalan sebagian operasi. Periksa keadaan perangkat sebelum mengulang.');
        }

        return $data;
    }

    public function module(string $module, string $olt, array $args = [], bool $write = false): array
    {
        if ($write && ! DB::table('provisioning_connections')->where('id', 1)->value('allow_writes')) {
            throw new RuntimeException('Perintah tulis CMS belum diizinkan pada pengaturan.');
        }

        // The PDF specifies PonId/OnuId in the GET body for onu_wan_get (pp. 296-297).
        $bodyArgs = $write || $module === 'onu_wan_get';

        return $this->request($write ? 'POST' : 'GET', '/v1/openapi/iot/mqtt/proxy/cgi-bin/h.cgi',
            ['module' => $module, 'externalId' => $olt, ...($bodyArgs ? [] : $args)], $bodyArgs ? $args : null);
    }

    public function pages(bool $olts): array
    {
        $all = [];
        for ($page = 1; $page <= 200; $page++) {
            $params = ['current' => $page, 'size' => 100, ...($olts ? ['category' => 'OLT'] : ['listType' => 'allOnuList', 'channel' => 'OMCI'])];
            $data = $this->request($olts ? 'GET' : 'POST', '/v1/openapi/cms/devices/page', $olts ? $params : [], $olts ? null : $params);
            $p = $data['page'] ?? null;
            if (! is_array($p) || ! is_array($p['records'] ?? null) || ! is_numeric($p['total'] ?? null)) {
                throw new RuntimeException('Pagination CMS tidak valid.');
            }
            $all = array_merge($all, $p['records']);
            if (count($all) > 20000) {
                throw new RuntimeException('Sinkronisasi melebihi 20.000 perangkat.');
            }
            if (count($all) >= (int) $p['total']) {
                return $all;
            }
            if (! $p['records']) {
                throw new RuntimeException('Pagination CMS terputus.');
            }
        }
        throw new RuntimeException('Pagination CMS melebihi batas.');
    }
}
