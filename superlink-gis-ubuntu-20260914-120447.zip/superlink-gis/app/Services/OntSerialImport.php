<?php

namespace App\Services;

use App\Models\Device;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class OntSerialImport
{
    public function preview(string $text): array
    {
        $tokens = preg_split('/[\s|,;]+/u', strtoupper(trim($text)), -1, PREG_SPLIT_NO_EMPTY);
        $tokens = array_values(array_filter($tokens, fn ($s) => ! preg_match('/^:?-+:?$/', $s)));
        if (count($tokens) > 1000) {
            throw ValidationException::withMessages(['serials' => 'Maksimum 1.000 serial per impor.']);
        }
        $invalid = array_values(array_filter($tokens, fn ($s) => ! preg_match('/^[A-Z0-9][A-Z0-9._-]{2,99}$/D', $s)));
        $unique = array_values(array_unique(array_diff($tokens, $invalid)));
        $existing = Device::whereIn(DB::raw('upper(serial_number)'), $unique)->pluck('serial_number')->map(fn ($s) => strtoupper($s))->all();

        return ['total' => count($tokens), 'unique' => count($unique), 'duplicates' => count($tokens) - count($invalid) - count($unique), 'invalid' => array_values(array_unique($invalid)), 'existing' => $existing, 'ready' => array_values(array_diff($unique, $existing))];
    }

    public function import(array $data): array
    {
        return DB::transaction(function () use ($data) {
            DB::select("SELECT pg_advisory_xact_lock(hashtext('ont-serial-import'))");
            $result = $this->preview($data['serials']);
            if ($result['invalid'] || $result['total'] === 0) {
                throw ValidationException::withMessages(['serials' => 'Perbaiki serial tidak valid atau isi daftar serial terlebih dahulu.']);
            }
            foreach ($result['ready'] as $serial) {
                app(DeviceService::class)->create(['asset_tag' => 'ONT-'.Str::uuid(), 'serial_number' => $serial, 'type' => 'ONT', 'vendor' => $data['vendor'] ?? null, 'model' => $data['model'] ?? null, 'location' => $data['location'], 'notes' => 'Impor serial teks']);
            }

            return $result;
        });
    }
}
