# Update pencarian ONT dan Telegram — 14 September 2026

Paket ini mengikuti format source Docker sebelumnya. Ekstrak folder `superlink-gis/` ke lokasi deployment existing setelah backup database dan storage. Pertahankan `.env` serta `APP_KEY` server. ZIP tidak membawa database, upload, token, vendor, node_modules, atau asset build lokal. Docker membangun frontend dan menginstal dependency dari lockfile.

Dari folder deployment yang berisi `docker-compose.yml`, jalankan:

```bash
sudo docker compose stop queue scheduler
sudo docker compose build
sudo docker compose run --rm init
sudo docker compose up -d
sudo docker compose logs --tail=80 app queue scheduler
```

Lanjutkan ke `up -d` hanya setelah build dan init berhasil. Init menjalankan migration baru `2026_09_14_000017_create_monitoring_incidents`. Jangan memakai `migrate:fresh` atau menghapus volume database. Setelah update, refresh paksa browser untuk memuat pencarian ONT terbaru. Pencarian deskripsi/SN sekarang dapat digunakan tanpa memilih OLT.

Telegram default nonaktif sehingga update dapat dipasang sebelum token bot tersedia. Untuk mengaktifkan, isi variabel Telegram dari `.env.server.example` ke `.env` server mengikuti [panduan Telegram](telegram-monitoring.md). Setelah mengubah `.env`, terapkan ulang container dan verifikasi:

```bash
sudo docker compose up -d --force-recreate app queue scheduler
sudo docker compose exec app php artisan telegram:check
```

Scheduler existing sudah menjalankan polling command dan alert; tidak perlu menambah cron atau bot terpisah. Gunakan `/start`, `/onu nama-pelanggan`, `/status`, dan `/incidents` untuk memeriksa bot.

Validasi sebelum packaging: pemeriksaan TypeScript dan build Vite berhasil pada sesi implementasi; suite backend 120 tes lulus, serta pengujian lanjutan 10 tes Telegram lulus. Docker build server dan pengiriman Telegram live belum diuji dari komputer ini. Keterbatasan data alarm dan pengiriman tercatat dalam panduan Telegram.
