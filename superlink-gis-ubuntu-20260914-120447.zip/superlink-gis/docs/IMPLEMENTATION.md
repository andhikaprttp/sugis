# Implementation plan

1. PostgreSQL/PostGIS migration, API authentication and RBAC.
2. GIS CRUD, hierarchy, individual ODP ports and topology.
3. Safe KML/KMZ parsing, staged review and transactional import.
4. Customer database, spreadsheet review and export.
5. Survey spatial recommendations, route estimation and atomic reservation.
6. Inertia/Vue/Leaflet working interface, dashboard and administration.
7. Automated tests, Docker and operating documentation.
8. CDATA CMS connector: encrypted credentials, scheduled OLT/ONU snapshots, customer SN matching, discovery, verified suspend/resume and profile-based GPON SN registration/WAN configuration. Device jobs use encrypted payloads, no automatic retries, result history, and explicit reconciliation for uncertain outcomes. Router/RADIUS session monitoring awaits platform details.
9. Ubuntu 24.04 deployment: see [operating guide](UBUNTU-24.04.md), including Docker worker/scheduler, CMS setup at 10.1.1.21, application host 10.1.1.40, and backup/update instructions.

Updated stack: Laravel 12, PHP 8.3, Eloquent, Laravel migrations, Inertia/Vue 3, TypeScript, Tailwind, Leaflet, PostGIS and Redis Queue. The requested Laravel monolith and Ubuntu/Docker deployment take precedence over Sites scaffolding/hosting. No Python/Node backend or React frontend remains. Parameterized native spatial SQL provides PostGIS integration. Geometry lives canonically in gis_objects; typed domain records reference it. Customer topology derives from its single assigned port and ODP hierarchy.
