# Telegram monitoring Superlink

Fitur terintegrasi ke Laravel/Vue existing, tanpa dependency baru. Snapshot CMS/PPPoE tetap diisi collector existing; command Telegram tidak memanggil CDATA atau MikroTik. Tidak ada operasi reboot, suspend, disconnect atau perubahan konfigurasi perangkat dari bot.

## Aktivasi

1. Buka akun resmi [@BotFather](https://t.me/BotFather), jalankan `/newbot`, lalu simpan token pada environment server. Jangan menempelkan token pada chat, URL browser, screenshot atau log.
2. Buka bot baru dan tekan Start. Untuk grup, tambahkan bot sebagai anggota dengan izin mengirim pesan. Dapatkan numeric user ID dan chat ID milik operator/grup Anda. Chat ID grup biasanya negatif; username Telegram bukan numeric ID.
3. Isi `.env` server:

```dotenv
TELEGRAM_ENABLED=true
TELEGRAM_BOT_TOKEN=isi_token_dari_botfather
TELEGRAM_CHAT_ID=-1001234567890
TELEGRAM_ALLOWED_USER_IDS=123456789,987654321
TELEGRAM_ALLOWED_CHAT_IDS=-1001234567890,123456789
TELEGRAM_DEBOUNCE_SECONDS=90
MONITORING_RX_WARNING_DBM=-27
MONITORING_MASS_THRESHOLD=5
```

Kedua allowlist wajib cocok untuk command maupun callback. Allowlist kosong menolak semua akses. Chat tujuan alert juga wajib masuk `TELEGRAM_ALLOWED_CHAT_IDS`. Token tidak ditampilkan di halaman web.

4. Jalankan deployment commands di project existing:

```sh
php artisan migrate --force
php artisan config:cache
php artisan telegram:check
```

`telegram:check` memanggil getMe dan hanya menampilkan username bot. Gunakan akun database maintenance existing untuk migrasi jika akun runtime dibatasi.

5. Jalankan scheduler Laravel existing, misalnya `php artisan schedule:work` di lokal atau cron `* * * * * cd /path/superlink-gis && php artisan schedule:run >> /dev/null 2>&1`. Worker queue existing harus tetap berjalan untuk SyncCdata dan SyncPppoe. Jangan menjalankan scheduler tambahan jika sudah ada. Command Telegram diperiksa setiap 10 detik; incident/alert setiap menit. Satu batch menerima maksimal tiga update dan mengirim maksimal tiga alert agar pesan tidak membanjiri chat.

Bot memakai getUpdates tanpa webhook dan menyimpan offset di database. Gunakan token bot baru yang belum memiliki webhook; webhook bot lama perlu dinonaktifkan sebelum polling. Lihat [Telegram Bot API](https://core.telegram.org/bots/api#getupdates).

## Penggunaan

```text
/start
/help
/status
/customer Budi Santoso
/pppoe budi001
/onu HARIS
/onu EZXGCB03B984
/olt OLT-POP-CNK-1
/pon OLT-POP-CNK-1 0/1/1
/offline
/warning
/alarm
/incidents
```

`/customer` mencari pelanggan GIS, sedangkan `/onu` mencari deskripsi atau SN CMS termasuk ONT yang belum dipetakan ke pelanggan GIS. Pencarian parsial tidak membedakan kapital. Hasil maksimal 10 dengan tombol detail; persempit kata kunci untuk hasil lain. Acknowledge mencatat numeric user ID dan waktu, tanpa membuat incident baru. Waktu pesan dalam WIB, field kosong dihilangkan, teks pelanggan di-escape sebagai HTML.

Pencarian web berada di Daftar OLT dan Monitoring pelanggan. Tanpa memilih OLT, pencarian deskripsi/SN mencakup semua OLT. Setelah memilih OLT, hasil dibatasi OLT tersebut; pagination mempertahankan filter.

## Alert dan incident

- OLT/ONU offline, PPPoE pelanggan offline, optical warning, pemulihan, sumber monitoring tidak tersedia.
- Status UNKNOWN dibedakan dari OFFLINE, termasuk kegagalan collector, sumber nonaktif, snapshot lebih dari lima menit, atau identitas PPPoE tidak pasti.
- Gangguan harus bertahan selama debounce sebelum notifikasi. Unknown memutus jendela debounce dan tidak menandai pulih. Resolusi hanya dari pengamatan sehat yang eksplisit.
- OLT offline menekan notifikasi anak. Banyak ONU offline pada PON yang sama menghasilkan PON outage. Banyak PPPoE hilang saat ONU online menghasilkan NAS outage untuk satu sumber RouterOS existing. Threshold jumlah dapat dikonfigurasi.
- Incident disimpan dengan status OPEN / ACKNOWLEDGED / RESOLVED. `confirmed_at` memisahkan kandidat debounce dari incident yang layak ditampilkan. Optical memakai severity WARNING, gangguan memakai CRITICAL.
- Recovery dikirim setelah incident yang pernah dicoba notifikasinya pulih. Incident yang pulih sebelum notifikasi tidak menghasilkan recovery tanpa alert awal.
- Pengiriman diklaim sebelum HTTP untuk mencegah pengiriman ganda ketika hasil jaringan ambigu. `delivery_status` SENT berarti API mengonfirmasi; UNKNOWN/ATTEMPTED perlu diperiksa operator. Pengiriman ambigu tidak diulang otomatis, sehingga pesan bisa hilang saat timeout/crash. Ini pengiriman at-most-once, bukan jaminan exactly-once Telegram. Field `notified_at`/`recovery_at` adalah waktu percobaan, bukan bukti pesan diterima pengguna. Periksa log error generik dan incident via `/incidents`.

## Verifikasi

```sh
php artisan test
php artisan telegram:check
php artisan telegram:poll
php artisan telegram:alerts
```

Tes menggunakan `superlink_test`, HTTP palsu, tanpa mengirim pesan ke Telegram sungguhan. Uji live setelah konfigurasi: `/start`, pencarian ONT, pilih tombol detail, cek `/incidents` dan acknowledge. Jangan memutus pelanggan untuk menguji alert; gunakan data/perangkat lab. `telegram:alerts` benar-benar mengirim bila Telegram diaktifkan.

## Batas data existing

Arsip alarm aktif CDATA belum disimpan oleh collector. `ont_events` hanya histori perubahan status polling; `/alarm` menjelaskan hal ini dan tidak mengarang severity atau alarm LOS. Alarm CDATA otomatis belum diimplementasikan karena membutuhkan kontrak API serta penyimpanan alarm existing yang valid.

MAC, software, vendor, lastOnlineTime/lastOfflineTime belum ada pada snapshot perangkat. Pesan menampilkan data yang tersedia dan waktu pengamatan lokal. Ringkasan POP memakai pemetaan POP pelanggan GIS, maksimal 10 POP; pilihan POP melalui tombol dan korelasi khusus ODP/POP belum tersedia. Korelasi NAS hanya satu sumber RouterOS sesuai monitoring existing, bukan multi-router. PON outage berarti jumlah ONU offline melewati threshold; ketika turun di bawah threshold incident agregat pulih, meski sebagian ONU masih offline dan dapat menjadi incident individual.

## File

Baru: `config/telegram.php`, migration `2026_09_14_000017_create_monitoring_incidents.php`, `app/Services/Monitoring/{MonitoringSnapshot,IncidentMonitor}.php`, `app/Services/Telegram/{Authorization,Transport,Formatter,CommandHandler,Poller,AlertSender}.php`, `tests/Feature/TelegramTest.php`, panduan ini.

Diubah: `.env.example`, `.env.server.example`, `routes/console.php`, `app/Http/Controllers/OperationsController.php`, `resources/js/Pages/Operations/{Index,DeviceCards}.vue`, `tests/Feature/OperationsTest.php`. Asset produksi dibangun ulang di `public/build`.
