# Localhost dan persiapan VPS

## Windows saat ini

Buka http://localhost:8080/login. PostgreSQL lokal memakai port 55432.
Jika server PHP belum berjalan, jalankan dari folder proyek:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/serve-local.ps1 -Port 8080
```

Biarkan terminal terbuka. Script memakai PHP portable di `../.tools/php`, atau PHP pada PATH. Database harus sudah berjalan. Jangan menjalankan ulang pada port yang masih dipakai. Konfigurasi lokal tetap memakai `.env` yang sudah ada.

## Upload ke VPS Linux

ZIP source ada di `output/releases`. Upload dan ekstrak ke `/opt/superlink-gis`, lalu gunakan Docker Engine dan Compose v2 pada VPS:

```bash
cd /opt/superlink-gis
cp .env.server.example .env
chmod 600 .env
nano .env
```

Ganti `APP_URL` menjadi `http://IP_VPS:8080`, isi password database dan admin baru (minimal 12 karakter), dan tetap gunakan `APP_ENV=production`, `APP_DEBUG=false`, `DEMO_SEED=false`. Host database/Redis tetap `postgres` dan `redis`.

Untuk instalasi baru, generate key lalu salin hasilnya ke `APP_KEY` dalam `.env`:

```bash
docker run --rm php:8.3-cli php -r 'echo "base64:".base64_encode(random_bytes(32)).PHP_EOL;'
docker compose up -d --build
docker compose ps -a
docker compose logs --tail=100 init app nginx queue scheduler
```

Buka `http://IP_VPS:8080/login`. Init harus berstatus `Exited (0)`. Izinkan port 8080 pada firewall jika diakses langsung. Untuk domain HTTPS, pasang reverse proxy/TLS, ubah `APP_URL` dan aktifkan `SESSION_SECURE_COOKIE=true`.

ZIP hanya berisi source: database pelanggan, upload, `.env`, dan token tidak ikut. Jika ingin membawa data localhost, ikuti bagian **Jika data Windows juga ingin dibawa** di [panduan pemindahan](PINDAH-KE-SERVER.md); pertahankan APP_KEY sumber. Jangan menghapus volume database.

Build Docker perlu diverifikasi pada VPS; komputer Windows sesi ini belum memiliki Docker.
