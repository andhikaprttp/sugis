# Reminder WhatsApp

Menu **Reminder WhatsApp** di sidebar menyatukan alur SSL Blast dengan tampilan dan login aplikasi utama. Sumber referensi: https://andhikaprttp.github.io/ssl-blast/.

## Cara menggunakan

1. Pilih jumlah reminder per penerima, bulan, dan jam WIB di bagian atas. Pilih tanggal satu per satu atau interval hari. Jumlah tanggal harus sesuai jumlah reminder, semuanya dalam bulan yang sama. Default bulan berikutnya; tanggal baru yang sudah lewat ditolak.
2. Isi nama reminder dan template. Variabel: `{NAME}`, `{INVOICE}`, `{AMOUNT}`, `{DUE_DATE}`, `{LINK}`.
3. Impor CSV DOKU (maksimal 2 MB / 500 penerima) atau tambah nomor manual. Header: `Customer Name,Customer Phone,Invoice Number,Total Amount,Expired Date,Payment Link`. Total Amount berupa angka tanpa pemisah ribuan. Nomor 08… dinormalisasi ke 628…; nomor dan invoice ganda ditolak ketika disimpan.
4. Simpan draft, periksa pratinjau setiap pesan. Edit nomor/pesan khusus jika perlu. Kosongkan pesan khusus untuk memakai template.
5. **Buka WhatsApp** membuka tautan `wa.me`; Anda tetap harus menekan kirim di WhatsApp. Ini tidak tercatat sebagai pesan terkirim dalam riwayat API.
6. Dengan API dan scheduler aktif, gunakan **Aktifkan otomatis** untuk jadwal atau **Kirim lewat API** untuk mengantrekan satu pesan sekarang. Tombol terakhir tetap bisa digunakan saat jadwal dijeda.
7. Tandai **Sudah lunas** atau hapus centang **Sertakan** untuk menghentikan pengiriman penerima. Pembayaran tidak tersinkron otomatis dengan DOKU. Jeda jadwal sebelum mengubah tanggal/template. Pesan yang sudah diproses provider tidak dapat ditarik kembali.

Jadwal berlaku hanya pada bulan yang dipilih. Buat reminder baru untuk bulan lain. Riwayat menampilkan 50 pengiriman API terbaru; daftar penerima memiliki filter dan paginasi.

## Mengaktifkan pengiriman otomatis

Tautan WhatsApp Web tidak menyediakan pengiriman tanpa interaksi. Konektor Fonnte disediakan sebagai opsi; akun, perangkat pengirim, dan token harus disiapkan pada layanan tersebut. Tidak ada pesan nyata dikirim dalam pengujian implementasi ini.

Pada `.env` server (jangan di frontend atau repository):

```dotenv
BLAST_DRIVER=fonnte
BLAST_FONNTE_TOKEN=token_perangkat_anda
```

Jalankan `php artisan config:cache` dan mulai ulang worker setelah konfigurasi berubah. Untuk menonaktifkan API, kembalikan `BLAST_DRIVER=disabled`.

Endpoint tetap HTTPS `https://api.fonnte.com/send`, token pada header Authorization, tanpa mengikuti redirect. Dokumentasi provider: https://docs.fonnte.com/api-send-message/. Koneksi perangkat dan kuota harus tersedia. `providerReady` di UI berarti konfigurasi tersedia, bukan verifikasi bahwa akun terhubung atau pesan dapat terkirim.

Jalankan scheduler satu kali per menit di server Linux:

```cron
* * * * * cd /path/superlink-gis && php artisan schedule:run >> /path/superlink-gis/storage/logs/scheduler.log 2>&1
```

Jika deployment sudah menjalankan `schedule:work`, tidak perlu menambahkan cron kedua. Dengan queue selain `sync`, jalankan worker `php artisan queue:work --tries=1 --timeout=60` melalui process manager. Pastikan `retry_after` queue lebih besar dari timeout worker. Server harus hidup dan memiliki koneksi internet saat jadwal tiba.

Lokal Windows: jalankan `powershell -ExecutionPolicy Bypass -File scripts/reminders-local.ps1` di terminal tersendiri dan biarkan aktif. Skrip hanya menjalankan pemeriksaan reminder setiap menit. Scheduler lokal ini tidak otomatis berjalan setelah komputer restart. Jangan jalankan bersamaan dengan scheduler lain.

## Status dan pencegahan pesan ganda

- `PENDING`, `QUEUED`, `SENDING`: menunggu atau sedang diproses.
- `ACCEPTED`: provider menerima permintaan, **bukan bukti pesan sampai**. Belum ada webhook status pengiriman.
- `FAILED`, `BLOCKED`: penolakan provider atau konfigurasi tidak aktif.
- `UNKNOWN`: timeout, respons tidak pasti, atau worker terhenti. Periksa provider sebelum meminta pengiriman baru; tidak ada retry otomatis.
- `EXPIRED`: terlambat lebih dari 60 menit; dilewati agar server yang baru hidup tidak mengirim seluruh jadwal lama sekaligus.
- `CANCELLED`: penerima lunas/dihentikan, jadwal dijeda/dihapus, atau akses pengirim dicabut sebelum job berjalan.

Kunci unik penerima + waktu jadwal, transisi status atomik, dan satu percobaan job mencegah pemrosesan ulang rutin menghasilkan pesan ganda. Permintaan manual memiliki UUID untuk deduplikasi permintaan yang sama. Menekan kirim manual lagi setelah berhasil adalah pengiriman baru dan dapat menggandakan pesan terjadwal. Maksimal 20 pesan diproses per pemeriksaan; gunakan queue worker untuk volume lebih besar.

Akses diatur oleh `blast.view`, `blast.manage`, `blast.send`, dilindungi autentikasi, CSRF, validasi server dan audit. Administrator, NOC, serta Customer Service dapat mengelola reminder; role baca hanya dapat melihat sesuai permission. Status aktif dan izin pengirim pembuat reminder diperiksa kembali saat job berjalan. Data nomor, pesan dan invoice tersimpan pada database internal seperti data pelanggan; token tidak dikirim ke browser atau disimpan pada riwayat.

Migration dan permission saat pemasangan baru: `php artisan migrate --force` menggunakan akun migrasi, lalu `php artisan db:seed --class=RolePermissionSeeder --force`. Pada instalasi lokal yang memakai akun database terbatas, migrasi melalui `scripts/admin-artisan.php`.
