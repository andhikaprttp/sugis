# Peta dan monitoring PPPoE

Dashboard menampilkan jumlah UP, DOWN, Belum diketahui, diagram komposisi, riwayat polling, dan maksimal 12 pelanggan prioritas. Daftar lengkap status tersedia di menu Monitoring pelanggan. Customer Service mendapat ringkasan di dashboard sesuai RBAC, tetapi tidak dapat menjalankan polling manual.

## Pilihan peta

Leaflet tetap digunakan untuk layer pelanggan, jalur fiber, dan zona RT/RW. Selain gaya OSM yang tersedia, pilihan Satelit, Topografi, dan Jalan detail menggunakan raster MapTiler. Isi pada `.env`:

```dotenv
MAPTILER_KEY=key_maptiler_anda
```

Key ini dikirim ke browser; gunakan key khusus peta dan batasi origin pada pengaturan MapTiler sesuai alamat aplikasi, termasuk localhost saat pengembangan. Perhatikan kuota paket MapTiler. Tanpa key, pilihan tersebut dinonaktifkan. Jika provider gagal, aplikasi kembali ke OSM. Referensi: [MapTiler dengan Leaflet](https://docs.maptiler.com/leaflet/examples/raster-tiles-in-leaflet-js/).

## Konektor sesi PPPoE RouterOS 7

Konektor ini membaca satu router MikroTik melalui REST. CMS CDATA tetap menjadi sumber status ONT; ONT online atau dying gasp bukan bukti status sesi PPPoE. Pemilihan sumber pada form Koneksi CMS saja tidak mengaktifkan polling router.

Isi `.env` di server aplikasi:

```dotenv
PPPOE_DRIVER=mikrotik
MIKROTIK_URL=https://alamat-router
MIKROTIK_USERNAME=akun_monitoring
MIKROTIK_PASSWORD=password_akun_monitoring
MIKROTIK_ALLOW_HTTP=false
```

Gunakan base URL tanpa `/rest` dan tanpa kredensial di URL. Aktifkan REST melalui layanan `www-ssl`, gunakan sertifikat yang dipercaya container, dan akun khusus dengan izin membaca REST/PPP. Batasi akses jaringan dari server aplikasi `10.1.1.40`. Username/password di atas adalah akun API router, bukan akun PPPoE pelanggan dan bukan token CMS. Referensi: [RouterOS REST API](https://help.mikrotik.com/docs/spaces/ROS/pages/47579162/REST%2BAPI).

HTTP hanya dapat dipakai dengan `MIKROTIK_ALLOW_HTTP=true` pada RouterOS yang mendukungnya (7.9+); Basic Auth akan dikirim tanpa enkripsi, sehingga HTTPS dianjurkan. Konektor tidak menonaktifkan validasi sertifikat.

Sesuaikan kolom `pppoe_username` pelanggan dengan nama akun router secara persis, termasuk huruf besar/kecil. Polling membaca `/ppp/secret` hanya untuk nama dan service, serta `/ppp/active` untuk nama, service, alamat IP, dan uptime. Tidak ada perintah perubahan router dan tidak mengambil password PPPoE.

- **UP:** sesi PPPoE aktif ditemukan.
- **DOWN:** akun lokal ditemukan tetapi tidak mempunyai sesi PPPoE aktif.
- **Belum diketahui:** username kosong/tidak ditemukan/duplikat, konektor belum diaktifkan, atau pengamatan lebih dari lima menit.

Akun yang hanya dikelola RADIUS dapat terlihat UP ketika aktif; tanpa inventaris RADIUS, ketidakhadiran sesi tidak dianggap DOWN. Untuk sumber RADIUS/billing lain atau beberapa router, diperlukan konektor/pemetaan tambahan.

Scheduler meminta polling setiap dua menit; dashboard memperbarui ringkasan setiap 60 detik saat tab terlihat. Jika polling gagal, pengamatan terakhir dipertahankan sampai kedaluwarsa. Riwayat disimpan tujuh hari; grafik menampilkan maksimal 60 pengamatan dari 24 jam terakhir.

## Menerapkan konfigurasi Ubuntu

Setelah memperbarui source, dari direktori proyek jalankan:

```bash
docker compose up -d --build
docker compose exec app php artisan migrate --force
docker compose exec app php artisan optimize:clear
docker compose restart app queue scheduler
docker compose exec app php artisan pppoe:sync
```

Perintah terakhir digunakan setelah kredensial router terisi. Jika hanya mengubah `.env`, jalankan `docker compose up -d --force-recreate`, lalu `optimize:clear` dan restart worker/scheduler. Pastikan scheduler dan queue tetap hidup untuk polling otomatis. Untuk server PHP lokal, jalankan `php artisan optimize:clear` dan mulai ulang proses server/worker/scheduler setelah mengubah `.env`.

Koneksi router dan tile MapTiler perlu diuji menggunakan kredensial Anda; pengujian otomatis proyek menggunakan respons router tiruan.


## Peta gratis dan pengukuran elevasi

Buka **Network Map ? Gaya ? Topo gratis** untuk OpenTopoMap tanpa API key. OSM dan gaya terang/gelap tetap tersedia tanpa key; satelit MapTiler tetap opsional dan memerlukan key. Tile OpenTopoMap maksimal zoom asli 17 lalu diperbesar. Atribusi OSM/SRTM/OpenTopoMap ditampilkan pada peta. Layanan publik dapat lambat atau tidak tersedia; setelah kegagalan tile berulang aplikasi kembali ke OSM. Tidak melakukan unduhan massal/offline. Ketentuan: https://opentopomap.org/about.

Klik **Ukur jarak & elevasi**, tambahkan minimal dua titik pada peta, lalu geser penanda untuk memperbarui jalur. Tombol Selesai menambah menghentikan penambahan titik; Undo menghapus titik terakhir, Reset menghapus jalur sementara. Grafik menunjukkan jarak horizontal terhadap elevasi, dan pointer pada grafik menandai titik terkait di peta. Pengukuran ini tidak menyimpan atau mengubah inventory GIS.

Jarak dihitung langsung di browser. Setelah 1,5 detik tanpa perubahan, maksimal 100 sampel jalur dikirim melalui server ke Open Topo Data SRTM30m (tanpa key). Hasil disimpan di cache 24 jam; limiter bersama membatasi permintaan ke satu per dua detik dan 950 per 24 jam. Gunakan Redis cache pada produksi agar semua worker memakai batas yang sama. Kuota publik resmi adalah 100 titik/permintaan, 1 permintaan/detik, 1.000/hari: https://www.opentopodata.org/.

Server memerlukan akses HTTPS keluar ke api.opentopodata.org; browser memerlukan akses tile OpenTopoMap/OSM. Tidak ada paket tambahan atau migration untuk fitur ini. Koordinat jalur dikirim ke penyedia elevasi, tanpa nama pelanggan atau kredensial. Bila gagal/kuota habis, klik Coba lagi; jarak tetap tersedia. Elevasi kosong tetap kosong, bukan dianggap nol. Untuk beban operasional tinggi, pertimbangkan hosting Open Topo Data sendiri dan konfigurasi endpoint yang disesuaikan; versi ini memakai endpoint publik tetap.

Resolusi sumber SRTM sekitar 30 meter (cakupan lintang -60 sampai 60). Jalur panjang dibatasi 100 sampel sehingga jarak antarsampel dapat lebih besar. Ketinggian merupakan perkiraan medan, bukan pengukuran tiang/gedung. Grafik ini tidak menghitung Fresnel, kelengkungan bumi, redaman radio, atau slack kabel seperti alat perencanaan radio lengkap.


## Pencarian koordinat dan simulasi kabel

Kolom pencarian Network Map menerima `-6.363513, 106.758732` (latitude, longitude) atau `6?21'48.7"S 106?45'31.4"E` (DMS). Tekan Enter atau Ke koordinat untuk memusatkan peta dan menampilkan penanda. Nilai lintang/bujur dan menit/detik divalidasi. Kedua contoh tersebut sedikit berbeda karena pembulatan; parser mempertahankan nilai masing-masing.

Pilih Tambah titik kabel pada hasil koordinat untuk memasukkan titik tersebut ke jalur simulasi. Alternatifnya buka Ukur / simulasi kabel dan aktifkan Mode simulasi kabel, kemudian klik peta atau aset titik (tiang/ODP/POP) secara berurutan. Garis putus-putus mengikuti pointer untuk memperlihatkan tarikan berikutnya sebelum klik. Geser penanda untuk memperbarui jalur. Selesai menambah menghentikan penambahan dari klik peta; Undo dan Reset tersedia. Batas 50 titik.

Panel menampilkan panjang setiap ruas, total jarak horizontal, dan estimasi kebutuhan kabel = jarak horizontal ? (1 + slack/100) + cadangan total meter. Slack awal 10% adalah asumsi yang dapat diubah, bukan standar pemasangan. Tidak menghitung sag, tinggi tiang, rute jalan otomatis, atau hambatan. Jalur ini sementara dan tidak mengubah inventori; refresh meninggalkannya. Profil elevasi tetap memakai sumber dan batas yang dijelaskan di atas.


## Rekomendasi ODP / ODC dan tata letak perencanaan

Buka Perencanaan kabel & rekomendasi, tentukan titik pertama jalur (klik peta atau Tambah titik kabel dari pencarian), lalu pilih tab Rekomendasi. Pilih ODP/ODC, radius 50?50.000 meter dan prioritas:

- Jarak terdekat: jarak geodesik dari titik asal.
- Jarak + perubahan medan: klik Bandingkan medan. Lima kandidat disampling hingga 20 titik per jalur dalam satu permintaan elevasi; skor = jarak + 10 ? jumlah perubahan elevasi absolut. Ini heuristik perencanaan, bukan estimasi biaya konstruksi atau optimasi rute jalan. Kandidat tanpa data lengkap ditempatkan terakhir.
- Port kosong terbanyak: jumlah port tersedia, kemudian jarak, di antara maksimal lima kandidat terdekat yang lolos filter.

Opsi Hanya perangkat dengan port kosong aktif secara default. Perangkat penuh dan data port belum diketahui dilewati sebelum batas lima kandidat diterapkan. Semua mode hanya mencari perangkat ACTIVE dengan lokasi titik dalam radius. Pencarian memakai database langsung, tidak terbatas 5.000 objek yang dimuat pada peta. Klik Cari / perbarui kandidat untuk data terbaru; hasil tidak memesan port. Simulasikan jalur ke sini mengganti jalur sementara dengan garis asal?kandidat dan membuka tab kabel. Jika jalur memiliki lebih dari dua titik, aplikasi meminta konfirmasi penggantian. Anda dapat menggeser titik dan menambah belokan mengikuti kondisi lapangan.

ODP memakai port individual AVAILABLE yang tidak terhubung pelanggan atau reservasi. ODC belum mempunyai inventori port individual: jumlah kosong diambil dari pemeriksaan manual operator dengan izin odc.update. Untuk mengisi, pilih ODC dan nonaktifkan filter port kosong, cari kandidat, buka Catat pemeriksaan port ODC, lalu masukkan jumlah kosong yang benar-benar diperiksa. Nilai tidak boleh melebihi kapasitas. Sistem merekam operator/waktu dan audit. Data berlaku 24 jam; perubahan kapasitas atau kedaluwarsa mengembalikannya menjadi belum diketahui. Jumlah ODP anak tidak dianggap sebagai jumlah port terpakai ODC.

Pada desktop lebar, panel perencanaan memiliki ruang tersendiri di kanan peta. Pilihan gaya ditata dalam grid, dan marker tiang/objek belum terklasifikasi diperkecil pada zoom di bawah 16. Layar kecil memakai panel bergulir di bagian bawah.

Update Ubuntu memerlukan migration baru odc_port_observations. Backup seperti panduan server, lalu rebuild container dan jalankan `docker compose exec app php artisan migrate --force`. Tidak ada port ODC kosong yang diisi otomatis oleh migration.


## Undo / Redo jalur

Toolbar Undo/Redo berada di atas tab perencanaan dan tetap terlihat saat panel digulir. Undo membatalkan tambah titik, satu perpindahan penanda, Reset, dan penggantian jalur rekomendasi. Redo mengembalikannya. Riwayat maksimal 100 langkah; perubahan baru setelah Undo menghapus cabang Redo. Pintasan Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z atau Ctrl+Y aktif ketika panel terbuka dan fokus bukan pada input teks/angka. Jarak, kabel, dan elevasi diperbarui mengikuti jalur hasil Undo. Slack/cadangan bukan bagian dari riwayat geometri.

Tampilan citra satelit yang tersedia adalah Gaya ? Satelit (MapTiler). Isi MAPTILER_KEY mengikuti panduan di atas. OpenTopoMap tidak menyediakan citra satelit pada integrasi ini.


## Tampilan mobile

Panel perencanaan berada di bawah peta pada layar kecil dan dapat digulir sendiri. Tombol Tutup pengukuran mengembalikan area peta. Gaya peta dan Layers berada di bagian atas; metadata objek dan formulir membuka panel bawah. Pada layar desktop panel tetap di sisi kanan. Menu aplikasi dibuka dari tombol navigasi di header dan ditutup dengan tombol silang, ketukan pada latar penutup, atau Escape. Animasi mengikuti preferensi reduced motion perangkat. Setelah update, refresh paksa browser untuk memuat aset build terbaru.

## Rumah pelanggan dan jalur jalan otomatis

Setelah koordinat dikenali, tombol **Rumah pelanggan · cari ODP** menetapkan koordinat sebagai titik asal, menggambar radius awal 3 km, membuka tab Rekomendasi, dan mencari daftar ODP aktif dengan port kosong secara otomatis. Mengubah radius, jenis perangkat, atau filter port memicu pencarian ulang setelah jeda singkat. Pada panel aset titik, termasuk POLE, tombol **Ukur dari tiang/titik ini** memberikan alur yang sama.

Daftar kandidat menampilkan jarak melalui jalan dan jarak lurus. Urutan Jarak terdekat memakai jarak jalan; ketika prioritas port dipilih, jarak jalan menjadi pemecah nilai yang sama. Tombol simulasi meminta geometri rute OSRM dan tidak menggambar garis lurus bila rute jalan gagal atau kandidat tidak dapat dirutekan. Rute dibatasi menjadi maksimal 50 titik edit agar tetap ringan pada mobile. Setelah dipilih, titik dapat digeser atau ditambah untuk mengikuti jalur tiang sebenarnya.

Routing dikonfigurasi melalui:

```dotenv
ROUTING_URL=https://router.project-osrm.org
ROUTING_PROFILE=driving
```

Endpoint publik Project OSRM cocok untuk pengujian dan tidak memiliki jaminan layanan produksi. Untuk penggunaan operasional, jalankan OSRM sendiri dengan data wilayah layanan dan arahkan `ROUTING_URL` ke server tersebut. Profil yang diterima adalah `driving`, `cycling`, atau `walking`; ketersediaannya bergantung pada server yang dipilih. Dokumentasi API: https://project-osrm.org/docs/v26.4.0/http.
