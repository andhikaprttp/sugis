# Superlink di Ubuntu Server 24.04

Target: aplikasi `10.1.1.40`, CMS CDATA `10.1.1.21`. Panduan ini menggunakan Docker Compose sehingga versi PHP, PostGIS, Redis, worker dan scheduler mengikuti proyek. Tidak perlu memasang PHP/Composer/Node di host. Image dan container belum diuji di mesin Ubuntu Anda.

## 1. Persiapan host

Siapkan Ubuntu Server 24.04 64-bit, alamat 10.1.1.40 yang sudah dikonfigurasi administrator jaringan, akses sudo, ruang penyimpanan untuk database/import/backup, serta internet saat build. Untuk awal, alokasikan 4 vCPU dan RAM 8 GB lalu ukur pemakaian data sebenarnya. XML/workbook besar dapat membutuhkan memori jauh lebih besar dari ukuran file.

Pastikan host dapat mengakses CMS pada port yang digunakan:

```bash
curl -I --connect-timeout 5 http://10.1.1.21/
```

Respons 401/403 tetap menunjukkan server dapat dijangkau; belum membuktikan token API benar. Jangan memakai IP OLT sebagai base URL CMS.

## 2. Docker Engine dan Compose

Untuk host baru tanpa paket Docker yang konflik, pasang dari repository resmi. Jika sudah memiliki Docker, periksa instalasi existing terlebih dahulu. Rujukan: [instalasi Docker Engine Ubuntu](https://docs.docker.com/engine/install/ubuntu/).

```bash
sudo apt update
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
sudo tee /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker compose version
sudo docker run --rm hello-world
```

Port yang dipublikasikan Docker perlu dibatasi melalui kontrol jaringan/Docker, bukan mengandalkan UFW saja. Dokumen Docker menjelaskan bahwa publikasi port dapat melewati aturan UFW.

## 3. Salin proyek

Salin folder **superlink-gis** dari Windows ke `/opt/superlink-gis` dengan WinSCP/SFTP. Salin source, migrations, resources, `composer.lock`, `package-lock.json`, Dockerfile dan Compose. Folder runtime Windows `../.tools` tidak diperlukan. Tidak perlu mengirim `vendor`, `node_modules`, `public/build`, cache, `.git`, atau file upload untuk instalasi baru; build membuat dependensi dan aset.

```bash
cd /opt/superlink-gis
cp .env.example .env
chmod 600 .env
nano .env
```

Isi setidaknya:

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_URL=http://10.1.1.40:8080
APP_PORT=8080
DB_DATABASE=superlink
DB_USERNAME=superlink
DB_PASSWORD=ISI_PASSWORD_DATABASE_KUAT
ADMIN_EMAIL=admin@superlink.local
ADMIN_PASSWORD=ISI_PASSWORD_ADMIN_MINIMAL_12_KARAKTER
DEMO_SEED=false
SESSION_SECURE_COOKIE=false
```

Pertahankan `DB_HOST=postgres`, `DB_PORT=5432`, `REDIS_HOST=redis`, `QUEUE_CONNECTION=redis`, `CACHE_STORE=redis`. Compose juga menetapkan nilai-nilai ini pada container.

Untuk **database baru saja**, buat APP_KEY:

```bash
sudo docker run --rm php:8.3-cli php -r 'echo "base64:".base64_encode(random_bytes(32)).PHP_EOL;'
```

Masukkan hasilnya ke `APP_KEY=`. Simpan key tetap dan backup terpisah; token CMS dan payload operasi terenkripsi tidak dapat dibaca dengan key berbeda. Saat memindahkan database existing, gunakan APP_KEY existing, jangan membuat key baru.

## 4. Jalankan aplikasi

```bash
sudo docker compose up -d --build
sudo docker compose ps -a
sudo docker compose logs --tail=100 init app queue scheduler nginx
curl -I http://10.1.1.40:8080/login
```

`init` menjalankan migrasi dan seed peran/admin. Status `Exited (0)` pada init normal. `app`, `postgres`, `redis`, `queue`, `scheduler`, dan `nginx` harus berjalan. Login menggunakan akun yang Anda isi dalam .env. Seeder tidak mengganti password admin yang sudah ada.

Buka **http://10.1.1.40:8080**. Untuk port 80, gunakan `APP_PORT=80`, `APP_URL=http://10.1.1.40`, lalu jalankan Compose kembali. Untuk akses produksi, pasang terminasi TLS pada reverse proxy sesuai domain/sertifikat Anda; ubah APP_URL ke HTTPS dan SESSION_SECURE_COOKIE=true. Batasi akses aplikasi dan CMS ke jaringan pengelola. PostgreSQL/Redis tidak dipublikasikan ke host oleh Compose ini.

Upload maksimal 256 MB; PHP POST dan Nginx request 260 MB. Worker import memakai memory limit PHP 512 MB; ukuran upload bukan jaminan semua workbook/XML sebesar itu bisa diproses. Jalankan percobaan file nyata sebelum penggunaan operasional.

## 5. Hubungkan CMS

1. Login ADMIN, buka **OLT & Pelanggan Online → Koneksi CMS & PPPoE**.
2. Masukkan `http://10.1.1.21` (atau base URL HTTPS CMS bila tersedia).
3. Masukkan API key **X-Token** dari administrator CMS. Jangan mengirim token melalui chat atau menyimpannya di source.
4. Centang **Aktifkan konektor**, biarkan izin tulis mati untuk pemeriksaan awal, lalu simpan.
5. Klik **Sinkronkan CMS**, kemudian **Refresh hasil**. Periksa waktu sinkronisasi dan error.
6. Daftar OLT diperbarui dari CMS. OLT tanpa externalId dilewati; tetapkan externalId yang benar melalui CMS sebelum menggunakannya.
7. Isi serial ONT pelanggan sama dengan SN di CMS. Pencocokan mengabaikan huruf besar/kecil dan whitespace. SN duplikat diblokir untuk operasi.

Scheduler meminta sinkronisasi tiap dua menit. Snapshot lebih dari lima menit ditandai kedaluwarsa; kegagalan sinkronisasi tidak mengubah semua ONT menjadi offline. Penyebab offline mengikuti data CMS; kode yang tidak dikenal tidak ditebak menjadi dying gasp. Event disimpan 90 hari dan mencatat perubahan hasil polling, bukan semua alarm historis OLT.

Diagnosis dari container (tanpa menampilkan token):

```bash
sudo docker compose exec app php artisan cdata:sync
sudo docker compose exec app php artisan schedule:list
sudo docker compose logs --tail=100 queue scheduler
```

Sesi PPPoE memakai konektor RouterOS 7 terpisah yang dikonfigurasi melalui environment. Memilih sumber pada form saja tidak mengaktifkannya. Ikuti [setup peta dan PPPoE](PETA-DAN-PPPOE.md) untuk kredensial router, polling UP/DOWN, dan key MapTiler. Integrasi RADIUS/billing lain belum tersedia.

## 6. Template dan operasi ONT

Di **Template layanan**, pilih OLT dan isi VLAN 1–4094 serta nama Line/Service/WAN/TR-069 Profile yang **sudah tersedia di OLT**. Template lokal tidak membuat profil di OLT. WAN Profile harus menghasilkan tepat satu WAN PPPoE untuk VLAN tersebut. Binding memakai `LAN1`–`LAN4` (port 0–3) dan `SSID4`–`SSID12` (indeks WLAN CDATA langsung), dipisah koma. Verifikasi pemetaan WLAN terhadap model ONT; jangan menganggap SSID4 adalah nama Wi-Fi.

Setelah memeriksa pemetaan menggunakan ONT uji, ADMIN dapat mengaktifkan **Izinkan perintah tulis**. ADMIN/NOC dapat:

- Membuka pelanggan pada Monitoring, meninjau SN/OLT/PON/ONU, lalu Suspend atau Aktifkan kembali. Ini mengubah status administratif ONT, bukan status langganan atau akun billing.
- Membuka Aktivasi ONT, mencari pelanggan, memilih OLT, menjalankan discovery, memilih PON dengan SN yang cocok, memilih template dan ONU ID kosong, lalu memasukkan username/password PPPoE. Pastikan akun PPPoE sudah ada di router/RADIUS.

Aktivasi saat ini menggunakan autentikasi GPON SN dan profile mode. Flow membaca ulang SN, memperbarui WAN yang dibuat profil, lalu memeriksa username/VLAN. Password sering disamarkan pada readback; keberhasilan konfigurasi tidak diklaim sebagai bukti autentikasi PPPoE. Bila profil belum membuat WAN atau firmware menolak parameter, periksa hasil pada Riwayat operasi.

`QUEUED` menunggu worker, `RUNNING` sedang diproses, `SUCCEEDED` berarti verifikasi yang disebutkan pada hasil berhasil. `FAILED` berarti gagal sebelum perintah perubahan dikirim. `UNKNOWN` berarti mungkin ada perubahan/hasil sebagian; jangan mengulang registrasi secara buta. Periksa ONT di CMS, lalu gunakan **Tandai sudah diperiksa di CMS** untuk rekonsiliasi. Ini tidak membatalkan atau mengulang perintah. Perbaikan WAN setelah registrasi sebagian dilakukan melalui CMS pada versi ini.

Token disimpan terenkripsi dengan APP_KEY. Password PPPoE berada dalam payload antrean terenkripsi di database dan dihapus setelah operasi selesai/gagal. Queue berisi ID operasi, bukan password. Operasi tidak di-retry otomatis. Watchdog scheduler menutup pekerjaan yang terhenti lebih dari 20 menit sebagai UNKNOWN. Tidak ada perintah perangkat yang dijalankan hanya karena menyimpan template.

## 7. Backup, pemindahan data, dan update

Sebelum update, backup database, storage, dan APP_KEY/.env di lokasi terlindungi:

```bash
mkdir -p backups
chmod 700 backups
sudo docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > backups/superlink.dump
sudo docker compose exec -T app tar -czf - -C storage app/private > backups/storage.tgz
chmod 600 backups/superlink.dump backups/storage.tgz
```

Untuk memindahkan database development, buat dump dengan pg_dump di komputer sumber dan salin dump beserta storage private. Hentikan queue/scheduler sebelum restore, gunakan database target kosong, dan pakai APP_KEY sumber. Pemindahan akan membawa akun serta data demo existing; DEMO_SEED=false tidak menghapus data yang sudah ada. Uji restore di database terpisah terlebih dahulu. Jangan menjalankan `migrate:fresh` atau `docker compose down -v` pada data yang ingin dipertahankan.

Setelah mengganti source dengan versi terbaru:

```bash
sudo docker compose stop queue scheduler
sudo docker compose build
sudo docker compose run --rm init
sudo docker compose up -d --force-recreate app queue scheduler nginx
sudo docker compose ps -a
```

Jangan mengganti APP_KEY selama update. Rollback source harus mempertimbangkan kompatibilitas migrasi; jangan menghapus kolom/data produksi tanpa rencana restore.

## Batas pengujian

Konektor diverifikasi memakai respons CMS tiruan berdasarkan PDF API CDATA. Belum ada token atau koneksi CMS live yang diuji dalam sesi implementasi. Perbedaan firmware, dukungan OMCI, struktur WAN tambahan, skala/unit RX/TX dan akses profil harus dikonfirmasi pada perangkat Anda. Nilai RX/TX ditampilkan sebagaimana respons CMS tanpa mengarang konversi satuan. Docker Compose dan instalasi Ubuntu perlu diuji pada host tujuan.
