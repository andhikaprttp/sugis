# Validation — 7 September 2026

## Executed successfully

- Login password visibility toggle added with accessible button name/state and no form submission on toggle. Basemap picker expanded to seven OSM visual styles in a collapsible panel. Four frontend tests passed, including persistence validation and explicit-style preservation across theme changes. Interactive browser verification remains unavailable.

- Customer Service RBAC: full suite passed **45 tests / 302 assertions**, including denial of direct non-customer URLs, customer-only dashboard payload, prevention of self-escalation, ADMIN assignment to existing/new users, and self-demotion protection. Existing account roles were not reassigned; role definitions were seeded locally. Sidebar hides empty groups and customer pages avoid unauthorized network API requests.

- CDATA connector: full suite **43 tests / 263 assertions** passed; after enforcing documented GET-body WAN parameters and repeat SN verification, the focused connector suite passed **8 tests / 52 assertions**. Final TypeScript/Vite build passed, and `artisan schedule:list` / `route:list --path=cdata` verified registration. Tests use fake CMS responses; no token or live device was contacted. Coverage includes nested CMS/OLT errors, mapping, stale/error preservation, idempotency, mismatched SN, uncertain write outcomes, token encryption/redaction, and registration/WAN credential handling.
- Ubuntu guide added at `docs/UBUNTU-24.04.md`; Compose includes a scheduler alongside the existing queue. Ubuntu host deployment and Docker image startup were not available for validation in this workspace. Router/RADIUS PPPoE session connector is pending the actual platform details and is not simulated as online.

- Operations menu release: full PHPUnit suite passed **35 tests / 212 assertions**. Includes all eight operation pages, OLT/template validation and persistence, audit recording, role restrictions, and proof that menu/configuration requests send no device HTTP requests. Development/test migrations applied. Live CMS/router integration remains unimplemented; monitoring state is unknown rather than inferred from customer subscription status.

- Resolved the actual user's PHP upload-size failure on port 8088: its old process logged upload_max_filesize=2M / post_max_size=8M. Restarted that process with explicit 256M / 260M settings and project upload temp directory. Real KMZ 32 MB and XLSX 32.01 MB uploads to 127.0.0.1:8088 both reached READY; smoke staging records/files were cleaned. Local startup script now accepts a Port parameter.

- After raising upload limits, real multipart KMZ 32 MB and XLSX 32.01 MB requests to localhost:8080 returned HTTP 302 and READY staging status. Test jobs and files were cleaned without inventory commits.

- PHP 8.3.33, Laravel 12.69.1; Composer dependencies installed with lockfile.
- PostgreSQL 17.6 / PostGIS 3.5.0 local database at 127.0.0.1:55432.
- Laravel migrations applied to development and separate `superlink_test` databases.
- Role/admin/network/customer demo seed completed; all coordinates are dummy.
- PHPUnit: **29 tests, 148 assertions passed**, including actual two-process port reservation contention, RT/RW metadata and statistics, spatial zone counts, and upload failure handling.
- HTTP tests: authenticated Inertia workspaces, map API, KML staging/review/commit, Excel generation/download.
- Vitest: **4 tests passed** (availability display, theme preference and automatic map style).
- Vue TypeScript checking and Vite production build passed for dark mode/map redesign, RT/RW layers/statistics, and reactive import endpoints.
- Laravel Pint formatting and format check passed.
- Local development server restarted on port 8080 after the final UI pass; port 8088 was used for earlier HTTP verification.
- Real authenticated multipart uploads to port 8080 passed: 3 MB KMZ produced HTTP 302 / READY / 3 staged rows; 3.01 MB XLSX produced HTTP 302 / READY / 1 staged row. Smoke-test records/files were removed without committing inventory. Reproduce locally with `php scripts/check-http-uploads.php` while the server is running.
- Upload regression tests cover numeric Excel RT/RW cells, invalid port values, corrupt KMZ errors, and malformed geometry that must not abort valid staged rows.
- RT/RW migration applied to development and test databases; statistics include customers without geometry and exclude soft-deleted records. No administrative boundaries were fabricated or seeded.

## Not executed / environmental limits

- Upload limit update: PHP 256M / POST 260M, Nginx 260m, Laravel 262144 KB, frontend and KMZ checks 256 MB. Expanded archive/XML bound is 512 MB. Nine focused zone/upload tests passed (66 assertions), including acceptance at 256 MB and rejection at 256 MB + 1 KB using simulated file sizes. TypeScript/Vite production build passed. A real 255 MB multipart attempt exceeded the smoke client's 120-second timeout before PHP accepted the full request; successful near-limit parsing is not claimed.

- Browser runtime discovery returned no available browser. Visual review, touch/mobile interaction, geolocation prompts, tile rendering, and full click-through E2E remain unverified.
- Docker Engine unavailable. Dockerfile/Compose are supplied but image build and container startup were not executed here.
- Redis integration was not exercised locally: local tests used sync queue/file or array cache. Compose forces Redis queue/cache independently of local development `.env` host values.
- No stress test of 20,000-row commits or 5,000-feature browser rendering, and no Excel/LibreOffice GUI or Google Earth application available for visual interoperability checks. Generated workbook structure and KML parsing were checked automatically.

The frontend stores theme/map style preferences only in localStorage. Network/customer/import data remains in PostgreSQL/PostGIS. Jalan/Fokus/Malam remain visual treatments of OSM tiles. Optional satellite/outdoor/street-detail providers now require a MapTiler key; live provider rendering has not been verified.

## Dashboard and PPPoE update ? 2026-09-07

- Backend: 49 tests / 320 assertions passed. Covers RouterOS read-only requests, UP/DOWN/UNKNOWN, failed polling preserving snapshots, five-minute expiry, changed/duplicate usernames, disabled connector, and CS permission boundaries.
- Frontend: 4 tests passed; TypeScript and Vite production build passed.
- Monitoring migrations and username index applied to development and test databases. Scheduler lists PPPoE every two minutes, conditional on configured credentials.
- No live RouterOS or MapTiler credentials supplied; no live router polling or satellite tile rendering verified. Browser visual QA remains unavailable.

## Free topographic map and elevation measurement ? 2026-09-07

- Three focused backend tests passed (11 assertions): coordinate validation, CS access denial, cached elevation, null preservation, incomplete upstream response and shared rate limit.
- Eight frontend tests passed, including known distance, bent routes, repeated/empty points, sample bounds and dateline crossing. Final TypeScript/Vite production build passed.
- Live read-only checks: OpenTopoMap tile returned HTTP 200 image/png; Open Topo Data SRTM30m returned OK and elevation for a public test coordinate in Jakarta.
- Browser visual interaction and full end-to-end profile rendering remain unverified. Public provider availability is not guaranteed; error/fallback states are implemented.

## Coordinate search and cable simulation ? 2026-09-07

- 11 frontend tests passed, including the supplied decimal/DMS examples, Unicode prime marks, coordinate bounds, invalid minute values, and cable slack/reserve arithmetic.
- TypeScript and final Vite production build passed. No backend/schema changes.
- Added temporary cable spans, pointer preview, draggable points, coordinate/asset insertion and adjustable slack/reserve. Browser interaction has not been visually verified.

## Recommendations and planner layout ? 2026-09-07

- Three backend tests / 13 assertions passed: full nearest cabinets skipped before limit, inactive exclusion, ODC unknown/manual observation/expiry/capacity mismatch, bounds and CS authorization.
- Thirteen frontend tests passed, including flatter-path ranking, missing terrain, port ranking and previous coordinate/cable regressions.
- New ODC observation migration applied to development and test databases. Manual observations are audited and expire after 24 hours.
- TypeScript/Vite build passed. Visual browser QA unavailable; terrain comparisons use the previously verified elevation service, with mocked ranking tests rather than live customer route requests.

Undo/Redo update: 15 frontend tests passed, including independent snapshots, drag/reset/replacement restoration, redo invalidation and 100-step history cap. TypeScript/Vite build passed. Browser keyboard/drag visual QA remains unverified.

MapTiler live verification: configured key returned HTTP 200 metadata and image tiles for maps/satellite/256, maps/streets-v4/256 and maps/outdoor-v4/256, with CORS *. Previous tiles/satellite-v4 returned 404; satellite now uses the verified 256px Maps endpoint. APP_URL aligned with local 127.0.0.1:8088 and configuration cache cleared. Windows trusted TLS used for checks; bundled PHP reported missing certificate issuer, without disabling TLS verification. No key or response URLs logged.

## Responsive UI and motion update ? 2026-09-07

- TypeScript/Vite production build and all 15 frontend regression tests passed.
- Map page uses dynamic viewport height; planner becomes a bottom panel below 1,000px, with separate short-landscape rules. Main navigation uses overlay, close button, Escape, focus containment and inert hidden navigation below 1,024px. Mobile inputs use 16px text and larger touch targets.
- Reduced-motion preferences disable transitions. Leaflet size changes are coalesced with requestAnimationFrame and pan:false to reduce layout jitter.
- Browser skill bootstrap and troubleshooting returned no connected browsers. Desktop/mobile visual inspection, touch gestures, keyboard navigation and screen-reader testing remain unverified.

## Automatic customer-home recommendations and road routing — 2026-09-10

- Six focused backend tests / 20 assertions passed for recommendation filtering, ODC observations, OSRM table distances, unroutable null results, GeoJSON coordinate conversion, 50-point editor bound, redirects, and malformed responses.
- Twenty frontend tests passed. TypeScript/Vite production build passed after removing an accidental internal Vitest import from runtime `theme.ts`.
- Live OSRM request for a local example returned HTTP 200 / `Ok`, about 1.1 km and 53 source geometry points. Application results are bounded to 50 editable points.
- Candidate search is automatic after the home coordinate or a point asset becomes the origin. Road-routing failure remains visible and does not silently create a straight route. Browser visual interaction remains unverified.

### Pembaruan navigasi peta dan mobile (10 September 2026)
- Perencanaan kabel dibuka melalui navbar; panel tertutup tidak menutupi peta.
- Mobile memakai navigasi bawah sesuai permission, dengan pengaturan bahasa/tema di menu.
- Panel peta menggunakan tombol tutup berlabel dan target sentuh 44 px. Escape menutup perencanaan.
- Tinggi peta menyesuaikan navbar, filter area, navigasi bawah, dan safe area perangkat.
- Validasi: 20 tes frontend lulus. Pemeriksaan visual langsung desktop/mobile masih perlu dilakukan.


### Komponen UI dan navigasi bersama (11 September 2026)
- Lima kelompok navigasi dengan satu kelompok terbuka, pencarian menu, dan penanda halaman/subhalaman aktif; seluruh URL dan pemeriksaan permission tetap dipertahankan.
- Drawer mobile mendukung Escape, fokus keyboard, bahasa/tema, dan tombol sentuh; navigasi bawah menandai halaman detail pelanggan.
- Form, kartu, tabel, pagination, dan filter pelanggan menggunakan jarak dan ukuran yang konsisten. Tabel/pagination bisa digeser pada layar sempit tanpa menyembunyikan data.
- 20 tes frontend lulus. Browser runtime tidak memiliki browser terhubung, sehingga verifikasi visual Android/iOS belum dilakukan.
