<?php

namespace Tests\Feature;

use App\Jobs\RunDeviceOperation;
use App\Models\Customer;
use App\Models\User;
use App\Services\Cdata\CdataClient;
use App\Services\Cdata\CdataSync;
use App\Services\Customer\CustomerService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Tests\TestCase;

class CdataConnectorTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        config(['cdata.allow_http' => true]);
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'CMS test', 'email' => uniqid().'@test.invalid', 'password' => 'Strong-test-password', 'active' => true]);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
        DB::table('provisioning_connections')->updateOrInsert(['id' => 1], ['cms_url' => 'http://cms.test', 'pppoe_source' => 'UNCONFIGURED', 'cms_token' => Crypt::encryptString('secret-cms-token'), 'enabled' => true, 'allow_writes' => true, 'created_at' => now(), 'updated_at' => now()]);
        Http::preventStrayRequests();
    }

    public function test_http_is_rejected_before_transmitting_token_unless_opted_in(): void
    {
        config(['cdata.allow_http' => false]);
        Http::fake();
        try {
            app(CdataClient::class)->module('onu_info_detail', 'OLT-A');
            $this->fail('HTTP must be rejected');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('HTTPS', $e->getMessage());
        }
        Http::assertNothingSent();
    }

    public function test_redirect_response_is_rejected_without_forwarding_token(): void
    {
        Http::fake(['*' => Http::response('', 302, ['Location' => 'https://untrusted.test'])]);
        try {
            app(CdataClient::class)->module('onu_info_detail', 'OLT-A');
            $this->fail('Redirect must be rejected');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('302', $e->getMessage());
        }
        Http::assertSentCount(1);
        Http::assertSent(fn ($request) => str_starts_with($request->url(), 'http://cms.test/'));
    }

    private function customer(): Customer
    {
        return app(CustomerService::class)->save(['customer_id' => 'CMS-'.Str::random(8), 'name' => 'CMS Customer', 'ont_serial_number' => 'CDAT12345678', 'status' => 'PROSPECT']);
    }

    private function snapshot(): void
    {
        DB::table('ont_snapshots')->insert(['sn' => 'CDAT12345678', 'olt_external_id' => 'OLT-A', 'pon_id' => '0/0/1', 'onu_id' => 1, 'ont_state' => 'ONLINE', 'admin_state' => 'ACTIVE', 'observed_at' => now()]);
    }

    private function response(array $data)
    {
        return Http::response(['code' => 0, 'data' => ['code' => 0, 'data' => $data]], 200);
    }

    public function test_client_checks_nested_error_and_does_not_retry(): void
    {
        Http::fake(['*' => Http::response(['code' => 0, 'data' => ['code' => 5, 'description' => 'secret-cms-token']], 200)]);
        try {
            app(CdataClient::class)->module('onu_info_detail', 'OLT-A');
            $this->fail('Must reject nested failure');
        } catch (\RuntimeException $e) {
            $this->assertStringNotContainsString('secret-cms-token', $e->getMessage());
        }
        Http::assertSentCount(1);
        Http::assertSent(fn ($r) => $r->hasHeader('X-Token', 'secret-cms-token'));
    }

    public function test_sync_paginates_and_maps_ont_without_inventing_pppoe(): void
    {
        Http::fake(function ($r) {
            if ($r->method() === 'GET') {
                return $this->response(['page' => ['records' => [['deviceId' => 'dev-a', 'externalId' => 'OLT-A', 'deviceName' => 'OLT A', 'ip' => '10.1.1.22']], 'total' => 1]]);
            }

            return $this->response(['page' => ['records' => [['sn' => 'cdat12345678', 'oltId' => 'dev-a', 'ponId' => '0/0/1', 'onuId' => 1, 'omciRunningState' => 'offline', 'deactive' => false, 'offlineReason' => 'Dying Gasp', 'rxPower' => '-22.5']], 'total' => 1]]);
        });
        $this->customer();
        app(CdataSync::class)->run();
        $this->assertDatabaseHas('ont_snapshots', ['sn' => 'CDAT12345678', 'olt_external_id' => 'OLT-A', 'ont_state' => 'OFFLINE', 'admin_state' => 'ACTIVE', 'offline_reason' => 'Dying Gasp']);
        $this->get('/operations/monitoring?state=DYING_GASP')->assertInertia(fn ($p) => $p->where('customers.total', 1));
        $this->get('/operations/monitoring?state=ONLINE')->assertInertia(fn ($p) => $p->where('customers.total', 0));
        Http::assertSentCount(2);
    }

    public function test_olt_without_external_id_is_visible_and_linked_to_customer(): void
    {
        $customer = $this->customer();
        Http::fake(function ($request) {
            return $this->response(['page' => ['records' => $request->method() === 'GET'
                ? [['deviceId' => 'cms-device', 'externalId' => null, 'deviceName' => 'Detected OLT', 'runningState' => 'online', 'model' => 'FD1616', 'ip' => '10.1.1.22']]
                : [['sn' => 'CDAT12345678', 'oltId' => 'cms-device', 'ponId' => '0/0/1', 'onuId' => 3, 'omciRunningState' => 'online']], 'total' => 1]]);
        });
        app(CdataSync::class)->run();
        $this->assertDatabaseHas('cms_olt_snapshots', ['device_id' => 'cms-device', 'external_id' => null, 'state' => 'ONLINE', 'online_count' => 1]);
        $this->assertDatabaseHas('ont_snapshots', ['sn' => 'CDAT12345678', 'olt_device_id' => 'cms-device', 'olt_external_id' => null]);
        $this->assertDatabaseMissing('provisioning_olts', ['external_id' => 'cms-device']);
        $this->get('/operations/monitoring')->assertInertia(fn ($p) => $p->where('customers.data.0.olt_name', 'Detected OLT')->where('cmsOnus.data.0.olt_name', 'Detected OLT'));
        $this->get('/operations/olts')->assertInertia(fn ($p) => $p->where('cmsOlts.data.0.name', 'Detected OLT'));
        $this->get('/customers/'.$customer->id)->assertInertia(fn ($p) => $p->where('customer.cms.olt_name', 'Detected OLT'));
        Http::fake(['*' => Http::response('unavailable', 503)]);
        try {
            app(CdataSync::class)->run();
            $this->fail('Expected sync failure');
        } catch (\RuntimeException $e) {
            $this->assertDatabaseHas('cms_olt_snapshots', ['device_id' => 'cms-device', 'state' => 'ONLINE']);
        }
    }

    public function test_failed_sync_keeps_last_snapshot(): void
    {
        $this->snapshot();
        Http::fake(['*' => Http::response('bad', 503)]);
        try {
            app(CdataSync::class)->run();
        } catch (\RuntimeException $e) {
        }
        $this->assertDatabaseCount('ont_snapshots', 1);
        $this->assertNotNull(DB::table('provisioning_connections')->value('last_error'));
    }

    public function test_suspend_is_idempotent_checks_identity_and_result(): void
    {
        $c = $this->customer();
        $this->snapshot();
        $reads = 0;
        Http::fake(function ($r) use (&$reads) {
            if ($r->method() === 'POST') {
                return $this->response(['SuccessNum' => 1, 'FailNum' => 0]);
            }$reads++;

            return $this->response(['PonSn' => 'CDAT12345678', 'ControlFlag' => $reads === 1 ? 1 : 0]);
        });
        $body = ['request_id' => (string) Str::uuid(), 'customer_id' => $c->id, 'action' => 'SUSPEND', 'confirmed' => true];
        $this->post('/cdata/operate', $body)->assertRedirect('/operations/history');
        $this->post('/cdata/operate', $body)->assertRedirect('/operations/history');
        $this->assertDatabaseHas('device_operations', ['id' => $body['request_id'], 'status' => 'SUCCEEDED', 'payload' => null]);
        $this->assertSame('PROSPECT', $c->fresh()->status);
        Http::assertSentCount(3);
    }

    public function test_wrong_sn_prevents_device_write(): void
    {
        $c = $this->customer();
        $this->snapshot();
        Http::fake(['*' => $this->response(['PonSn' => 'OTHER'])]);
        $this->post('/cdata/operate', ['request_id' => (string) Str::uuid(), 'customer_id' => $c->id, 'action' => 'SUSPEND', 'confirmed' => true]);
        Http::assertNotSent(fn ($r) => $r->method() === 'POST');
        $this->assertDatabaseHas('device_operations', ['status' => 'FAILED', 'payload' => null]);
    }

    public function test_write_failure_is_unknown_and_blocks_new_operation(): void
    {
        $c = $this->customer();
        $this->snapshot();
        Http::fake(fn ($r) => $r->method() === 'POST' ? Http::response('', 504) : $this->response(['PonSn' => 'CDAT12345678', 'ControlFlag' => 1]));
        $body = ['request_id' => (string) Str::uuid(), 'customer_id' => $c->id, 'action' => 'SUSPEND', 'confirmed' => true];
        $this->post('/cdata/operate', $body);
        $this->assertDatabaseHas('device_operations', ['status' => 'UNKNOWN', 'payload' => null]);
        $this->post('/cdata/operate', [...$body, 'request_id' => (string) Str::uuid()])->assertSessionHasErrors('cms');
        Http::assertSentCount(2);
    }

    public function test_tokens_are_encrypted_never_returned_or_audited(): void
    {
        $this->post('/operations/connection', ['cms_url' => 'http://cms.test', 'pppoe_source' => 'UNCONFIGURED', 'cms_token' => 'new-secret', 'enabled' => true, 'allow_writes' => false])->assertSessionHasNoErrors();
        $encrypted = DB::table('provisioning_connections')->value('cms_token');
        $this->assertNotSame('new-secret', $encrypted);
        $this->assertSame('new-secret', Crypt::decryptString($encrypted));
        $this->get('/operations/connection')->assertDontSee('new-secret')->assertDontSee($encrypted);
        $this->assertStringNotContainsString('new-secret', json_encode(DB::table('audit_logs')->get()));
    }

    public function test_activation_encrypts_queue_payload_then_registers_and_updates_wan(): void
    {
        Queue::fake();
        $c = $this->customer();
        $olt = DB::table('provisioning_olts')->insertGetId(['name' => 'A', 'external_id' => 'OLT-A', 'created_at' => now(), 'updated_at' => now()]);
        $t = DB::table('provisioning_templates')->insertGetId(['olt_id' => $olt, 'name' => 'Internet', 'vlan' => 100, 'line_profile' => 'line', 'service_profile' => 'srv', 'wan_profile' => 'wan', 'tr069_profile' => 'tr', 'binding' => 'LAN1', 'created_at' => now(), 'updated_at' => now()]);
        $id = (string) Str::uuid();
        $this->post('/cdata/operate', ['request_id' => $id, 'customer_id' => $c->id, 'action' => 'ACTIVATE', 'confirmed' => true, 'template_id' => $t, 'pon' => '0/0/1', 'onu' => 2, 'username' => 'subscriber', 'password' => 'subscriber-secret'])->assertSessionHasNoErrors();
        $this->assertStringNotContainsString('subscriber-secret', DB::table('device_operations')->value('payload'));
        $wan = ['Index' => 1, 'WanName' => 'Internet', 'vlanId' => 100, 'enable_vlan' => true, '802_1_mark' => 0, 'service_type' => 2, 'connection_type' => 2, 'ip_protocol' => 1, 'enable_igmp_mld_proxy' => false, 'MTU' => 1492, 'ipv4' => ['dhcp_enable' => 1], 'port_binding' => ['lan' => [0], 'ssid' => []], 'ppp' => ['username' => 'subscriber']];
        Http::fake(function ($r) use ($wan) {
            parse_str(parse_url($r->url(), PHP_URL_QUERY), $q);

            return $this->response(match ($q['module']) {
                'onu_autofind_info' => ['AutofindInfo' => [['SnVal' => 'CDAT12345678', 'PonId' => '0/0/1']]],'onu_list_get' => ['list' => []],'onu_info_detail' => ['PonSn' => 'CDAT12345678'],'onu_wan_get' => ['WanInfo' => [$wan]],default => []
            });
        });
        (new RunDeviceOperation($id))->handle(app(CdataClient::class));
        $this->assertDatabaseHas('device_operations', ['id' => $id, 'status' => 'SUCCEEDED', 'payload' => null]);
        Http::assertSent(fn ($r) => str_contains($r->url(), 'onu_wan_set') && $r['ppp']['password'] === 'subscriber-secret' && $r['Operate'] === 2);
        Http::assertSent(fn ($r) => $r->method() === 'GET' && str_contains($r->url(), 'onu_wan_get') && ! str_contains($r->url(), 'PonId') && $r['PonId'] === '0/0/1');
        $this->assertSame('subscriber', $c->fresh()->pppoe_username);
    }
}
