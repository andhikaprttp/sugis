<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\CustomerImportJob;
use App\Models\GisObject;
use App\Models\Odp;
use App\Models\OdpPort;
use App\Models\User;
use App\Services\Customer\CustomerService;
use App\Services\Customer\SpreadsheetService;
use App\Services\Gis\KmlExportService;
use App\Services\Gis\KmzImportService;
use App\Services\Network\NetworkService;
use App\Services\Network\PortService;
use App\Services\Survey\SurveyService;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Tests\TestCase;

class BusinessFlowTest extends TestCase
{
    use DatabaseTransactions;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $u = User::create(['name' => 'Test Admin', 'email' => 'test-'.uniqid().'@example.test', 'password' => 'Example-Password-123']);
        $u->assignRole('ADMIN');
        $this->actingAs($u);
    }

    private function point($type = 'ODP', $code = null, $lng = 106.76, $lat = -6.37): GisObject
    {
        return app(NetworkService::class)->save(['name' => 'Test '.$type, 'code' => $code ?? 'TEST-'.uniqid(), 'object_type' => $type, 'geometry' => ['type' => 'Point', 'coordinates' => [$lng, $lat]], 'capacity' => 8]);
    }

    private function customer(): Customer
    {
        return app(CustomerService::class)->save(['customer_id' => 'C-'.uniqid(), 'name' => 'Test Customer', 'status' => 'PROSPECT', 'geometry' => ['type' => 'Point', 'coordinates' => [106.761, -6.37]]]);
    }

    public function test_login_logout_and_invalid_password(): void
    {
        $user = auth()->user();
        auth()->logout();
        $this->post('/login', ['email' => $user->email, 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->post('/login', ['email' => $user->email, 'password' => 'Example-Password-123'])->assertRedirect('/dashboard');
        $this->assertAuthenticated();
        $this->post('/logout')->assertRedirect('/login');
        $this->assertGuest();
    }

    public function test_viewer_cannot_mutate_network_or_customer(): void
    {
        $u = User::create(['name' => 'Viewer', 'email' => uniqid().'@example.test', 'password' => 'Example-Password-123']);
        $u->assignRole('VIEWER');
        $this->actingAs($u)->postJson('/api/gis-objects', ['name' => 'No', 'object_type' => 'POLE'])->assertForbidden();
        $this->post('/customers', ['customer_id' => 'NO', 'name' => 'No'])->assertForbidden();
        $this->get('/map')->assertOk();
    }

    public function test_gis_and_odp_crud_capacity_and_audit(): void
    {
        $o = $this->point();
        $odp = Odp::findOrFail($o->id);
        $this->assertSame(8, $odp->availability()['available']);
        app(NetworkService::class)->save(['name' => 'Renamed', 'capacity' => 16], $o);
        $this->assertSame(16, $odp->fresh()->availability()['available']);
        app(NetworkService::class)->save(['capacity' => 4], $o);
        $this->assertSame(4, $odp->fresh()->availability()['available']);
        app(NetworkService::class)->delete($o);
        $this->assertSoftDeleted('gis_objects', ['id' => $o->id]);
        $this->assertDatabaseHas('audit_logs', ['model_id' => $o->id, 'action' => 'Update']);
    }

    public function test_duplicate_code_and_invalid_geometry(): void
    {
        $o = $this->point('ODP', 'DUPLICATE');
        $this->postJson('/api/gis-objects', ['name' => 'Duplicate', 'code' => 'DUPLICATE', 'object_type' => 'ODP', 'geometry' => ['type' => 'Point', 'coordinates' => [106, -6]]])->assertUnprocessable();
        $this->putJson('/api/gis-objects/'.$o->id, ['geometry' => ['type' => 'Point', 'coordinates' => [200, 95]]])->assertUnprocessable();
    }

    public function test_customer_assignment_cannot_overwrite_and_dependency_delete_blocked(): void
    {
        $o = $this->point();
        $port = OdpPort::where('odp_id', $o->id)->first();
        $c = $this->customer();
        app(PortService::class)->assign($port, $c);
        $this->assertSame(7, Odp::find($o->id)->availability()['available']);
        $this->deleteJson('/api/gis-objects/'.$o->id)->assertUnprocessable();
        $other = $this->customer();
        $this->expectException(ValidationException::class);
        app(PortService::class)->assign($port, $other);
    }

    public function test_reservation_then_installation_and_second_reservation_rejected(): void
    {
        $o = $this->point();
        $c = $this->customer();
        $s = app(SurveyService::class)->create(['customer_id' => $c->id]);
        $s = app(SurveyService::class)->route($s, [$o->id, $c->gis_object_id]);
        $this->assertGreaterThan(100, $s->route_distance);
        $s = app(SurveyService::class)->transition($s, 'WAITING_APPROVAL');
        $s = app(SurveyService::class)->transition($s, 'APPROVED');
        $p = OdpPort::where('odp_id', $o->id)->first();
        app(PortService::class)->reserve($p, $s);
        try {
            app(PortService::class)->reserve($p, $s);
            $this->fail('Double reservation allowed');
        } catch (ValidationException $e) {
            $this->assertSame('RESERVED', $p->fresh()->status);
        }$s = app(SurveyService::class)->transition($s, 'INSTALLATION');
        app(SurveyService::class)->transition($s, 'INSTALLED');
        $this->assertSame('OCCUPIED', $p->fresh()->status);
        $this->assertSame($c->id, $p->fresh()->customer_id);
        $this->assertSame('ACTIVE', $c->fresh()->status);
    }

    public function test_nearest_filters_radius_inactive_and_full_odp(): void
    {
        $near = $this->point('ODP', null, 106.76, -6.37);
        $far = $this->point('ODP', null, 107, -6.37);
        $inactive = $this->point('ODP', null, 106.7601, -6.37);
        $inactive->update(['status' => 'INACTIVE']);
        $found = app(SurveyService::class)->nearest(106.76, -6.37);
        $ids = array_column($found, 'id');
        $this->assertContains($near->id, $ids);
        $this->assertNotContains($far->id, $ids);
        $this->assertNotContains($inactive->id, $ids);
        OdpPort::where('odp_id', $near->id)->update(['status' => 'DISABLED']);
        $this->assertNotContains($near->id, array_column(app(SurveyService::class)->nearest(106.76, -6.37), 'id'));
    }

    public function test_kmz_security_and_roundtrip(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'kmz');
        $z = new \ZipArchive;
        $z->open($path, \ZipArchive::OVERWRITE);
        $z->addFromString('doc.kml', file_get_contents(base_path('samples/network.kml')));
        $z->close();
        $this->assertCount(3, app(KmzImportService::class)->parse($path, 'sample.kmz')['objects']);
        unlink($path);
        $o = $this->point();
        $kml = app(KmlExportService::class)->generate([$o]);
        $this->assertStringContainsString($o->code, $kml);
        $this->assertStringNotContainsString('password', $kml);
    }

    public function test_kmz_path_traversal_rejected(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'kmz');
        $z = new \ZipArchive;
        $z->open($path, \ZipArchive::OVERWRITE);
        $z->addFromString('../evil.kml', '<kml/>');
        $z->close();
        try {
            $this->expectException(\InvalidArgumentException::class);
            app(KmzImportService::class)->parse($path, 'bad.kmz');
        } finally {
            unlink($path);
        }
    }

    public function test_excel_review_duplicates_and_formula_safe_export(): void
    {
        $c = $this->customer();
        $s = app(SpreadsheetService::class);
        $book = $s->workbook(['Customers' => [['Customer ID', 'Name', 'Status', 'Latitude', 'Longitude'], ['XLS-NEW', '=HYPERLINK("evil")', 'PROSPECT', -6, 106], [$c->customer_id, 'Duplicate', 'PROSPECT', null, null], ['XLS-OK', 'Good', 'PROSPECT', -6.37, 106.76]]]);
        Storage::makeDirectory('tests');
        $path = 'tests/'.uniqid().'.xlsx';
        (new Xlsx($book))->save(Storage::path($path));
        $j = CustomerImportJob::create(['filename' => 'test.xlsx', 'path' => $path, 'uploaded_by' => auth()->id()]);
        $s->parse($j);
        $j->refresh();
        $this->assertSame(1, $j->invalid_rows, json_encode($j->rows->toArray()));
        $this->assertSame(1, $j->duplicate_rows, 'duplicate count');
        $this->assertSame(1, $j->valid_rows, 'valid count');
        $this->assertDatabaseMissing('customers', ['customer_id' => 'XLS-OK']);
        $s->commit($j, [$j->rows()->where('validation', 'VALID')->firstOrFail()->id]);
        $this->assertDatabaseHas('customers', ['customer_id' => 'XLS-OK']);
        $export = $s->export([], auth()->user()->email);
        $this->assertSame(['Customers', 'Summary', 'Metadata'], $export->getSheetNames());
        $safe = $s->workbook(['Data' => [['Name'], ['=1+1'], ['+123'], ['@formula']]]);
        $this->assertSame('s', $safe->getSheet(0)->getCell('A2')->getDataType());
        Storage::delete($path);
    }

    public function test_excel_port_conflicts_and_coordinate_validation(): void
    {
        $o = $this->point('ODP', 'XLS-ODP');
        $c = $this->customer();
        $p = OdpPort::where('odp_id', $o->id)->first();
        app(PortService::class)->assign($p, $c);
        $r = app(SpreadsheetService::class)->validateRow(['customer_id' => 'NEW', 'name' => 'New', 'status' => 'ACTIVE', 'odp_code' => 'XLS-ODP', 'port_number' => $p->port_number, 'latitude' => 100, 'longitude' => 106]);
        $this->assertArrayHasKey('port_number', $r['errors']);
        $this->assertArrayHasKey('coordinates', $r['errors']);
    }

    public function test_customer_missing_location_and_soft_delete(): void
    {
        $c = app(CustomerService::class)->save(['customer_id' => 'MISSING', 'name' => 'Missing', 'status' => 'PROSPECT']);
        $this->assertTrue(app(CustomerService::class)->query(['missing_location' => true])->whereKey($c->id)->exists());
        app(CustomerService::class)->delete($c);
        $this->assertSoftDeleted('customers',['id' => $c->id]);
    }
}
