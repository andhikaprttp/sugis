<script setup lang="ts">
import {Link} from '@inertiajs/vue3';
import {Server, Router} from 'lucide-vue-next';
import Pagination from '../../Components/Pagination.vue';
defineProps<{olts:any,onus:any,selected?:string,section:string}>();
function status(row:any, field:string){return row.observed_at && Date.now()-new Date(row.observed_at).getTime()<300000 ? row[field] : 'UNKNOWN';}
</script>
<template>
 <section class="space-y-4">
  <div><h2>Pilih OLT</h2><p class="muted mt-2">Pilih perangkat untuk melihat ONT dan nama pelanggan dari deskripsi CMS.</p></div>
  <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
   <Link v-for="o in olts.data" :key="o.device_id" :href="'/operations/'+section+'?cms_olt='+encodeURIComponent(o.device_id)" class="card device p-5" :class="{chosen:selected===o.device_id}" :aria-current="selected===o.device_id?'true':undefined">
    <div class="flex items-center justify-between gap-3"><span class="flex items-center gap-2"><Server class="h-5 w-5"/> OLT</span><span class="state" :class="status(o,'state')">{{status(o,'state')}}</span></div>
    <h3 class="mt-4 font-semibold">{{o.name}}</h3><p class="muted mt-2">{{o.model||'Model belum tersedia'}}</p><p class="muted text-sm">Serial: {{o.sn||'-'}}</p><p class="muted text-sm">IP: {{o.host||'-'}}</p><p class="mt-4 text-sm">{{o.online_count}} online / {{o.onu_count}} ONT</p>
   </Link>
  </div><p v-if="!olts.data.length" class="card p-6 muted">Belum ada OLT dari CMS.</p><Pagination :links="olts.links"/>
  <div v-if="!selected" class="card p-6 muted">Pilih salah satu OLT di atas untuk menampilkan data pelanggan dan ONT.</div>
  <template v-if="selected && onus">
   <h2>ONT pada OLT terpilih <span class="muted">({{onus.total}})</span></h2>
   <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
    <article v-for="o in onus.data" :key="o.sn" class="card device p-5">
     <div class="flex items-center justify-between gap-3"><span class="flex items-center gap-2"><Router class="h-5 w-5"/> ONT</span><span class="state" :class="status(o,'ont_state')">{{status(o,'ont_state')}}</span></div>
     <h3 class="mt-4 font-semibold">{{o.description||o.sn}}</h3><p class="muted text-sm mt-2">Serial: {{o.sn}}</p><p class="muted text-sm">OLT: {{o.olt_name||o.olt_device_id}}</p><p class="muted text-sm">PON {{o.pon_id??'-'}} / ONU {{o.onu_id??'-'}}</p><p class="mt-3 text-sm">RX {{o.rx_power??'-'}} / TX {{o.tx_power??'-'}}</p>
     <Link v-if="o.gis_customer_id" :href="'/customers/'+o.gis_customer_id" class="link mt-4 inline-block">Buka pelanggan GIS</Link><p v-else class="muted mt-4 text-sm">Belum terhubung ke pelanggan GIS. Cocokkan serial ONT pada data pelanggan.</p>
    </article>
   </div><p v-if="!onus.data.length" class="card p-6 muted">Tidak ada ONT yang sesuai pada OLT ini.</p><Pagination :links="onus.links"/>
  </template>
 </section>
</template>
<style scoped>
.device{overflow-wrap:anywhere}.chosen{outline:2px solid #60a5fa}.device:focus-visible{outline:3px solid #60a5fa;outline-offset:3px}.state{border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700;background:var(--edge);color:var(--muted)}.ONLINE{background:#dcfce7;color:#166534}.OFFLINE{background:#fee2e2;color:#991b1b}
</style>
