<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\GisObject;
use App\Services\AuditService;
use App\Services\Customer\CustomerService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;

class CustomerController
{
    public function index(Request $r, CustomerService $s)
    {
        return Inertia::render('Customers/Index', ['customers' => $s->query($r->all())->paginate(30)->withQueryString(), 'filters' => $r->all()]);
    }

    public function create()
    {
        return Inertia::render('Customers/Form', ['customer' => null]);
    }

    public function edit(Customer $customer)
    {
        return Inertia::render('Customers/Form', ['customer' => $this->data($customer)]);
    }

    public function show(Customer $customer)
    {
        return Inertia::render('Customers/Show', ['customer' => [...$this->data($customer), 'devices' => $customer->devices()->orderBy('type')->get()]]);
    }

    private function data(Customer $c): array
    {
        return [...$c->toArray(), 'object' => GisObject::withGeometry()->find($c->gis_object_id), 'topology' => $c->topology(), 'surveys' => auth()->user()->can('survey.view') ? $c->surveys()->latest()->get() : []];
    }

    public function store(Request $r, CustomerService $s)
    {
        $c = $s->save($r->all());

        return $r->expectsJson() ? response()->json(['data' => $this->data($c)]) : redirect('/customers/'.$c->id);
    }

    public function update(Request $r, Customer $customer, CustomerService $s)
    {
        $s->save($r->all(), $customer);

        return $r->expectsJson() ? response()->json(['data' => $this->data($customer->fresh())]) : redirect('/customers/'.$customer->id);
    }

    public function destroy(Customer $customer, CustomerService $s)
    {
        $s->delete($customer);

        return back()->with('success', 'Customer dihapus');
    }

    public function deactivate(Customer $customer, CustomerService $s)
    {
        $s->deactivate($customer);

        return back()->with('success', 'Customer dinonaktifkan dan port dilepas');
    }

    public function locate(Request $r, Customer $customer, CustomerService $s)
    {
        $v = $r->validate(['geometry' => 'required|array']);
        $s->save($v, $customer);

        return response()->json(['message' => 'Location updated']);
    }

    public function bulk(Request $r, CustomerService $s)
    {
        $v = $r->validate(['ids' => 'required|array|min:1|max:500', 'ids.*' => 'uuid', 'action' => 'required|in:status,pop,delete,restore', 'status' => 'required_if:action,status|in:PROSPECT,SURVEY,WAITING_INSTALLATION,ACTIVE,SUSPENDED,INACTIVE,TERMINATED', 'pop_id' => 'required_if:action,pop|uuid']);
        Gate::authorize(match ($v['action']) {
            'delete' => 'customer.delete','restore' => 'customer.restore',default => 'customer.update'
        });
        DB::transaction(function () use ($v, $s) {
            foreach ($v['ids'] as $id) {
                $c = Customer::withTrashed()->findOrFail($id);
                match ($v['action']) {
                    'delete' => $s->delete($c),'status' => $s->save(['status' => $v['status']], $c),'pop' => $this->assignPop($s, $c, $v['pop_id']),'restore' => $this->restore($c)
                };
            }
        });

        return back()->with('success', 'Bulk operation selesai');
    }

    private function assignPop(CustomerService $s, Customer $c, string $pop)
    {
        abort_if($c->port()->exists(), 422, 'Customer terhubung port; POP ditentukan topology');

        return $s->save(['pop_id' => $pop], $c);
    }

    private function restore(Customer $c)
    {
        $c->restore();
        GisObject::withTrashed()->findOrFail($c->gis_object_id)->restore();
        AuditService::record('Restore', 'Customer', $c->id, null, $c->toArray());
    }
}
