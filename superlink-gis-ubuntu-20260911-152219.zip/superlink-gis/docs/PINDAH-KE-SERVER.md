# Memindahkan Superlink dari Windows ke Ubuntu

Paket `superlink-gis-ubuntu-*.zip` adalah source aplikasi lengkap untuk build Docker, bukan hanya file JavaScript dalam `public/build`. Paket tidak membawa `.env` lokal, API key CMS, database pelanggan, file upload, dependensi Windows atau cache. Server membutuhkan internet untuk build awal. Langkah berikut untuk instalasi baru pada server yang belum memiliki data Superlink.

## Instalasi baru di 10.1.1.40

1. Pasang Docker Engine dan Compose mengikuti [panduan Ubuntu 24.04](UBUNTU-24.04.md), bagian 1–2.
2. Upload ZIP melalui WinSCP/SFTP ke home user SSH Anda, misalnya `/home/andhika/`. Gunakan user SSH yang benar untuk server Anda.
3. Login SSH. Ganti nama ZIP pada perintah di bawah dengan nama paket yang dikirim:

```bash
sudo apt install -y unzip
sudo unzip superlink-gis-ubuntu-NAMA-PAKET.zip -d /opt
cd /opt/superlink-gis
sudo cp .env.server.example .env
sudo chmod 600 .env
sudo nano .env
```

Isi `DB_PASSWORD` dan `ADMIN_PASSWORD` dengan password baru. APP_URL sudah disiapkan `http://10.1.1.40:8080`. Jangan gunakan placeholder `GANTI_...` sebagai password.

4. Untuk database baru, buat APP_KEY:

```bash
sudo docker run --rm php:8.3-cli php -r 'echo "base64:".base64_encode(random_bytes(32)).PHP_EOL;'
sudo nano .env
```

Masukkan hasil key pada `APP_KEY=` lalu simpan. Simpan key ini bersama backup konfigurasi, jangan dimasukkan ke repository publik.

5. Build dan jalankan:

```bash
sudo docker compose up -d --build
sudo docker compose ps -a
sudo docker compose logs --tail=80 init app queue scheduler nginx
```

Service init dengan status `Exited (0)` berarti migrasi/seed berhasil. Layanan lainnya harus berjalan. Jangan menjalankan server PHP development Windows di Ubuntu.

6. Buka **http://10.1.1.40:8080**. Login dengan ADMIN_EMAIL/ADMIN_PASSWORD dari .env baru. Di **Koneksi CMS & PPPoE**, isi `http://10.1.1.21` dan API key CMS. Simpan lalu sinkronkan. Panduan lengkap konfigurasi, jaringan, HTTPS, dan operasi ada di [UBUNTU-24.04.md](UBUNTU-24.04.md).

## Jika data Windows juga ingin dibawa

Jangan gunakan alur database baru lalu menganggap data lama otomatis ikut. Database, storage private, dan APP_KEY sumber harus dipindahkan terpisah. Backup berisi data pelanggan dan token terenkripsi; simpan sebagai file privat.

Pada PowerShell, dari direktori `superlink-gis`, hentikan aktivitas tulis aplikasi selama backup konsisten dibuat:

```powershell
New-Item -ItemType Directory -Force ../transfer-private | Out-Null
& '../.tools/postgres/pgsql/bin/pg_dump.exe' -h 127.0.0.1 -p 55432 -U superlink -d superlink -Fc -f ../transfer-private/superlink.dump
tar -czf ../transfer-private/storage-private.tgz -C storage/app private
```

Pastikan pg_dump selesai tanpa error. Catat **APP_KEY yang sudah ada** dari `.env` sumber secara privat. Jangan menaruh key di command line, chat, atau screenshot. Backup di atas belum dibuat otomatis oleh proses packaging. Pengguna yang memilih migrasi bertanggung jawab menghentikan import, operasi perangkat, dan penulisan data selama pemindahan.

Di Ubuntu, salin ZIP aplikasi dan dua backup tersebut melalui SFTP. Buat .env server seperti di atas, tetapi gunakan **APP_KEY sumber**. Jangan menggenerate key baru. Dengan target database baru/kosong, jalankan:

```bash
cd /opt/superlink-gis
sudo docker compose build
sudo docker compose up -d --wait postgres redis
sudo docker compose exec -T postgres sh -c 'pg_restore --exit-on-error --no-owner --no-acl -U "$POSTGRES_USER" -d "$POSTGRES_DB"' < /home/andhika/superlink.dump
```

Sesuaikan path home. Perintah restore ditujukan hanya untuk database target kosong; jika target sudah berisi tabel, berhenti dan rencanakan restore ke database lain. Tidak ada perintah penghapusan database pada panduan ini.

Matikan konektor otomatis sebelum aplikasi target dijalankan agar source dan target tidak melakukan pekerjaan yang sama. Tandai pekerjaan perangkat yang terbawa sebagai perlu rekonsiliasi dan hapus payload kredensialnya:

```bash
sudo docker compose exec -T postgres sh -c 'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' <<'SQL'
UPDATE provisioning_connections SET enabled=false, allow_writes=false;
UPDATE device_operations SET status='UNKNOWN', payload=NULL,
message='Dipindahkan server: periksa perangkat sebelum rekonsiliasi.', updated_at=now()
WHERE status IN ('QUEUED','RUNNING');
SQL
sudo docker compose run --rm init
sudo docker compose run --rm --no-deps -T --user root app sh -c 'mkdir -p storage/app; tar -xzf - -C storage/app; chown -R www-data:www-data storage' < /home/andhika/storage-private.tgz
sudo docker compose up -d app queue scheduler nginx
```

Backup storage dibuat sendiri dari folder `private`; jangan memakai arsip dari pihak yang tidak dikenal untuk ekstraksi sebagai root. Command SQL di atas mengasumsikan database sumber versi paket ini sudah memiliki tabel konektor; jika database lebih lama, jalankan migrasi terlebih dahulu dengan worker/scheduler tetap dihentikan.

Setelah login, periksa jumlah pelanggan, peta, file import, dan riwayat. Login mengikuti **akun database lama**, karena seeder tidak mengganti password akun existing. Pastikan instance Windows tidak lagi menjalankan pekerjaan pada CMS sebelum mengaktifkan konektor di server baru. Restore PostgreSQL tidak membawa antrean Redis lama; pekerjaan import yang belum selesai di sumber perlu ditangani atau di-upload ulang.

Simpan backup sampai pemeriksaan migrasi selesai. Jangan menjalankan `docker compose down -v` atau `migrate:fresh` untuk mengatasi masalah pada database yang berisi data.

## Memperbarui paket

Update RBAC menambahkan role `CUSTOMER_SERVICE`. Jalankan `php artisan db:seed --class=RolePermissionSeeder --force` melalui container app setelah update bila tidak menggunakan service init. Init sudah menjalankan seeder tersebut. Di Settings, ADMIN dapat memilih CUSTOMER_SERVICE saat membuat user atau mengganti role pada tabel pengguna. Aksesnya hanya Dashboard pelanggan dan grup Customers (lihat/tambah/edit/import/export); tidak memiliki izin hapus pelanggan, peta, OLT/CMS, survey, statistik zona, reports, audit atau settings. Perubahan berlaku pada request berikutnya; pengguna dapat refresh halaman. Dashboard Customer Service tidak mengirim data statistik jaringan/survey ke browser.

Untuk server existing, jangan menimpa .env dan jangan menjalankan restore database baru. Backup terlebih dahulu, ganti source dengan paket terbaru, lalu ikuti bagian update pada [panduan Ubuntu](UBUNTU-24.04.md). Paket tidak memuat .env atau storage lokal sehingga source dapat dipisahkan dari data deployment.

Untuk mengaktifkan pilihan peta MapTiler dan status sesi pelanggan, ikuti [Peta dan PPPoE](PETA-DAN-PPPOE.md). Kredensial router dan key peta tidak dibawa oleh ZIP.
